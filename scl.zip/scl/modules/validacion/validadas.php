<?php
# @uthor Mark 
# Agenda File 

require_once("includes/includes.inc.php");
require_once("validacion.inc.php");

initialize("validacion","Validaci�n");

$id_solicitud = base64_decode($_REQUEST['sol']);	
$s_usr_id = get_session_varname("s_usr_id");

layout_menu($db,"");
$sol_validada= get_sol_validada($s_usr_id,$db); 

?>
	<p class="textbold">Validacion &gt; Solicitudes Validadas</p>
	<p>&nbsp;</p>
	<form method="post" action="modules.php?mod=validacion&op=index" name="frm3">
	<table class="text" border="0">
		<tr>
			<td>
				<table>
					<tr style="font-weight:bold;" align="center">
						<td># Reg.</td>
						<td>&nbsp;</td>
						<td># Solicitud</td>
						<td>&nbsp;</td>
						<td>Cliente</td>
						<td>&nbsp;</td>
						<td>Fecha</td>
						<td>&nbsp;</td>												
						<!--td>Editar</td-->
						
					</tr>
					<?					
						$i = 1;
						while(!$sol_validada->EOF) {
								echo '<tr align="center">
										<td class="textleft">'.$i.'</td>
										<td>&nbsp;</td>
										<td class="textleft">'.$sol_validada->fields["ID_SOLICITUD"].'</td>
										<td>&nbsp;</td>
										<td class="textleft">'.$sol_validada->fields["MAIN_NOMBRE_COMPLETO"].'</td>
										<td>&nbsp;</td>
										<td class="textleft">'.$sol_validada->fields["DFECHA"].'</td>
										<td>&nbsp;</td>										
										<!--td class="textleft"><a href="modules.php?mod=validacion&op=valida_solicitud&sol='.$sol_validada->fields["ID_SOLICITUD"].'"><img src="'.$linkpath.'includes/imgs/Editar.gif"></a></td-->
										<td>&nbsp;</td>
										
									</tr>';
								$i++;
								$sol_validada->MoveNext();
							}
					?>
				</table>			
			</td>
		</tr><tr>
			<td colspan="3">&nbsp;</td>
		</tr><tr>
			<td colspan="3">
				<input type="submit" value="Buscar Solicitud">
			</td>
		</tr>
	</table>
	</form>
<?
layout_footer();
?>