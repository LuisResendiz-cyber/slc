<?php

# BUSCA LA SOLICITUD ENVIADA POR EL AGENTE A VALIDACION
function get_sol_capturada($p_solicitud, $db){
	$stmt = $db->PrepareSP("BEGIN SPS_SOL_CAPTURADA(:p_solicitud,:p_existe,:p_calregistro, :p_statusllamada, :p_etapa); END;");
	$db->InParameter($stmt, $p_solicitud, 'p_solicitud');
	$db->OutParameter($stmt, $p_existe, 'p_existe');
	$db->OutParameter($stmt, $p_calregistro, 'p_calregistro');	
	$db->OutParameter($stmt, $p_statusllamada, 'p_statusllamada');
	$db->OutParameter($stmt, $p_etapa, 'p_etapa');	
	$db->Execute($stmt);
	return $p_existe.'-'.$p_calregistro.'-'.$p_statusllamada.'-'.$p_etapa;
}

# OBTIENE UN NUEVO REGISTRO
function get_detalle_solicitud($s_usr_id, $db){
	$rs = $db->ExecuteCursor("BEGIN SPS_DETALLESSOLICITUD(".$s_usr_id.",:rc); END;", 'rc');
	$db->SetFetchMode(ADODB_FETCH_BOTH);
	return $rs;
}

function get_detalle_solicitud_validacion($id_solicitud, $db){
	$rs = $db->ExecuteCursor("BEGIN SPS_DETALLE_SOLICITUD_VAL(".$id_solicitud.",:rc); END;", 'rc');
	$db->SetFetchMode(ADODB_FETCH_BOTH);
	return $rs;
}

# OBTIENE LA LISTA DE CATALOGOS DE FORMA DINAMICA PARA IN
function get_catalogo($v_id_campo, $db){
	$rs = $db->ExecuteCursor("BEGIN spS_Catalogo('".$v_id_campo."',:rc); END;", 'rc');
	$db->SetFetchMode(ADODB_FETCH_BOTH);
	return $rs;
}


#MUESTRA SCRIPT A MOSTRAR
function set_muestra_script($id_solicitud, $db){
	$stmt = $db->PrepareSP("BEGIN SPS_MUESTRA_SCRIPT(:p_solicitud, :p_script); END;");
	$db->InParameter($stmt, $id_solicitud, 'p_solicitud');
	$db->OutParameter($stmt, $p_script, 'p_script');
	$db->Execute($stmt);	
	return $p_script;
}

# GUARDA LOS DATOS DE LA SOLICITUD EN BASE DE DATOS
function set_venta_ok($id_solicitud, $etapa, $producto, $usr_super, $user, $nombre, $paterno, $materno, $nombre_completo, $fecha_nac, $rfc, $tdc, $tdc1, $tdc2, $tdc3, $promo, $edocta, $calle, $num_ext, $num_int, $id_codigo, $cp, $colonia, $tel1, $tipo_tel1, $tel2, $tipo_tel2, $celular, $email, $tarjetas_adi, $autoriza_buro, $comentarios, $db){
	//$stmt = $db->PrepareSP("BEGIN SPX_GUARDASOL_VAL(:p_s_usr_id, :p_solicitud, :p_nombre,:p_paterno, :p_materno ,:p_nombre_completo, :p_tel_contacto,:p_tdc, :p_tel_alterno, :p_tel_celular, :p_email, :p_actualizar, :p_promo, :p_mastdc, :p_edocta,:p_tdc1, :p_tdc2, :p_tdc3, :p_ejecutivo_venta,:p_folio_carta , :p_statusllamada, :p_calregistro, :p_telefono, :p_actualizado ); END;");
    $stmt = $db->PrepareSP("BEGIN SPX_GUARDASOL_VAL(:p_solicitud, :p_etapa, :p_producto, :p_usr_super, :p_user, :p_nombre, :p_paterno, :p_materno, :p_nombre_completo, :p_fecha_nac, :p_rfc, :p_tdc, :p_tdc1, :p_tdc2, :p_tdc3, :p_promo, :p_edocta, :p_calle, :p_num_ext, :p_num_int, :p_id_codigo, :p_cp, :p_colonia, :p_tel1, :p_tipo_tel1, :p_tel2, :p_tipo_tel2, :p_celular, :p_email, :p_tarjetas_adi, :p_autoriza_buro, :p_comentarios, :p_statusllamada, :p_calregistro, :p_telefono, :p_actualizado); END;");
	$db->InParameter($stmt, $id_solicitud, 'p_solicitud');
	//$db->InParameter($stmt, $id_registro, 'p_id_registro');
    $db->InParameter($stmt, $etapa, 'p_etapa');
    //$db->InParameter($stmt, $cal_reg, 'p_cal_reg');
	$db->InParameter($stmt, $producto, 'p_producto');
	$db->InParameter($stmt, $usr_super, 'p_usr_super');
	$db->InParameter($stmt, $user, 'p_user');
    //$db->InParameter($stmt, $subcalificacion, 'p_subcalificacion');
    $db->InParameter($stmt, $nombre, 'p_nombre');
	$db->InParameter($stmt, $paterno, 'p_paterno');
	$db->InParameter($stmt, $materno, 'p_materno');
	$db->InParameter($stmt, $nombre_completo, 'p_nombre_completo');
    $db->InParameter($stmt, $fecha_nac, 'p_fecha_nac');
	$db->InParameter($stmt, $rfc, 'p_rfc');
    $db->InParameter($stmt, $tdc, 'p_tdc');
    $db->InParameter($stmt, $tdc1, 'p_tdc1');
	$db->InParameter($stmt, $tdc2, 'p_tdc2');
	$db->InParameter($stmt, $tdc3, 'p_tdc3');
    $db->InParameter($stmt, $promo, 'p_promo');
	$db->InParameter($stmt, $edocta, 'p_edocta');
    $db->InParameter($stmt, $calle, 'p_calle');
    $db->InParameter($stmt, $num_ext, 'p_num_ext');
    $db->InParameter($stmt, $num_int, 'p_num_int');
    $db->InParameter($stmt, $id_codigo, 'p_id_codigo');
    $db->InParameter($stmt, $cp, 'p_cp');
    $db->InParameter($stmt, $colonia, 'p_colonia');
    $db->InParameter($stmt, $tel1, 'p_tel1');
    $db->InParameter($stmt, $tipo_tel1, 'p_tipo_tel1');
    $db->InParameter($stmt, $tel2, 'p_tel2');
    $db->InParameter($stmt, $tipo_tel2, 'p_tipo_tel2');
    $db->InParameter($stmt, $celular, 'p_celular');
    $db->InParameter($stmt, $email, 'p_email');
    $db->InParameter($stmt, $tarjetas_adi, 'p_tarjetas_adi');
    $db->InParameter($stmt, $autoriza_buro, 'p_autoriza_buro');
    $db->InParameter($stmt, $comentarios, 'p_comentarios');
	$db->OutParameter($stmt, $p_statusllamada, 'p_statusllamada');
	$db->OutParameter($stmt, $p_calregistro, 'p_calregistro');	
	$db->OutParameter($stmt, $p_telefono, 'p_telefono');	
	$db->OutParameter($stmt, $p_actualizado, 'p_actualizado');
	$db->Execute($stmt);

    return $p_statusllamada.'-'.$p_calregistro.'-'.$p_telefono.'-'.$p_actualizado;
}


# DATOS DEL CLIENTE
function get_sol_validada($s_usr_id, $db){
	$rs = $db->ExecuteCursor("BEGIN SPS_SOL_VALIDADA(".$s_usr_id.",:rc); END;", 'rc');
	$db->SetFetchMode(ADODB_FETCH_BOTH);
	return $rs;
}


function get_detalle_telefono($s_usr_id, $action, $db){
	$rs = $db->ExecuteCursor("BEGIN SPS_DETALLESTELEFONO(".$s_usr_id.",".$action.",:rc); END;", 'rc');
	$db->SetFetchMode(ADODB_FETCH_BOTH);
	return $rs;
}

#GUARDA EL SEGUIMEINTO DE UNA SOLICITUD 
function set_guardaseguimiento($id_solicitud, $etapa, $calificacion, $statuscalif,$telefono,$maquina, $id_usr, $usr_super,$activo,$id_zona,$sub_calregistro,$id_tipo_evento,$num_intentos, $db){
	$stmt = $db->PrepareSP("BEGIN SPI_SEGUIMIENTO(:p_solicitud, :p_etapa, :p_calificacion, :p_statuscalif, :p_telefono, :p_id_user, :p_maquina, :p_usr_super, :p_activo, :p_id_zona, :p_sub_calregistro, :p_id_tipo_evento, :p_num_intentos ); END;");	
	$db->InParameter($stmt,	$id_solicitud, 'p_solicitud');
	$db->InParameter($stmt, $etapa, 'p_etapa');
	$db->InParameter($stmt, $calificacion, 'p_calificacion');
	$db->InParameter($stmt, $statuscalif, 'p_statuscalif');
	$db->InParameter($stmt, $telefono, 'p_telefono');
	$db->InParameter($stmt, $maquina, 'p_maquina');
	$db->InParameter($stmt, $id_usr, 'p_id_user');	
	$db->InParameter($stmt, $usr_super, 'p_usr_super');
	$db->InParameter($stmt, $activo, 'p_activo');
	$db->InParameter($stmt, $id_zona, 'p_id_zona');
	$db->InParameter($stmt, $sub_calregistro, 'p_sub_calregistro');
	$db->InParameter($stmt, $id_tipo_evento, 'p_id_tipo_evento');
	$db->InParameter($stmt, $num_intentos, 'p_num_intentos');	
	$db->Execute($stmt);
}

# Devuelve los ultimos valores con los cuales esta guardado el registro en TBL_DATOS.
function set_status_registro($id_solicitud,$db){	
	$rs = $db->ExecuteCursor("BEGIN SPS_STATUS_REGISTRO(".$id_solicitud.",:rc); END;", 'rc');
	$db->SetFetchMode(ADODB_FETCH_BOTH);
	return $rs;
}

?>