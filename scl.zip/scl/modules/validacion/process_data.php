<?php
# @uthor Mark 
# Process_data File on Validacion

require_once("includes/includes.inc.php");
require_once("validacion.inc.php");

initialize_nolayout("validacion","");

$action = $_REQUEST['act'];
$header = "modules.php?mod=validacion&op=index";

if(isset($action) && $action == 1){ # BUSCA LA SOLICITUD QUE SE VA A VALIDAR
	$s_usr_id = get_session_varname('s_usr_id');
	$id_solicitud = $_REQUEST['idsolicitud'];	
	
	$existe_sol = get_sol_capturada($id_solicitud, $db);
	
	$existe_sol_ = explode('-',$existe_sol);
	$existe = $existe_sol_[0];
	$calificacion = $existe_sol_[1];
	$statusllamada = $existe_sol_[2];
	$etapa = $existe_sol_[3];	
		
	set_traking(get_session_varname("s_usr_id"),'B SOL_VAL', get_session_varname("s_usr_maquina"), $id_solicitud, '', $db);	

    if($existe == 1 && $statusllamada == 1013){
        set_session_varname("id_solicitud",$id_solicitud);
		set_traking(get_session_varname("s_usr_id"),'T SOL_VAL', get_session_varname("s_usr_maquina"), $id_solicitud, '', $db);						
        $header = "modules.php?mod=validacion&op=valida_solicitud";
	}else{
        unset_session_varname("id_solicitud");
		$header = "modules.php?mod=validacion&op=error&e=1&sl=".$id_solicitud;
	}	set_traking(get_session_varname("s_usr_id"),'N E SOL_VAL', get_session_varname("s_usr_maquina"), $id_solicitud, '', $db);				
	
	
} elseif (isset($action) && $action == 2) { // GUARDA LOS CAMBIOS QUE EN VALIDACI�N SE LLEGARON A DAR O SIMPLEMENTE PROCESAR.

    $nombre = $_REQUEST['nombre'];
	$paterno = $_REQUEST['paterno'];
	$materno = $_REQUEST['materno'];
	$nombre_completo = $_REQUEST['nombre'].' '.$_REQUEST['paterno'].' '.$_REQUEST['materno'];
	$fecha_nac = $_REQUEST['fecha_nac'];
    $rfc = $_REQUEST['rfc'];
    $tdc = $_REQUEST['tdc'];
    $tdc1 = $_REQUEST['tdc1'];
    $tdc2 = $_REQUEST['tdc2'];
    $tdc3 = $_REQUEST['tdc3'];
    $promo = $_REQUEST['promociones'];
    $edocta = isset($_REQUEST['estados_cuenta']) ? $_REQUEST['estados_cuenta'] : 0;
    $tarjetas_adi = $_REQUEST['tarjetas_adicionales'];
    $calle = $_REQUEST['calle'];
    $num_ext = $_REQUEST['num_ext'];
    $num_int = $_REQUEST['num_int'];
    $id_codigo = $_REQUEST['id_codigo'];
    $cp = $_REQUEST['cp'];
    $colonia = $_REQUEST['colonia'];
    $tel1 = $_REQUEST['tel1'];
    $tipo_tel1 = $_REQUEST['tipo_tel1'];
    $tel2 = $_REQUEST['tel2'];
    $tipo_tel2 = $_REQUEST['tipo_tel2'];
    $celular = $_REQUEST['celular'];
    $email = $_REQUEST['email'];
    $etapa = $_REQUEST['id_etapa'];
	$autoriza_buro = $_REQUEST['autoriza_buro'];
    $comentarios = $_REQUEST['comentarios'];

    $producto = 1;
	$user = get_session_varname("s_usr_id");
	$usr_super = get_session_varname("s_usr_super");
	$id_solicitud = get_session_varname('id_solicitud');
    
    $regi_actulizado = set_venta_ok($id_solicitud, $etapa, $producto, $usr_super, $user, $nombre, $paterno, $materno, $nombre_completo, $fecha_nac, $rfc, $tdc, $tdc1, $tdc2, $tdc3, $promo, $edocta, $calle, $num_ext, $num_int, $id_codigo, $cp, $colonia, $tel1, $tipo_tel1, $tel2, $tipo_tel2, $celular, $email, $tarjetas_adi, $autoriza_buro, $comentarios, $db);
	
	$regi_actulizado_ = explode('-',$regi_actulizado);
	$statusllamada = $regi_actulizado_[0];
	$calificacion = $regi_actulizado_[1];
	$telefono = $regi_actulizado_[2];
	$actualizado = $regi_actulizado_[3];	
	
	if($actualizado == 1){		
		set_traking($s_usr_id,'GRABOGRABO SOL_VAL', get_session_varname("s_usr_maquina"), $solicitud, '1003', $db);		
		
		$status_registro = set_status_registro($solicitud,$db);
		set_guardaseguimiento($solicitud, $status_registro->fields['ID_ETAPA'],$status_registro->fields['CAL_REGISTRO'],$status_registro->fields['ID_STATUSLLAMADA'],0, get_session_varname("s_usr_maquina"), get_session_varname("s_usr_id"),$status_registro->fields['USR_ID_SUPERVISOR'],$status_registro->fields['ACTIVO'],$status_registro->fields['ID_ZONA'],$status_registro->fields['SUB_CALREGISTRO'],9,$status_registro->fields['NUM_INTENTOS'], $db);
		unset_session_varname("id_solicitud");	 	
		$header = "modules.php?mod=validacion&op=validadas";
	}else{
		$header = "modules.php?mod=validacion&op=error&e=1"; # ERROR NO ACTUALIZO LA SOLICITUD EN VALIDACION CORRECTAMENTE.
	}	
	
}

header("location: ".$header);
?>