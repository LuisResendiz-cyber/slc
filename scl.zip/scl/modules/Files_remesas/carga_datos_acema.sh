#!/bin/sh

export ORACLE_BASE=/u01/app/oracle
export ORACLE_HOME=/u01/app/oracle/product/10.2.0/db_1
export LD_LIBRARY_PATH=$ORACLE_HOME/lib
export ORACLE_SID=ccm
export ORACLE_TERM=xterm
export ORAHOME=/u01/app/oracle/product/10.2.0/db_1
export ORASID=ccm
export PATH=/u01/app/oracle/product/10.2.0/db_1/bin:/usr/sbin:/usr/local/bin:/bin:/usr/bin

sqlldr USERID=acema/a92e651641e@ccm, CONTROL=/opt/data/www/htdocs/seguimiento/modules/Files_remesas/load_data_acema_lx.ctl, LOG=/opt/data/www/htdocs/seguimiento/modules/Files_remesas/load_data_acema.log, bad=/opt/data/www/htdocs/seguimiento/modules/Files_remesas/load_data_acema.bad

sqlldr USERID=ccupdate/c11d4294072@ccm, CONTROL=/opt/data/www/htdocs/ccupdate/modules/mesa_control/load_data_ccupdate_lx.ctl, LOG=/opt/data/www/htdocs/ccupdate/modules/mesa_control/load_data_ccupdate.log, bad=/opt/data/www/htdocs/ccupdate/modules/mesa_control/load_data_ccupdate.bad

#data=T03DJ000004.DAT
