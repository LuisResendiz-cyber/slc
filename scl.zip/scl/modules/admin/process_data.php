<?php
require_once("includes/includes.inc.php");
require_once("modules/agentes/agentes.inc.php");

load_session();

$isPredictivo = get_session_varname("s_usr_marcacion");

$action = isset($_REQUEST['act']) ?  $_REQUEST['act']: '';
$header = "index2.php";
$empresa = get_session_varname("s_usr_centro");

/* var_dump($action); //1
var_dump($empresa); //false(no data)
var_dump($isPredictivo); //false(no data)

die(); */

if (isset($action) && $action == 1) { # VALIDA LA AUTENTICACION DEL USUARIO
    $valor_return = login($_POST["user"], $_POST["password"], $_POST["marcacion"], $db);

    //echo $_POST["user"]. "<br>"; //577242
    //echo $_POST["password"]. "<br>"; //1-577242
    //echo $_POST["marcacion"]. "<br>"; //2
    //var_dump($valor_return); //2
    //gettype($valor_return);


    if($_POST["marcacion"] == 2 && ($valor_return == 0 || $valor_return == 5 || $valor_return == 6)){

        $header = "modules.php?mod=agentes&op=process_data&act=MQ==";
        set_session_varname("inicio",1);
    }else if($_POST["marcacion"] == 1 && ($valor_return == 0 || $valor_return == 5 || $valor_return == 6)){

/*         echo "Voy aca2...";
        die();
 */
        $usr_id = get_session_varname("s_usr_id");
        $url_logout_pred = "http://172.20.1.10/click2dial/tdcamexonline/softemployeelogout.php?employeeid=" . $usr_id;

        $handler_logout = curl_init($url_logout_pred);
        $logout_pred = curl_exec($handler_logout);
        curl_close($handler_logout);

        set_preavail($usr_id, "-1", $db);

        $header = "index2.php?msg=" . encripta($valor_return);


    }elseif($valor_return == 13 || $valor_return == 14 || $valor_return == 15){

     /*    echo "Voy aca3...";
        die();
 */
        $header = "index2.php?msg=" . encripta($valor_return);

    }else{
         //echo "voy aca4....";
         //die();
        $usr_id = get_session_varname("s_usr_id");

     //var_dump($usr_id); //77652
       // die();

        $url_logout_pred = "http://172.20.1.10/click2dial/tdcamexonline/softemployeelogout.php?employeeid=" . $usr_id;
        //Limpia al agente de predictivo
        $handler_logout = curl_init($url_logout_pred);
        $logout_pred = curl_exec($handler_logout);
        curl_close($handler_logout);

        set_preavail($usr_id, "-1", $db);


        $header = "index2.php?msg=" . encripta($valor_return);
    }
} elseif (isset($action) && $action == 2) { # TERMINA SESION DEL USUARIO

    $usr_id = get_session_varname("s_usr_id");
    $id_solicitud = get_session_varname('id_solicitud');
    $id_registro = get_session_varname('id_registro');
    // var_dump($id_solicitud.' - '.$id_registro);die();
    set_libera_solicitud($id_registro, 1, 1, $db);
    set_traking($usr_id, 'ABANDONO REGISTRO', get_session_varname("s_usr_maquina"), $id_solicitud, 0, $db);

    if ($isPredictivo == 1) {
        $usr_id = get_session_varname("s_usr_id");


        $url_clear_pred = "http://172.20.1.10/click2dial/tdcamexonline/clearmeetme.php?employeeid=" . $usr_id;
        //Limpia al agente de predictivo
        $handler_clear = curl_init($url_clear_pred);
        $clear_pred = curl_exec($handler_clear);
        curl_close($handler_clear);

        //Pone el pre_avail en -1
        set_preavail($usr_id, "-1", $db);

        $url_logout_pred = "http://172.20.1.10/click2dial/tdcamexonline/softemployeelogout.php?employeeid=" . $usr_id;
        //Limpia al agente de predictivo
        $handler_logout = curl_init($url_logout_pred);
        $logout_pred = curl_exec($handler_logout);
        curl_close($handler_logout);

        set_preavail($usr_id, "-1", $db);
    }

    set_traking(get_session_varname("s_usr_id"), 'FINALIZO SESION', get_session_varname("s_usr_maquina"), 0, '', $db);
    $resul = set_autorizacion(get_session_varname('s_usr_nomina'),3, $db);
    if($resul == '1') {
        set_traking($usr_id, 'INICIO PERMISO', get_session_varname("s_usr_maquina"), '', '', $db);
    }
    unload_session($db);
    $header = "index2.php?log_out=1";
}

header("location: " . $header);
