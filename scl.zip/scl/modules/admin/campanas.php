<?php
# Campanas File 
# @uthor Mark   

require_once("includes/includes.inc.php");
require_once("admin.inc.php");

initialize("mesa_control","Seleccion de Campa&ntilde;a", $db);

get_menu($db);
?>
	<p class="textbold">Seguimiento &gt; Campa&ntilde;a</p>
	<p>&nbsp;</p>
	<form name="frm1" method="post" action="modules.php?mod=admin&op=process_data&act=3">
	<table border ="0">
		<tr style="background-color:<?=getColor(0)?>">
			<td align="center" colspan="2"><b>Selecci&oacute;n</b></td>
		</tr><tr>
			<td align="center" colspan="2">
				<b>Campa&ntilde;a:&nbsp;</b>
				<select name="s_id_campana" onChange="asigna_campana()">
					<option value="0">Elige opcion</option>
<?php
					$i = 0;
					$rs = get_campanas($db);
					while(!$rs->EOF) {
						echo '<option value="'.$rs->fields[0].'" '.(get_session_varname('s_campana_id')==$rs->fields[0]?" selected":"").' >'.$rs->fields["NOMBRE"].'</option>';
						$rs->MoveNext();
						$i++;
					}					
?>					
				</select>
			</td>
		</tr>
	</table>
	</form>
	<p>&nbsp;</p>
<?php 
get_footer();
?>