<?php
require_once("../includes/includes.inc.php");
/****************/
/*  Admin File */
/* @uthor Mark */
/***************/

echo layout_header();
echo '<h4>Nuevo Usuario</h4>';
echo '<p id="text">Para agregar un usuario de clic en la opcion <b>Nuevo</b><br>';

$conn = getConn();
$query = "SELECT * FROM USERS";
$statement = execute($conn, $query);

echo '<h4>ABC usuarios</h4>';
echo '<p id="text">Para agregar un usuario de clic en la opcion <b>Nuevo</b><br>';
echo 'Para modificar los datos del usuario, seleccione al usuario y de clic en la opcion <b>Editar</b><br> ';
echo 'Para borrar un registro, de clic sobre el nombre del usuario y presione <b>Eliminar</b><br></p>';

echo '<a href="users/adduser.php" class="link">Nuevo</a>&nbsp;&nbsp;';
echo '<a href="#" onclick="editData()" id="edit" class="link" style="display: none;">| Editar</a>&nbsp;&nbsp;';
echo '<a href="#" onclick="deleteData()" id="delete" class="link" style="display: none;">| Eliminar</a>&nbsp;&nbsp;<br>';
echo '<form method="post" name="frmdetail" action="users/process.php">';
echo '<input type="hidden" name="idSelected">';
echo '<input type="hidden" name="action">';
echo '<table border="1" width="30%" id="t1">';
echo '<tr><td>Id User</td><td>Name</td><td>Mail</td></tr>';
// Fetch the results in an associative array 
while ($row = oci_fetch_array ($statement, OCI_NUM)) {
	echo '<tr><td>'.$row[0].'</td><td><a href="#" class="link" onclick="select_elem(this, '.$row[0].')">'.$row[1].'</a></td><td>'.$row[2].'</td></tr>';
}
echo '<tr><td colspan="4">Registros Encontrados:'.numrows($statement).'</td></tr>';
echo '</table>';
echo '</form>';
echo layout_footer();

?>

         
          