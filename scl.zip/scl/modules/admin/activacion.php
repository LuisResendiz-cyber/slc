<?php
# Activacion File 
# @uthor Mark

require_once("includes/includes.inc.php");

initialize("administrador","Activaci&oacute;n de Usuarios", $db);
get_menu($db, "");

?>
	<h4>Activacion de Usuarios</h4>
	<form name="frm1" method="post" action="process_data.php">
	<p id="text">Para activar la cuenta de un usuario, ingrese el Id Usuario y d&eacute; clic en el bot&oacute;n continuar<br>
	<table width="30%" id="t1" border="0">
		<tr>
			<td>&nbsp;</td>
		</tr><tr>		
			<td colspan="2"><?=form_oblmsg();?></td>
		</tr><tr>
			<td colspan="2">&nbsp;</td>
		</tr><tr>
			<td>* Id Usuario:</td>
			<td><input type="text" name="s_usr_id" value="" maxlength="19" size="20"></td>
		</tr><tr>
			<td colspan="2">
				<div id="resp_act" style="display:none"></div>
			</td>
		</tr>
	</table>
    </form>
	<br>
	<input type="button" value="Cancelar" onclick="Atras()">
	<input type="button" value="Activar" onclick="Activar()">
	<br>
<?
get_footer();
?>