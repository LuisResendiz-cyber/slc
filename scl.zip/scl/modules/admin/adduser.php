<?php
require_once("../includes/includes.inc.php");

/****************/
/*adduser File */
/* @uthor Mark */
/***************/

echo layout_header();
echo '<h4>Nuevo Usuario</h4>';
echo '<p id="text">Para agregar un usuario de clic en la opcion <b>Nuevo</b><br>';
?>
	<FORM name="forma" method="POST" action="./process.php">
	<input type="hidden" name="action" value="1">
	<table width="30%" id="t1" border="1">
	   <tr>
	       <td colspan="2">* Campos Requeridos</td>
	   </tr><tr>
	   	   <td >* Nombre:</td>
		   <td><input type="text" name="name" value="" maxlength="19" size="20"></td>
	   </tr><tr>
		   <td >* Paterno:</td>
		   <td><input type="text" name="lastname"  maxlength="20" size="20" value=""></td>
	   </tr><tr>
		   <td >* Mail</td>
		   <td><input type="text" name="mail"  maxlength="20" size="20" value=""></td>
		</tr>
	</table>
	<br>
	<input type="button" value="Cancelar" onclick="window.location='../index.php'">
	<input type="submit" value="Continuar">
	<br>

<?=layout_footer();?>

         
          