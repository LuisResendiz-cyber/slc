<?php
# @uthor Mark 
# abc_usuarios File en NOMINA

require_once("includes/includes.inc.php");
require_once("nominas.inc.php");

initialize("nomina","ABC Usuarios");
layout_menu($db, "");

?>
	<h4>ABC de Usuarios</h4>
	<form name="frm1" method="post" action="modules.php?mod=nomina&op=abc_usuarios">
	<p id="text">Para mostrar los usuarios disponibles del sistema ingrese el campo nombre y/o el campo Id Usuario y d� clic en el bot�n continuar.
	<br><br>
	<input type="hidden" name="search" value="10">
	<table width="50%" id="t1" border="0">
	   <tr>
			<td>&nbsp;</td>
		</tr><tr>	
			<td >Nombre:</td>
			<td><input type="text" name="nombre" value="<?=$_REQUEST['nombre']?>" maxlength="50" size="50"></td>
		</tr><tr>
			<td >Paterno:</td>
			<td><input type="text" name="paterno" value="<?=$_REQUEST['paterno']?>" maxlength="30" size="30"></td>
		</tr><tr>		
			<td >Materno:</td>
			<td><input type="text" name="materno" value="<?=$_REQUEST['materno']?>" maxlength="30" size="30"></td>
		</tr><tr>
		   <td >Id Usuario</td>
		   <td><input type="text" name="id_usuario" value="<?=$_REQUEST['id_usuario']?>" maxlength="20" size="8" value=""></td>
		</tr>
	</table>
	<br>
	<input type="button" value="Cancelar" onclick="Atras()">
	<input type="button" value="Buscar" onclick="Buscar_usuarios()">
	</form>
	<br>
	
<?
if($_REQUEST['search'] == 10){

	$nombre = ($_REQUEST['nombre']!=""?$_REQUEST['nombre']:"");
	$paterno = ($_REQUEST['paterno']!=""?" ".$_REQUEST['paterno']:"");
	$materno = ($_REQUEST['materno']!=""?" ".$_REQUEST['materno']:"");
	$id_usuario = ($_REQUEST['id_usuario']!=""?$_REQUEST['id_usuario']:0);
?>	
	<hr>
	<h4>Resultados de la busqueda</h4>
	<form method="post" action="modules.php?mod=nomina&op=edita_usuario" name="frm2">
		<input type="hidden" name="idSelected" id="idSelected">
		<p>
			<a href="#" onclick="nuevo_usuario()" class="optionlink" id="linknuevo">Nuevo Usuario</a>&nbsp;&nbsp;&nbsp;
			<a href="#" onclick="edit_data()" class="optionlink" id="linkeditar" style="display: none;">Editar Usuario</a>&nbsp;&nbsp;&nbsp;
		</p>
		<table border="0">
			<tr bgcolor="gray">
				<td><b>#</b></td>
				<td>&nbsp;</td>
				<td><b>Nombre</b></td>
				<td>&nbsp;</td>
				<td align="center"><b>Id usuario</b>&nbsp;&nbsp;&nbsp;</td>
				<td>&nbsp;</td>
				<td align="center"><b>Perfil</b>&nbsp;&nbsp;&nbsp;</td>
				<td>&nbsp;</td>
				<td align="center"><b>Estado</b>&nbsp;&nbsp;&nbsp;</td>
			</tr>
			<?
			$d = 1;
			$usuarios = get_busqueda_usuarios($nombre.$paterno.$materno, $id_usuario,$db);

			while(!$usuarios->EOF) {
				echo '<tr>
						<td>'.$d.'</td>
						<td>&nbsp;</td>
						<td><a href="#" onclick="select(this,'.$usuarios->fields["USR_ID"].')" class="textlink">'.$usuarios->fields["USR_NOMBRE"].'</a>&nbsp;&nbsp;&nbsp;</td>
						<td>&nbsp;</td>
						<td>'.$usuarios->fields["USR_ID"].'</td>
						<td>&nbsp;</td>
						<td align="center">'.get_perfil_usuario($usuarios->fields["USR_NIVEL"]).'</td>
						<td>&nbsp;</td>
						<td>'.($usuarios->fields["USR_ACTIVO"]==1?"ACTIVO":"INACTIVO").'</td>
					</tr>';		
				$usuarios->MoveNext();
				$d++;
			}
			?>
			<tr>
				<td colspan="10">&nbsp;</td>
			</tr>
		</table>
		<br>
		</form>
<?
}
layout_footer();
?>