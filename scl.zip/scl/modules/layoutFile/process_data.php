<?php
//ini_set('display_errors',1);
# Process_data File 
# @uthor Mark       

require_once("includes/includes.inc.php");
require_once("layoutFile.inc.php");

load_session();
$action = $_REQUEST['action'];
$header = "modules.php?mod=layoutFile&op=index";

if(isset($action) && $action == 1){ # INICIA EL SEGUIMIENTO A SOLICITUDES #
	
	$fecha_envio = $_REQUEST['fecha_envio'];
	$num_remesa = $_REQUEST['num_remesa'];
	$surveyid = $_REQUEST['surveyid'];
	$fecha1 = $_REQUEST['fecha1'];
	$fecha2 = $_REQUEST['fecha2'];

	/*if($_SESSION['s_campana_id'] == 210){
        print_r($_REQUEST);
        echo $registros_actualizados = set_file_clasified_data($fecha1, $fecha2, $surveyid, $num_remesa, $db, $fecha_envio);
        die();
    }*/
    $registros_actualizados = set_file_clasified_data($fecha1, $fecha2, $surveyid, $num_remesa, $db, $fecha_envio);
	$header = "modules.php?mod=cargaArchivo&op=subeArchivo&e=6&c=".$registros_actualizados;

    //print_r($_REQUEST);
	//die();
	header("location: ".$header);
	
} elseif (isset($action) && $action == 2){ #CONTROLADOR QUE REALIZA EL CAMBIO DE ESTADO DE LAS REMESAS
	
	$act = $_REQUEST['act'];
		
		if($act == 2){ ## CAMBIA EL ESTADO DE LAS REMESAS PRE - FACTURADAS

			foreach ($_POST as $v1 => $v2){
				$com = substr($v1,0,11);
				if($com == 'prefactura_'){
					$res = "'".substr($v1,11)."'";
					if($j == 0){
						$var .= $v2;
					}else{
						$var .= ','.$v2;
					}
					$j++;
				}
			}
			 
			$preFactura = $var;

			$num_factura = $_REQUEST['num_factura'];
			$fecha_factura = $_REQUEST['fecha_factura'];
			
			$rs = set_remesa_estatus($preFactura, $num_factura, $fecha_factura, $db);
			$existe_remesa = $rs->fields["REMESA"];
			$registros = $rs->fields["REGISTRO"];
			
			if($existe_remesa == 100){
				$valor = 'SE ACTUALIZARON '.$registros.' REGISTROS CON EXITO';
			}else if($existe_remesa == 200){
				$valor = 'NO SE ENCONTRARON REGISTROS EN BASE, INTENTE NUEVAMENTE!!!';
			}
			
		} else if($act == 3){ ## CAMBIA EL ESTADO DE LAS REMESAS A COBRADAS
				
			//print_r($_REQUEST);
			foreach ($_POST as $v1 => $v2){
				$com = substr($v1,0,8);
				if($com == 'factura_'){
					$res = "'".substr($v1,8)."'";
					if($j == 0){
						$v2_2 = explode('-', $v2);
						$var .= $v2_2[1];
						$surv .= $v2_2[0];
					}else{
						$v2_3 = explode('-', $v2);
						$var .= ','.$v2_3[1];
						$surv .= ','.$v2_3[0];
					}
					$j++;
				}
			}			
			
			$survey = $surv;
			$factura = $var;	
			$fecha_envio = $_REQUEST['fecha_envio'];
			$fecha_pago = $_REQUEST['fecha_pago'];
			
			$rs = set_remesa_estatus_co($factura, $fecha_envio, $fecha_pago, $surv, $db);
			$existe_remesa = $rs->fields["REMESA"];
			$registros = $rs->fields["REGISTRO"];
			
			if($existe_remesa == 100){
				$valor = 'SE ACTUALIZARON '.$registros.' REGISTROS CON EXITO';
			}else if($existe_remesa == 200){
				$valor = 'NO SE ENCONTRARON REGISTROS EN BASE, INTENTE NUEVAMENTE!!!';
			}
			
		} else if($act == 4){ #CAMBIA EL ESTADO DE LAS REMESAS A CANCELADAS O REEMBOLSADAS
			
			$folio = $_REQUEST['folio'];	
			$fecha_cance = $_REQUEST['fecha_cance'];
			$notaCredito = ($_REQUEST['notaCredito'] != ""?$_REQUEST['notaCredito']:0);

			$rs = set_remesa_estatus_ca_re($folio, $fecha_cance, $notaCredito, $db);
			$existe_remesa = $rs->fields["REMESA"];
			$registros = $rs->fields["REGISTRO"];
			
			if($existe_remesa == 100){
				$valor = 'SE ACTUALIZARON '.$registros.' REGISTROS CON EXITO';
			}else if($existe_remesa == 200){
				$valor = 'NO SE ENCONTRARON REGISTROS EN BASE, INTENTE NUEVAMENTE!!!';
			}
			
		} else if($act == 5 ) { ## CAMBIA EL ESTADO DE LAS REMESAS A REEMBOLSADAS (NOTA DE CREDITO)
			
			$num_credito = $_REQUEST['num_credito'];
			$fecha_credito = $_REQUEST['fecha_credito'];
			foreach ($_POST as $v1 => $v2){
				$com = substr($v1,0,8);
				if($com == 'factura_'){
					$res = "'".substr($v1,8)."'";
					if($j == 0){
						$var .= $v2;
					}else{
						$var .= ','.$v2;
					}
					$j++;
				}
			}
			$facturas = $var;
				
			$rs = set_remesa_reembolso($num_credito, $fecha_credito, $facturas, $db);
			$valor = 'SE ACTUALIZARON '.$rs->fields["REGISTRO"].' REGISTROS CON EXITO';
		
		} else if($act == 6 ) { ## ASIGNA PRECIOS A LAS SOLICITUDES
			
			$shot = $_REQUEST['shot'];	
			$porcentaje = $_REQUEST['porcentaje'];
			$rs = get_remesa_precios($shot, $porcentaje, $db);

			echo '
				<form name="frm1" method="POST" action="">
				<input type="hidden" value="'.$shot.'" name="shot" readonly>
				<table border="0">
					<tr>
						<td><b>Registros:<b></td>
						<td>'.$rs->fields['REGISTROS'].'</td>
					</tr><tr>
						<td><b>Contactos Efectivos:<b></td>
						<td>'.$rs->fields['CONTACTOS_EFECTIVOS'].'</td>
					</tr><tr>
						<td colspan="2">&nbsp;</td>
					</tr><tr>
						<td colspan="2">
							<table>
								<tr style="background-color:<'.getColor(0).';font-weight:bold;text-align:center">
									<td>Producto</td>
									<td>Ventas</td>
									<td>Precio</td>
								</tr><tr style="background-color:'.getColor(1).'" align="center">
										<td>SECURITY</td>
										<td>'.$rs->fields['VENTAS_SECURITY'].'</td>
										<td><input type="text" name="1_11_12" value="'.$rs->fields['PRECIO_SECURITY'].'" readonly size="6"></td>
								</tr><tr style="background-color:'.getColor(0).'" align="center">
										<td>SAFE</td>
										<td>'.$rs->fields['VENTAS_SAFE'].'</td>
										<td><input type="text" name="21" value="'.$rs->fields['PRECIO_SAFE'].'" readonly size="6"></td>
								</tr><tr style="background-color:'.getColor(1).'" align="center">
										<td>Combitos security</td>
										<td>'.$rs->fields['VENTAS_SEC_COM'].'</td>
										<td><input type="text" name="20" value="'.$rs->fields['PRECIO_SEC_COM'].'" readonly size="6"></td>
								</tr><tr style="background-color:'.getColor(0).'" align="center">
										<td>Combitos Safe Card</td>
										<td>'.$rs->fields['VENTAS_SC_COM'].'</td>
										<td><input type="text" name="22" value="'.$rs->fields['PRECIO_SC_COM'].'" readonly size="6"></td>
								</tr><tr style="background-color:'.getColor(1).'" align="center">
										<td>AP</td>
										<td>'.$rs->fields['VENTAS_AP'].'</td>
										<td><input type="text" name="13_14" value="'.$rs->fields['PRECIO_AP'].'" readonly size="6"></td>
								</tr><tr style="background-color:'.getColor(0).'" align="center">
										<td>Hospitalizacion</td>
										<td>'.$rs->fields['VENTAS_HOSPI'].'</td>
										<td><input type="text" name="3_7_8_9_10" value="'.$rs->fields['PRECIO_HOSPI'].'" readonly size="6"></td>
								</tr><tr style="background-color:'.getColor(1).'" align="center">
										<td>Cancer Integral</td>
										<td>'.$rs->fields['VENTAS_INTEGRAL'].'</td>
										<td><input type="text" name="5" value="'.$rs->fields['PRECIO_INTEGRAL'].'" readonly size="6"></td>
								</tr><tr style="background-color:'.getColor(0).'" align="center">
										<td>Cancer Femenino</td>
										<td>'.$rs->fields['VENTAS_FEMENINO'].'</td>
										<td><input type="text" name="4" value="'.$rs->fields['PRECIO_FEMENINO'].'" readonly size="6"></td>
								</tr><tr style="background-color:'.getColor(1).'" align="center">
										<td colspan="2">Factor</td>
										<td><input type="text" name="factor" value="'.$rs->fields['PORCENTAJE_TOTAL'].'" readonly size="6"></td>
								</tr>
							</table>
						</td>
					</tr>
			</table>';
			
			die();

		} else if($act == 7) { ## ASIGNA EL NUMERO DE PREFACTURA A LAS REMESAS APROBADAS
			
			$prefactura = $_REQUEST['prefactura'];
			$fecha_pref = $_REQUEST['fecha_pref'];
			
			
			foreach ($_POST as $v1 => $v2){
				$com = substr($v1,0,7);
				if($com == 'remesa_'){
					$res = "'".substr($v1,7)."'";
					if($j == 0){
						$var .= $v2;
					}else{
						$var .= ','.$v2;
					}
					$j++;
				}
			}
			$remesa = $var;

			$rs = set_remesa_prefactura($prefactura, $fecha_pref, $remesa, $db);
			$valor = 'SE ACTUALIZARON '.$rs->fields["REGISTRO"].' REGISTROS CON EXITO';
		}
			
		echo "<font color=\"red\"><h4><b>* ".$valor."</b></h4></font>";
	
} elseif (isset($action) && $action == 3) { ## CARGA EL ARCHIVO Y MUESTRA EL CONTENIDO DE LOS REGISTROS
		
		delete_from_remesas_full($db); 
		
		if ($_POST["action_val"] == "upload") {
		    $tamano = $_FILES["fichero"]['size'];
		    $tipo = $_FILES["fichero"]['type'];
		    $archivo = $_FILES["fichero"]['name'];
		    $prefijo = rand();

		    if ($archivo != "") {
		        $destino = "modules/Files_remesas/archivo_carga_full_".get_session_varname('s_campana_schema').".txt";
		        if (copy($_FILES['fichero']['tmp_name'], $destino)) {
					set_data_remesas_full();
					//$header = "modules.php?mod=cargaArchivo&op=subeArchivo&file=".encrypt($destino);
					$header = "modules.php?mod=cargaArchivo&op=subeArchivo";
		        } else {
		            $header = "modules.php?mod=cargaArchivo&op=subeArchivo&e=1";
		        }
		    } else {
				$header = "modules.php?mod=cargaArchivo&op=subeArchivo&e=2";
		    }
		}	

		header("location: ".$header);

} elseif (isset($action) && $action == 4){ ## CLASIFICA LA INFORMACION QUE SE CARGO EN EL ARCHIVO
		
		$num_gen = (isset($_REQUEST['num_gen']) && strlen($_REQUEST['num_gen']) > 1?$_REQUEST['num_gen']:'');
		$clasificacion = $_REQUEST['clasificacion'];
		$fec_gen = $_REQUEST['fec_gen'];
		$key = time();
		
		//echo  
		$clasifica_datos = set_data_clasification($clasificacion, $fec_gen, $num_gen, $key, $db);
		//die();
		if ($clasifica_datos <= 50000){
			$header = "modules.php?mod=cargaArchivo&op=subeArchivo&e=3&c=".$clasifica_datos."&ky=".$key;
		}else{
			 $header = "modules.php?mod=cargaArchivo&op=subeArchivo&e=4";
		}
		
		header("location: ".$header);
	
} elseif (isset($action) && $action == 5) { # DEVULVE LAS BUSQUEDAS DE LAS PREFACTURAS

		$act = $_REQUEST['act'];
?>
		<table border="0">
			<tr style="background-color:<?php echo getColor(0);?>;font-weight:bold" align="center">
				<td>Reg.</td>
				<td>Shot</td>
				<td># Remesa</td>
				<td>Producto</td>
				<td>Estatus</td>
				<td>Cantidad</td>
			</tr><tr>
<?
		if($act == 2 || $act == 5){
			
			$preFactura = $_REQUEST['preFactura'];
			$rs = get_preInvoice_data(1, $preFactura, $act, $db);
			if($rs->fields["REGISTROS"] >= 1){
				$i = 1;
				$rs1 = get_preInvoice_data(2, $preFactura, $act, $db);
				while(!$rs1->EOF){
					echo '<tr style="background-color:'.getColor($i).'" align="center">
								<td>'.$i.'&nbsp;&nbsp;</td>
								<td>'.$rs1->fields["SHOTID"].'&nbsp;&nbsp;</td>
								<td>'.$rs1->fields["REMESA"].'&nbsp;&nbsp;</td>
								<td>'.$rs1->fields["NAME"].'&nbsp;&nbsp;</td>
								<td>'.$rs1->fields["STATUS"] .'&nbsp;&nbsp;</td>
								<td>'.$rs1->fields["CANTIDAD"].'&nbsp;&nbsp;</td>
						  </tr>';
					$rs1->MoveNext();
					$i++;
				}
			} else {
				echo '<tr><td colspan="6"><font color="red" size="2"><b>No se encontraron registros</b></font></td></tr>';
			}
			
		} else if($act == 3) { ## Facturadas

			$factura = $_REQUEST['Factura'];
			$rs = get_preInvoice_data(1, $factura, $act, $db);
			if($rs->fields["REGISTROS"] >= 1){
				$i = 1;
				$rs1 = get_preInvoice_data(2, $factura, $act, $db);
				while(!$rs1->EOF){
					echo '<tr style="background-color:'.getColor($i).'" align="center">
						<td>'.$i.'&nbsp;&nbsp;</td><td>'.$rs1->fields["SHOTID"].'&nbsp;&nbsp;</td>
						<td>'.$rs1->fields["REMESA"].'&nbsp;&nbsp;</td><td>'.$rs1->fields["NAME"].'&nbsp;&nbsp;</td><td>'.$rs1->fields["STATUS"] .'&nbsp;&nbsp;</td><td>'.$rs1->fields["CANTIDAD"].'&nbsp;&nbsp;</td>
					</tr>';
					$rs1->MoveNext();
					$i++;
				}
			} else {
				echo '<tr><td colspan="6"><font color="red" size="2"><b>No se encontraron registros</b></font></td></tr>';
			}
		}
?>
			</tr>
		</table>
<?php
} elseif (isset($action) && $action == 6) { // EJECUTA CODIGO CUANDO EL ACTION = 6
	
		$act = $_REQUEST['act'];
		$folio = $_REQUEST['folio'];
		$rs = get_folio_data(1, $folio, $act, $db);
		if($rs->fields["REGISTROS"] >= 1){
?>
			<table border="0">
				<tr style="background-color:<?php echo getColor(0);?>;font-weight:bold" align="center">
					<td>Reg.</td>
					<td>Shot</td>
					<td># Remesa</td>
					<td>Cliente</td>
					<td>Producto</td>
					<td>Cuenta</td>
					<td>Estatus</td>
				</tr><tr>
					<?php 
						$i = 1;
						$rs1 = get_folio_data(2, $folio, $act, $db);
						while(!$rs1->EOF){
							echo '<tr style="background-color:'.getColor($i).'" align="center">
								<td>'.$i.'&nbsp;&nbsp;</td><td>'.$rs1->fields["SHOTID"].'&nbsp;&nbsp;</td>
								<td>'.$rs1->fields["REMESA"].'&nbsp;&nbsp;</td><td>'.$rs1->fields["CUSTOMERID"].'&nbsp;&nbsp;</td><td>'.$rs1->fields["SURVEYID"] .'&nbsp;&nbsp;</td><td>'.$rs1->fields["CUENTA"].'&nbsp;&nbsp;</td><td>'.$rs1->fields["STATUS"].'&nbsp;&nbsp;</td>
							</tr>';
							$rs1->MoveNext();
							$i++;
						}
					?>
				</tr>
			</table>
<?php
		}else{
			echo '<font color="red" size="2"><b>No se encontraron registros</b></font>';
		}
		
	} elseif (isset($action) && $action == 7) { ## GUARDA LOS PRECIOS DE CADA UNOS DE LOS PRODUCTOS
		
		$shot = $_REQUEST['shot'];
		$_1_11_12 = ($_REQUEST['1_11_12']!=""?$_REQUEST['1_11_12']:0);
		$_21 = ($_REQUEST['21']!=""?$_REQUEST['21']:0);
		$_20 = ($_REQUEST['20']!=""?$_REQUEST['20']:0);
		$_22 = ($_REQUEST['22']!=""?$_REQUEST['22']:0);
		$_13_14 = ($_REQUEST['13_14']!=""?$_REQUEST['13_14']:0);
		$_3_7_8_9_10 = ($_REQUEST['3_7_8_9_10']!=""?$_REQUEST['3_7_8_9_10']:0);
		$_5 = ($_REQUEST['5']!=""?$_REQUEST['5']:0);
		$_4 = ($_REQUEST['4']!=""?$_REQUEST['4']:0);
		$preFactura = $_REQUEST['preFactura'];
		$fecha_envio = $_REQUEST['fecha_envio'];
		$factor = $_REQUEST['factor'];
		
		$rs = set_precio_remesa_producto($shot, $_1_11_12, $_21, $_20, $_22, $_13_14, $_3_7_8_9_10, $_5, $_4, $preFactura, $fecha_envio,  $factor, $db);
		
		if($rs->fields["REGISTRO"] >= 1){
			$header = "modules.php?mod=cargaArchivo&op=subeArchivo.php?e=5";
		}else{
			$header = "modules.php?mod=cargaArchivo&op=subeArchivo.php?e=4";
		}
		
		header("location: ".$header);
		
	} elseif (isset($action) && $action == 8) { ## GUARDA LOS PRECIOS DE CADA UNOS DE LOS PRODUCTOS
	
		$tipoLayout = $_REQUEST['tipoLayout'];
		$mes = $_REQUEST['mes'];
		$header = "modules.php?mod=cargaArchivo&op=layout.php?file_name=".encrypt('prueba').'&mes='.$mes.'&tipoLayout='.$tipoLayout;
		header("location: ".$header);
	
	} elseif (isset($action) && $action == 9) { ## GENERA EL REPORTE DE CARGA
		
		$ky = $_REQUEST['ky'];
		$header = "modules.php?mod=cargaArchivo&op=reporteCarga&ky=".$ky;
		header("location: ".$header);
	
	}
?>