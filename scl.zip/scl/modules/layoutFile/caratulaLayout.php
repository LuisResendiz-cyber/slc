<?php
#CaratulaLayout File 
#@uthor Mark   

require_once("includes/includes.inc.php");
require_once("modules/layoutFile/layoutFile.inc.php");

load_session();
initialize("mesa_control","Busqueda de Clientes",$db);

get_header("Genera Layout");
get_menu($db);

$tipo_pago = (isset($_POST['tipo_pago'])?$_POST['tipo_pago']:0);
$surveyid = (isset($_POST['surveyid'])?$_POST['surveyid']:"");
$fecha1 = (isset($_POST['fecha1'])?$_POST['fecha1']:"");
$fecha2 = (isset($_POST['fecha2'])?$_POST['fecha2']:"");
//print_r($_SESSION);
?>
	<p class="textbold">Seguimiento &gt; Caratula</p><p>&nbsp;</p>
	<form name="frm1" method="post" action="modules.php?mod=layoutFile&op=process_data&action=1">
		<table class="text" border="0">
			<tr>
				<td colspan="2">
					<table border ="2">
						<tr style="background-color:<?=getColor(0)?>">
							<td align="center" colspan="2"><b>Selecci&oacute;n</b></td>
						</tr><tr style="background-color:<?=getColor(1)?>">
							<td align="center" colspan="2">
							<?
							if(get_session_varname('s_campana_schema') == 'acema'){?>
								<b>Filtro por metodo de pago:&nbsp;</b>
								<select name="tipo_pago" onChange="BusquedaFiltro()">
									<option value="0" <?=($tipo_pago == 0?" selected":"")?>></option>
									<option value="1" <?=($tipo_pago == 1?" selected":"")?>>Centro de Pagos</option>
									<option VALUE="2" <?=($tipo_pago == 2?" selected":"")?>>G PAY</option>
									<option value="3" <?=($tipo_pago == 3?" selected":"")?>>PROSA</option>
									<option value="4" <?=($tipo_pago == 4?" selected":"")?>>12 meses sin intereses</option>
									<option value="5" <?=($tipo_pago == 5?" selected":"")?>>UNICEF</option>
									

								</select>
							<?} else echo '&nbsp;'?>
							</td>
						</tr>
<?
						$i = 0;
						$rs = get_caratula_layout($fecha1, $fecha2, $surveyid, $db, 1, $tipo_pago);
						while(!$rs->EOF) {
							echo '<tr style="background-color:'.getColor($i).'">
									<td class="textright">
										<input type="checkbox" name="SolSel'.$i.'" value="'.$rs->fields["CUSTOMERID"].'-'.$rs->fields["SURVEYID"].'" checked onclick="return false;">
									</td><td>
										<b>'.$rs->fields["LAYOUT"].'</b>
									</td>
								</tr>';
							$rs->MoveNext();
							$i++;
						}
?>
						<tr>
							<td colspan="2"><b>Registros Encontrados:<?=$i?></b></td>
						</tr>
					</table>
				</td>
			</tr><tr>
				<td colspan="2">&nbsp;</td>
			</tr><tr>
				<td align="right" width="55%">
					<b>Campa&ntilde;a / Remesa #:</b>&nbsp;<input type="text" name="num_remesa" size="15" >&nbsp;&nbsp;&nbsp;&nbsp;
					<b>Fecha de envio:</b>
				</td><td>
					<script language="JavaScript">
						var SC_SET_1 = {'appearance': SC_APPEARANCE,'dataArea':'fecha_envio','dateFormat' : 'd/m/Y'}
						new sCalendar(SC_SET_1);
					</script>
				</td>
			</tr><tr>
				<td colspan="2" id="buttons">
					<br>
					<input type="button" value="Pantalla Anterior" onclick="GoBack()"/>&nbsp;&nbsp;
					<input type="button" value="Iniciar seguimiento" name="descarga" onclick="valida_seguimiento(<?=$t?>)">
				</td>
			</tr>
		</table>
		<input type="hidden" name="fecha1" value="<?=$fecha1?>">
		<input type="hidden" name="fecha2" value="<?=$fecha2?>">
		<input type="hidden" name="surveyid" value="<?=$surveyid?>">
		</form>
		<p>&nbsp;</p>
<?php 
get_footer();
?>