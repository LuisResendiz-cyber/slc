<?php
//ini_set('display_errors',1);
# Index File 
# @uthor Mark
# Generador de layouts

require_once("includes/includes.inc.php");
require_once("layoutFile.inc.php");

load_session();
initialize("mesa_control","Busqueda de Clientes",$db);

get_header("Genera archivo");
get_menu($db);

if(isset($_GET['action']) && $_GET['action'] > 0){
	$action_ = $_GET[action];
	if($action_ == 1){
		$error = "El archivo no se pudo generar, Intente nuevamente";
	}
	echo $error;
}else{
	//$act = desencrypt($_GET['act']);
    //print_r($_SESSION);
?>
	<form name="frm1" action="modules.php?mod=layoutFile&op=caratulaLayout" method="post">
	<table width="50%" border="0">
		<tr bgcolor="#a0a0a0">
			<td colspan="4" valign="top" align="center">
			  <font size="2" color="#000000" face="Comic Sans MS"><b>GENERACI&Oacute;N DE CARATULA</b></font>
			</td>
		
		</tr><tr>
			<td colspan ="4">&nbsp;</td>
		</tr><tr align="center">
			<td colspan="2"><b>Del:&nbsp;</b></td>
			<td colspan="2"><b>Al:&nbsp;</b></td>
		</tr><tr align="center">
			<td colspan="2">
				<script language="JavaScript">
					<!--		
					var SC_SET_1 = {'appearance': SC_APPEARANCE,'dataArea':'fecha1','dateFormat' : 'd/m/Y'}
					new sCalendar(SC_SET_1);
					//-->
				</script>
			</td>
			<td colspan="2">
				<script language="JavaScript">
					<!--
					var SC_SET_2 = {'appearance': SC_APPEARANCE,'dataArea':'fecha2','dateFormat' : 'd/m/Y'}
					new sCalendar(SC_SET_2);
					//-->
				</script>
			</td>
		</tr><tr align="center">
			<td colspan="4">&nbsp;</td>
		</tr><tr align="center">
			<td colspan="4">
				<b>Productos:&nbsp;</b>
				<select name="surveyid">
<?php
					$i = 0;
					$rs = get_productos($db);
					while(!$rs->EOF) {
						echo '<option value="'.$rs->fields["SURVEYID"].'"  >'.$rs->fields["NOMBRE"].'</option>';
						$rs->MoveNext();
						$i++;
					}
?>					
				</select>
			</td>
		</tr><tr align="left">
			<td colspan="4"><br>&nbsp;</td>
		</tr><tr>
			<td colspan="4">
				<input type="button" value="Pantalla Anterior" onclick="location.href='<?php echo $linkpath;?>index.php'"/>&nbsp;&nbsp;
				<input type="button" value="Mostrar Caratula" onclick="valida_caratula()">
			</td>
		</tr>
	</table>
</form>
<?php
}
get_footer();
?>