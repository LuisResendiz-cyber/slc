<?php
//ini_set('display_errors',1);
################# Funciones con llamada a BD ################

## MUESTRA LOS PRODUTOS POR CAMPA�A
function get_productos($conn){
	$rs = $conn->ExecuteCursor("BEGIN ".get_session_varname('s_campana_schema').".CSP_GETPRODUCTOS(1,:rc); END;", 'rc');
	$conn->SetFetchMode(ADODB_FETCH_BOTH);
	
	return $rs;
}

## MUESTRA LA CARATULA DEL LAYOUT
function get_caratula_layout($fecha1, $fecha2, $surveyid, $conn, $action, $tipo_pago){
	if($tipo_pago == 0){
		$store = 'CSP_GETDATOSLAYOUT_N';
	}else if($tipo_pago == 1){
		$store = 'CSP_GETDATOSLAYOUT11_N';
	}else if($tipo_pago == 2 || $tipo_pago == 3){
		$store = 'CSP_GETDATOSLAYOUT1_N';
	}else if($tipo_pago == 4){
		$store = 'CSP_GETDATOSLAYOUT12M_N';
	}else if($tipo_pago == 5){
		$store = 'CSP_GETDATOSLAYOUTUNICEF_N';
	}
	$rs = $conn->ExecuteCursor("BEGIN ".get_session_varname('s_campana_schema').".".$store."('".$fecha1."','".$fecha2."',".$surveyid.",".$tipo_pago.",".$action.",:rc); END;", 'rc');
	$conn->SetFetchMode(ADODB_FETCH_BOTH);
	
	return $rs;
}

## REGRESA EL VALOR DEL RFC, BILLACCOUNT Y SHOT
function get_rfc_data($customerid, $surveyid, $conn){
	$rs = $conn->ExecuteCursor("BEGIN ".get_session_varname('s_campana_schema').".CSP_GETDATOSRFC_N(".$customerid.",".$surveyid.", :rc); END;", 'rc');
	$conn->SetFetchMode(ADODB_FETCH_BOTH);
	
	return $rs;
}

## GUARDA LOS DATOS EN REMESAS_DATA_TEMP
function set_fallen($shot, $remesa, $customerid, $survey, $folio, $rfc, $cantidad, $prima, $conn){
	$rs = $conn->ExecuteCursor("BEGIN ".get_session_varname('s_campana_schema').".CSP_INSERTA_REMESAS_DATA('".$shot."','".$remesa."',".$customerid.",".$survey.",'".$folio."','".$rfc."',".$cantidad.",'".$prima."',:rc); END;", 'rc');
	$conn->SetFetchMode(ADODB_FETCH_BOTH);
	
	return $rs;
}

## INSERTA LOS REGISTROS EN REMESAS_N A PARTIR (CAIDOS Y ENVIADOS)
function update_remesas_n($num_remesa, $fecha_envio, $load_clasified, $conn){
	$rs = $conn->ExecuteCursor("BEGIN ".get_session_varname('s_campana_schema').".CSP_ACTUALIZA_REMESAS_N('".$fecha_envio."','".$num_remesa."','".$load_clasified."',:rc); END;", 'rc');
	$conn->SetFetchMode(ADODB_FETCH_BOTH);
	
	return  $rs->fields["REGISTROS"];	
}

## TRAE LOS DATOS DE ACUERDO AL ARCHIVO CARGADO
function get_data_by_file($rfc, $solicitud, $conn){
	//$rs = $conn->ExecuteCursor("BEGIN CSP_GETDATOSPORARCHIVO_N('".trim($rfc)."',".trim($solicitud).",:rc); END;", 'rc');
	$rs = $conn->ExecuteCursor("BEGIN ".get_session_varname('s_campana_schema').".CSP_GETDATOSPORARCHIVO_N(1,1,:rc); END;", 'rc');
	$conn->SetFetchMode(ADODB_FETCH_BOTH);
	
	return $rs;
}

## REGRESA LOS ESTADOS DISPONIBLES PARA CLASIFICAR LA INFORMACION
function get_ControllerStatus($status = 0,$conn){
	$rs = $conn->ExecuteCursor("BEGIN ".get_session_varname('s_campana_schema').".CSP_GETCONTROLLERSTATUS_N(".$status.",:rc); END;", 'rc');
	$conn->SetFetchMode(ADODB_FETCH_BOTH);
	
	return $rs;
}

## CLASIFICA LOS REGISTROS DE REMESA
function set_data_clasification($clasificacion, $fec_gen, $num_gen, $key, $conn){
	
	$cantidad = 0;
	$rs = $conn->ExecuteCursor("BEGIN ".get_session_varname('s_campana_schema').".CSP_SETDATACLASIFICATION_N(".$clasificacion.",'".$fec_gen."','".$num_gen."',".$key.",:rc); END;", 'rc');	
	$conn->SetFetchMode(ADODB_FETCH_BOTH);
	$cantidad = $rs->fields["REMESA"];

	/*$f = fopen($file, "r");
	while ($lines = fgets($f, 1000) ) {
		$line = explode("\|",trim($lines));
		if($clasificacion == 850){
			$rs = $conn->ExecuteCursor("BEGIN CSP_SETDATACLASIFICATION_N(".$clasificacion.",'".$fec_gen."','".$num_gen."','".$line[1]."',".$line[2].",'".$line[3]."','".$line[4]."','".$line[5]."',".$line[6].",'".$line[7]."','".$line[8]."','".$line[9]."',".$key.",:rc); END;", 'rc');
		}else{
			$rs = $conn->ExecuteCursor("BEGIN CSP_SETDATACLASIFICATION_N(".$clasificacion.",'".$fec_gen."','".$num_gen."','".$line[1]."',".$line[2].", '', '', '".$line[3]."', '', '', '', '',".$key.", :rc); END;", 'rc');
		}
		
		$conn->SetFetchMode(ADODB_FETCH_BOTH);
		
		if($rs->fields["REMESA"] > 0){
			$cantidad += 1;
		}
	}
	fclose($f);*/
	
	return $cantidad;
}

## ACTUALIZA EL CAMPO DE PREFACTURA  DE LOS REGISTROS APROBADOS
function set_remesa_prefactura($prefactura, $fecha_pref, $remesa, $conn){
	$rs = $conn->ExecuteCursor("BEGIN ".get_session_varname('s_campana_schema').".CSP_SETREMESAPREFACTURADO('".$prefactura."','".$fecha_pref."','".$remesa."',:rc); END;", 'rc');
	$conn->SetFetchMode(ADODB_FETCH_BOTH);

	return $rs;
}

## Actualiza el status de las remesas a facturadas
function set_remesa_estatus($preFactura, $num_factura, $fecha_factura, $conn){
	$rs = $conn->ExecuteCursor("BEGIN ".get_session_varname('s_campana_schema').".CSP_SETREMESASESTATUS_N('".$preFactura."',".$num_factura.",'".$fecha_factura."',:rc); END;", 'rc');
	$conn->SetFetchMode(ADODB_FETCH_BOTH);
	
	return $rs;
}

## Actualiza el status de las remesas a cobradas
function set_remesa_estatus_co($factura, $fecha_envio, $fecha_pago, $surv, $conn){
	
	$rs = $conn->ExecuteCursor("BEGIN ".get_session_varname('s_campana_schema').".CSP_SETREMESASESTATUS_CO_N('".$factura."','".$fecha_envio."','".$fecha_pago."','".$surv."',:rc); END;", 'rc');
	$conn->SetFetchMode(ADODB_FETCH_BOTH);
	
	return $rs;
}

## ACTUALIZA EL STATUS DE LAS REMESAS A CANCELADAS O REEMBOLSADAS
//set_remesa_estatus_ca_re
function set_remesa_reembolso($num_credito, $fecha_credito, $facturas, $conn){
	$rs = $conn->ExecuteCursor("BEGIN ".get_session_varname('s_campana_schema').".CSP_SETREMESASESTATUS_CO_RE_N(".$num_credito.",'".$fecha_credito."','".$facturas."',:rc); END;", 'rc');
	$conn->SetFetchMode(ADODB_FETCH_BOTH);

	return $rs;
}

#-- Actualiza el status de las remesas a canceladas o reembolsadas
function set_remesa_estatus_apro($shot, $preFactura, $fecha_aprobada, $conn){
	$rs = $conn->ExecuteCursor("BEGIN ".get_session_varname('s_campana_schema').".CSP_SETREMESASESTATUS_APRO('".$preFactura."','".$shot."','".$fecha_aprobada."',:rc); END;", 'rc');
	$conn->SetFetchMode(ADODB_FETCH_BOTH);

	return $rs;
}

## REGRESA EL RS DE LOS FACTURADOS Y PRE FACTURADOS
function get_preInvoice_data($action, $preFactura, $option, $conn){
	$rs = $conn->ExecuteCursor("BEGIN ".get_session_varname('s_campana_schema').".CSP_GETPREFACTURA_N('".$preFactura."',".$action.",".$option.",:rc); END;", 'rc');
	$conn->SetFetchMode(ADODB_FETCH_BOTH);
	
	return $rs;
}

## REGRESA LA INFORMACION PARA ARMA EL LAYOUT DE DESCARGA
function get_data_file_to_download($customerid, $producto, $conn){
	$rs = $conn->ExecuteCursor("BEGIN ".get_session_varname('s_campana_schema').".CSP_GETDATOSSOLICITUD_N(".$customerid.",".$producto.",:rc); END;", 'rc');
	$conn->SetFetchMode(ADODB_FETCH_BOTH);
		
	return $rs;
}


## DEVUELVE EL PRECIO QUE SE VA A GENERAR PARA LOS DISTINTOS PRODUCTOS
function get_remesa_precios($shot, $porcentaje, $conn){
	$rs = $conn->ExecuteCursor("BEGIN ".get_session_varname('s_campana_schema').".CSP_SETPRECIOREMESA('".$shot."','".$porcentaje."',:rc); END;", 'rc');
	$conn->SetFetchMode(ADODB_FETCH_BOTH);

	return $rs;
}

## ACTUALIZA EL PRECIO DE LOS PRODUCTOS EN LA TABLA DE REMESAS_N
function set_precio_remesa_producto($shot, $_1_11_12, $_21, $_20, $_22, $_13_14, $_3_7_8_9_10, $_5, $_4, $preFactura, $fecha_envio,  $factor,  $conn){
	$rs = $conn->ExecuteCursor("BEGIN ".get_session_varname('s_campana_schema').".CSP_SETPRECIOREMESAPROD('".$shot."', '".$_1_11_12."', '".$_21."', '".$_20."', '".$_22."', '".$_13_14."', '".$_3_7_8_9_10."', '".$_5."', '".$_4."', '".$preFactura."', '".$fecha_envio."','".$factor."',:rc); END;", 'rc');
	$conn->SetFetchMode(ADODB_FETCH_BOTH);

	return $rs;
}

## REGRESA LOS SHOT DE LAS DISTINTAS ZONAS DISPONIBLES PARA APROBAR
function get_shot_zonas($val, $conn){
	$rs = $conn->ExecuteCursor("BEGIN ".get_session_varname('s_campana_schema').".CSP_GETSHOTZONAS(".$val.",:rc); END;", 'rc');
	$conn->SetFetchMode(ADODB_FETCH_BOTH);
	
	return $rs;
}

#--Regresa la informacion referente al domicilio
function get_domiciliocompleto($codigo, $municipio, $estado, $conn){
	$rs = $conn->ExecuteCursor("BEGIN ".get_session_varname('s_campana_schema').".CSP_GETDOMICILIOCOMPLETO(".$codigo.",".$municipio.",".$estado.",:rc); END;", 'rc');
	$conn->SetFetchMode(ADODB_FETCH_BOTH);
	
	return $rs;
}

#-- Regresa la informacion para arma el layout de descarga
function get_datosBD($customerid, $conn){
	$rs = $conn->ExecuteCursor("BEGIN ".get_session_varname('s_campana_schema').".GET_DATOSBD(".$customerid.",:rc); END;", 'rc');
	$conn->SetFetchMode(ADODB_FETCH_BOTH);
		
	return $rs;
}

function get_datos_layout_remesas($mes, $tipoLayout ,$conn){
	$rs = $conn->ExecuteCursor("BEGIN ".get_session_varname('s_campana_schema').".CSP_GETDATOSLAYOUT_REMESAS(".$mes.",".$tipoLayout.",:rc); END;", 'rc');
	$conn->SetFetchMode(ADODB_FETCH_BOTH);
		
	return $rs;

}

## DEVUELVE EL REPORTE DE LA CARGA
function get_rerporte_carga($ky, $conn){
	$rs = $conn->ExecuteCursor("BEGIN ".get_session_varname('s_campana_schema').".CSP_GETREPORTE_CARGA(".$ky.",:rc); END;", 'rc');
	$conn->SetFetchMode(ADODB_FETCH_BOTH);
		
	return $rs;
}

#-- Devuelve el siguiente valor de el numero de remesa
function get_remesa_nextval($conn){
	$stmt = "SELECT MAX(REMESAID) AS NEXTVAL FROM ".get_session_varname('s_campana_schema').".REMESAS_N";
	$conn->SetFetchMode(ADODB_FETCH_ASSOC);
	$rs = $conn->Execute($stmt);
	if($rs->fields["NEXTVAL"] != 0){
		return $rs->fields["NEXTVAL"];
	}else{
		return 2220;
	}
}

## ELIMINA LOS REGISTROS QUE SE ENCUENTRAN EN LA TABLA DE REMESAS_DATA_TEMP
function delete_from_remesas_full($conn){
	$sql = "DELETE FROM ".get_session_varname('s_campana_schema').".REMESAS_CARGA_FULL";
	if ($conn->Execute($sql) === false) 
		return false;
	else
		return true;
}


## ELIMINA LOS REGISTROS QUE SE ENCUENTRAN EN LA TABLA DE REMESAS_DATA_TEMP
function delete_from_remesas_temp($conn){
	$sql = "DELETE FROM ".get_session_varname('s_campana_schema').".REMESAS_DATA_TEMP";
	if ($conn->Execute($sql) === false) 
		return false;
	else
		return true;
}

################# Funciones sin llamada a BD ################

## INICIA EL SEGUIMIENTO DE LAS SOLICITUDES EN BD
function set_file_clasified_data($fecha1, $fecha2, $surveyid, $num_remesa, $conn, $fecha_envio){

	delete_from_remesas_temp($conn);

	$customer_string_array = explode(",", get_survey_or_customer_string(1));
	$survey_string_array = explode(",", get_survey_or_customer_string(2));

	for($t = 1; $t <= count($customer_string_array) - 1; $t++){
		$rs_rfc = get_rfc_data($customer_string_array[$t], $survey_string_array[$t], $conn);
		set_fallen($rs_rfc->fields["SHOTID"], $num_remesa, $customer_string_array[$t], $survey_string_array[$t], $rs_rfc->fields["BILLACCOUNT"], $rs_rfc->fields["RFC"], $rs_rfc->fields["CANTIDAD"], $rs_rfc->fields["PRIMA"], $conn);
	}

	$cantidad = update_remesas_n($num_remesa, $fecha_envio, '2222', $conn);

	return $cantidad;
}

##---------- PREPARA EL ARCHIVO PARA DESCARGAR LAYOUT
function set_file_to_download_layout($customer_string, $survey_string, $zona_string, $destino){
	$customer = explode(",", $customer_string);
	$survey = explode(",", $survey_string);
	$zona = explode(",", $zona_string);
	$outputFile = "";
	$myfile = fopen($destino, "w") or die("Can not open file");
	for($r = 1; $r <= count($customer)-1; $r++){
		$outputFile .= $customer[$r].",".$survey[$r].",".$zona[$r]."\r\n";
	}
	fputs($myfile, $outputFile);
	fclose($myfile);
}

## DEVUELVE EL RAMO PARA CADA UNOS DE LOS DISTINTOS PRODUCTOS
function get_ramo($surveyid){
	$ramo = "";
	if($surveyid == 1 || $surveyid == 11 || $surveyid == 12){
		$ramo .= "0074";
	}else if ($surveyid == 2){
		$ramo .= "0026";
	}else if ($surveyid == 3 || $surveyid == 7 || $surveyid == 8 || $surveyid == 9 || $surveyid == 10){
		$ramo .= "0092";
	}else if ($surveyid == 4){
		$ramo .= "0091";
	}else if ($surveyid == 5){
		$ramo .= "0090";
	}else if ($surveyid == 13){
		$ramo .= "0003";
	}else if ($surveyid == 21){
		$ramo .= "0080";
	}else if ($surveyid == 22){
		$ramo .= "0081";
	}

	return $ramo;
}

## REGRESA EL NOMBRE DEL ARCHIVO DONDE SE GUARDARAN LOS REGISTROS DEL LAYOUT-- QUITAR
function get_file_name($num_remesa, $fecha_envio, $ly, $surveyid, $ramo){
	if($ly == 7){
		$File_name = "Inicial_OUT_9012_".$ramo."_".get_now_int()."_".$num_remesa.'.txt';
	}else{
		$File_name = "Final_OUT_9012_".$ramo."_".get_now_int()."_".$num_remesa.'.txt';
	}
	return $File_name;
}

## REGRESA LOS REGISTROS ENCONTRADOS (1 => CUSTOMER, 2 => SURVEY, 3=> ZONAS) 
function get_survey_or_customer_string($type){
	$complemento = "0";
	$solicitud = '';
	$survey ='';
	$zona = '';
	foreach ($_POST as $v1 => $v2){
		$com = substr($v1,0,6);
		if($com == 'SolSel'){
			$sol_sur_array = explode( "-", $v2);
			for($x = 0; $x <= count($sol_sur_array)-1; $x++){
				if($x == 0)
					$solicitud.= ','.$sol_sur_array[$x];
				else if ($x == 1)
					$survey .= ','.$sol_sur_array[$x];
				else if ($x == 2)
					$zona .= ','.$sol_sur_array[$x];
			}
		}
	}
	
	if($type == 1)
		return $complemento.$solicitud;
	else if($type == 2)
		return $complemento.$survey;
	else if($type == 3)
		return $complemento.$zona;
}

## CARGA EL CONTENIDO DEL ARCHIVO EN BASE DE DATOS
function set_data_remesas_full(){

	if($_SERVER["SERVER_ADDR"] == '172.20.1.79' || $_SERVER["SERVER_ADDR"] == '172.20.1.51'){
		$arhivo = realpath(set_ctl_file('_lx'));
		$path = realpath('modules/Files_remesas/carga_datos_'.get_session_varname('s_campana_schema').'.sh');
		$comando = 'sh '.$path;
		$salida = shell_exec($comando);
		echo "<pre>$salida</pre>";
	}else{
		$arhivo = realpath(set_ctl_file('_ws'));
		$comando = 'sqlldr '.get_session_varname('s_campana_schema').'@develop/ace1rp3f control='.$arhivo.' rows=100000';
		//die();
		$salida = exec($comando);
	}
	//die();
}

## ARMA EL ARCHIVO CTL
function set_ctl_file($sys){

	$ctl_file = 'modules/Files_remesas/load_data_'.get_session_varname('s_campana_schema').$sys.'.ctl';
	$path_file =  realpath('modules/Files_remesas');
	
	if($_SERVER["SERVER_ADDR"] == '172.20.1.79' || $_SERVER["SERVER_ADDR"] == '172.20.1.51'){
		$content = "LOAD DATA\nINFILE '".$path_file."/archivo_carga_full_".get_session_varname('s_campana_schema').".txt'\nINTO TABLE REMESAS_CARGA_FULL\nAPPEND\nFIELDS TERMINATED BY '|' OPTIONALLY ENCLOSED '\"'\n(STATUS,RFC,CUSTOMERID,FECHA,CANCELACIONID,CAUSAID,SURVEYID)";
	}else{
		$content = "LOAD DATA\nINFILE '".$path_file."\archivo_carga_full_".get_session_varname('s_campana_schema').".txt'\nINTO TABLE REMESAS_CARGA_FULL\nAPPEND\nFIELDS TERMINATED BY '|' OPTIONALLY ENCLOSED '\"'\n(STATUS,RFC,CUSTOMERID,FECHA,CANCELACIONID,CAUSAID,SURVEYID)";
	}
	
	$file_handle = fopen($ctl_file, 'w') or die("No se pudo abrir el archivo"); 
	fwrite($file_handle, $content);
	fclose($file_handle);
	
	return $ctl_file;
}

/*function set_data_remesas_full(){
	$arhivo =  realpath('modules/Files_remesas/load_data.ctl');
 	$comando = 'sqlldr acema@develop/ace1rp3f control='.$arhivo.' rows=100000';
	exec($comando);
}*/
