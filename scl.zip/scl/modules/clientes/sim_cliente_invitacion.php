<?php
require_once("../includes/includes.inc.php");
require_once("clientes.inc.php");
$sim_datos='';
$mas_48="NO";

/*******************/
/*sim_cliente File */
/*@uthor Mark      */
/*******************/

$action = $_REQUEST["action"]; 

initialize("clientes","Busqueda de Clientes");

$statement = get_cliente_by_folio(get_varname_session("folio_cliente"));
$cliente = get_row($statement);
if($action == 1){
	$capital = $_REQUEST["capital1"];
	$pago = $_REQUEST["pago_mens"];
}else if ($action == 2){
	$capital = convert_to_money($cliente[47]);
	$pago=0;
	$pago_final=0;
	$num_pago=0;
}

$tipo = (isset($cliente[16])?$cliente[16]:"");
$saldo_tipo = $capital;


	$plazo = 48;
	$tasa = 13.0;
	
$porcentaje_pago_mensual = $pago / $capital;

$suma_pago_fijo_mensual =0;
$suma_interes_mensual = 0;
$suma_capital_amortizado = 0;
$suma_interes_mas_capital = 0;
$suma_iva_interes = 0;
$suma_mensual_con_iva = 0;


$planes_arr = get_varname_session("planes");



echo "<script>
	
	function RegresaBusqueda(){
		document.location = '{$linkpath}clientes/process_data.php?action=2';
	}
	
	function Guardar(){
	if(document.fmr2.mas_48.value == 'SI'){
			alert('El plazo es superior a 48 mensualidades, debe recalcular el pago');
	}else{
		var product = document.getElementById(\"product\").value;
		var last4 = document.getElementById(\"last4\").value;
		var capital = document.getElementById(\"capital\").value;
		document.fmr2.capital1.value = withoutdecimal(document.fmr2.capital1.value);
		y = withoutdecimal(capital);
		
		if(last4 != \"\" && capital != \"\"){
		//if(product != \"\" && last4 != \"\" && capital != \"\"){
			//document.getElementById(\"fmr_2\").action = '{$linkpath}clientes/process_data.php';
			document.fmr2.action = '{$linkpath}clientes/process_data.php';	
			document.fmr2.action.value = 3;";
			echo "document.fmr2.estatus_tdc.value = 1;
			document.fmr2.submit();
		}else
			alert('Existen campos vacios')
	}
	}

	function Recalcular(value){
		var capital = document.getElementById(\"capital\").value;
		y = withoutdecimal(capital);
		var pago2 = document.fmr2.pago_mens.value;
		z = withoutdecimal(pago2);
		
		if(capital != \"\"){
			if (z > 0){ 
			document.getElementById(\"capital1\").value = y;
			document.fmr2.action.value = 1;
			document.fmr2.submit();
			}else{
				alert(\"El campo de Pago no puede estar vacio\");
				return false;
			}
		}else{
			alert(\"El campo de Saldo no puede estar vacio\");
			return false;
		}
	}
	
	function withoutdecimal(valor){
		capital = valor.replace(\",\", \"\");
		return capital; 
	}
	
	function pulsar(e) {
  		tecla = (document.all) ? e.keyCode :e.which;
  		return (tecla!=13);
	} 
	
</script>
		<form method=\"post\" action=\"{$linkpath}clientes/sim_cliente_invitacion.php\" name=\"fmr2\" id=\"fmr_2\">
";

//layout_menu();
layout_menu($db);
if($action == 1){			
			$num_pago = 1;
			$plazo_1 = 48;
			$saldo=$capital;
			while($saldo > 0){
			if ($num_pago == 50 && $saldo>0){
				?>
				<script>
					alert('La deuda debe refinanciarse en un plazo menor a 48 meses, se debe aumentar el importe');
				</script>
				<?
				$mas_48="SI";
				break;
			}
				$tasa_mensual = $tasa / 12;
				$pago_fijo_mensual = $pago;
				$saldo = ($num_pago==1?$capital:$saldo - $capital_amortizado);			
				$interes_mensual = ($tasa_mensual * $saldo)/100;
				if ($pago_fijo_mensual>=$saldo){
					$pago_fijo_mensual=$saldo + $interes_mensual;
				}
				$capital_amortizado = $pago_fijo_mensual - $interes_mensual;
				$interes_mas_capital = $interes_mensual + $capital_amortizado;
				$iva_interes = $interes_mensual * .15;
				$mensual_con_iva = $pago_fijo_mensual + $iva_interes;
				//if($num_pago <= $plazo){
				if($saldo >= 1){
					if($num_pago <= $plazo_1){
						$suma_pago_fijo_mensual += $pago_fijo_mensual;
						$suma_interes_mensual += $interes_mensual;
						$suma_capital_amortizado += $capital_amortizado;
						$suma_interes_mas_capital += $interes_mas_capital;
						$suma_iva_interes += $iva_interes;
						$suma_mensual_con_iva += $mensual_con_iva;
					}
				}
				$sim_datos=$sim_datos."<tr><td>".$num_pago."</td><td>".get_money_format($saldo,2)."</td><td><center>".get_money_format($capital_amortizado,2)."</center></td><td><center>".get_money_format($interes_mensual,2)."</center></td><td><center>".get_money_format($pago_fijo_mensual,2)."<center></td><td><center>".get_money_format($iva_interes,2)."</center></td><td><center>".get_money_format($mensual_con_iva,2)."</center></td></tr>";									
				$num_pago=$num_pago+1;
			}
			$pago_final=$suma_mensual_con_iva/($num_pago-2);
}
			

echo "<p class=\"textbold\">Clientes &gt; Simulador</p><p>&nbsp;</p>
			<input type=\"hidden\" value=\"\" name=\"action\">
			<input type=\"hidden\" value=\"".$mas_48."\" name=\"mas_48\">
			<input type=\"hidden\" value=\"12\" name=\"plan_index\">
			<input type=\"hidden\" value=\"".$capital."\" name=\"capital1\" id=\"capital1\">
			<input type=\"hidden\" value=\".$plazo.\" name=\"plazo\" id=\"plazo\">
			<input type=\"hidden\" value=\"100\" name=\"porc_pago\" id=\"porc_pago\">
			<input type=\"hidden\" value=\"\" name=\"estatus_tdc\" id=\"estatus_tdc\">
			
			<table class=\"text\" border=\"0\">
				<tr>
					<td class=\"textright\"><b>Cliente:&nbsp;</b></td><td><p>".$cliente[3]." ".$cliente[4]." ".$cliente[5]."</p></td>
				</tr><tr>
					<td class=\"textright\"><b>Producto (TDC):&nbsp;</b></td><td><p><input type=\"text\" value=\"".(isset($cliente[18])?$cliente[18]:"")."\" size=\"15\" name=\"product\" id=\"product\"></p></td>
				</tr><tr>
					<td class=\"textright\"><b>Terminacion:&nbsp;</b></td><td><p><input type=\"text\" value=\"".(isset($cliente[29])?$cliente[29]:"")."\" maxlength=\"4\" size=\"3\" name=\"last4\" id=\"last4\"></p></td>
				</tr><tr>
					<td> &nbsp;</td>
				</tr>
			</table>
			
			<table border=\"0\" width=\"45%\">
<tr>
					<td class=\"textleft\"><b>Saldo:</b>&nbsp;</td>
					<td><input type=\"text\" name=\"capital\" value=\"".get_money_format($capital,2)."\" size=\"6\" id=\"capital\" onkeypress=\"return pulsar(event)\"></td>
					<td class=\"textleft\"><b>Tasa:</b>&nbsp;</td>
					<td>".$tasa."%</td>
				</tr><tr>
					<td class=\"textleft\"><b>Pago:</b></td>
					<td><input type=\"text\" name=\"pago_mens\" value=\"".$pago."\" size=\"6\" id=\"capital\" onkeypress=\"return pulsar(event)\"></td>
					<td class=\"textleft\"><b>% de pago mensual:</b>&nbsp;</td>
					<td class=\"textleft\">".number_format($porcentaje_pago_mensual * 100)."%</td>
				</tr>";
			//for($num_pago = 1; $num_pago <= ($plazo+1); $num_pago++){
	echo "<tr>
					<td class=\"textleft\"><b>Pago Mensual c/ IVA:</b></td>
					<td class=\"textleft\"><b>".get_money_format($pago_final,2)."<b>
								<input type=\"hidden\" value=\"".$pago_final."\" name=\"pago_final\" id=\"pago_final\">
</td>
					<td class=\"textleft\"><b>N�mero de Mensualidades:</b></td>
					<td class=\"textleft\"><b>".($num_pago-2)."<b></td>
				</tr><tr>
					<td class=\"textleft\" colspan=\"4\"><input type=\"button\" value=\"Recalcular\" onclick=\"Recalcular(1)\"/></td>
				</tr>
			</table>
			<br><br>
			<table border=\"0\" width=\"70%\" id=\"sim\">
				<tr bgcolor=\"gray\">
					<td class=\"textleft\">&nbsp;</td>
					<td class=\"textleft\">&nbsp;</td>
					<td colspan=\"5\"><center><b>Pago Mensual</b>&nbsp;<center></td>
				</tr><tr bgcolor=\"gray\">
					<td class=\"textleft\"><b>N� Pago</b>&nbsp;</td>
					<td><center><b>Saldo</b>&nbsp;</center></td>
					<td><center><b>Capital Amortizado</b>&nbsp;</center></td>
					<td><center><b>Interes Mensual</b>&nbsp;</center></td>
					<td><center><b>Pago Fijo Mensual</b>&nbsp;</center></td>
					<td><center><b>Iva</b>&nbsp;</center></td>
					<td><center><b>Mensual con Iva</b>&nbsp;</center></td>
				</tr>";
if($action==1){
			
			echo $sim_datos."<tr><td><b>TOTAL</b></td><td>&nbsp;</td><td><center><b>".get_money_format($suma_capital_amortizado,2)."</b><center></td><td><center><b>".get_money_format($suma_interes_mensual,2)."</b></center></td><td><center><b>".get_money_format($suma_pago_fijo_mensual,2)."</b></center></td><td><center><b>".get_money_format($suma_iva_interes,2)."</b></center></td><td><center><b>".get_money_format($suma_mensual_con_iva,2)."</b></center></td></tr></table>
			<br><br>
			<script>
				document.fmr2.plazo.value=".($num_pago-2)."
			</script>";
			 
			echo "<table>
					<tr>
						<td>&nbsp;</td>
					</tr><tr>";

				echo "<td><b>% Monto pendiente</b></td><td>".number_format(($saldo/$capital)*100)." %</td>
					</tr><tr>
						<td><b>Monto pendiente de pago</b></td><td>$".get_money_format($saldo,0)."</td>
					</tr>";
echo "</table></form>
	  <p>&nbsp;</p>
	  <input type=\"button\" value=\"Cancelar\" onclick=\" RegresaBusqueda()\"/>
	  &nbsp;&nbsp;
	  <input type=\"button\" value=\"Guardar\" onclick=\"Guardar()\"/>";
}

layout_footer();
?>