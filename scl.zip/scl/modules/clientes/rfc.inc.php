<?php

function rfc($plastname,$mlastname,$name,$date){
	$plastname = rfc_filter(rfc_text($plastname));
	$mlastname = rfc_filter(rfc_text($mlastname));
	$name = rfc_text($name);
	if($mlastname == "")$mlastname = substr($plastname,0,1);

	$rfc = substr($plastname,0,1);

	for($i = 0; $i < strlen($plastname);++$i)if(rfc_vowel(substr($plastname,$i,1))){
		$rfc .= substr($plastname,$i,1);
		break; 
	}

	$rfc .= substr($mlastname,0,1);

	$names = explode(" ",$name);
	if(count($names) > 1 && ($names[0] == "JOSE" || $names[0] == "MARIA" || $names[0] == "MA." || $names[0] == "MA"))$rfc .= substr($names[1],0,1);
	else $rfc .= substr($names[0],0,1);  

	$invalid = array("BUEI" => "BUEX","BUEY" => "BUEX","CACA" => "CACX","CACO" => "CACX","CAGA" => "CAGX",
							"CAGO" => "CAGX","CAKA" => "CAKX","CAKO" => "CAKX","COGE" => "COGX","COJA" => "COJX",
							"KOGE" => "KOGX","KOJO" => "KOJX","KAKA" => "KAKX","KULO" => "KULX","MAME" => "MAMX",
							"MAMO" => "MAMX","MEAR" => "MEAX","MEAS" => "MEAX","MEON" => "MEOX","MION" => "MIOX",
							"COJE" => "COJX","COJI" => "COJX","COJO" => "COJX","CULO" => "CULX","FETO" => "FETX",
							"GUEY" => "GUEX","JOTO" => "JOTX","KACA" => "KACX","KACO" => "KACX","KAGA" => "KAGX",
							"KAGO" => "KAGX","MOCO" => "MOCX","MULA" => "MULX","PEDA" => "PEDX","PEDO" => "PEDX",
							"PENE" => "PENX","PUTA" => "PUTX","PUTO" => "PUTX","QULO" => "QULX","RATA" => "RATX");

	if(isset($invalid[$rfc]))$rfc = $invalid[$rfc];

	//$rfc .= substr($date,2,6);
	$rfc .= substr($date,-2,2).substr($date,-7,2).substr($date,-10,2);

	$table1 = array("&" => "10","Ñ" => "10","A" => "11","B" => "12","C" => "13","D" => "14",
						"E" => "15","F" => "16","G" => "17","H" => "18","I" => "19","J" => "21",
						"K" => "22","L" => "23","M" => "24","N" => "25","O" => "26","P" => "27",
						"Q" => "28","R" => "29","S" => "32","T" => "33","U" => "34","V" => "35",
						"W" => "36","X" => "37","Y" => "38","Z" => "39","0" => "0","1" => "1",
						"2" => "2","3" => "3","4" => "4","5" => "5","6" => "6","7" => "7","8" => "8","9" => "9");

	$fullname = "{$plastname} {$mlastname} {$name}";
	$fullname_table1 = "0";
	$fullname_sum = 0;
	for($i = 0;$i < strlen($fullname);++$i){
		if(isset($table1[substr($fullname,$i,1)]))$fullname_table1 .= $table1[substr($fullname,$i,1)];
		else $fullname_table1 .= "00";		
	}
	for($i = 0;$i < strlen($fullname_table1) - 1;++$i)$fullname_sum += (substr($fullname_table1,$i,1) * 10 + substr($fullname_table1,$i + 1,1)) * substr($fullname_table1,$i + 1,1);

	$table2 = array("0" => "1","1" => "2","2" => "3","3" => "4","4" => "5","5" => "6","6" => "7",
						"7" => "8","8" => "9","9" => "A","10" => "B","11" => "C","12" => "D","13" => "E",
						"14" => "F","15" => "G","16" => "H","17" => "I","18" => "J","19" => "K","20" => "L",
						"21" => "M","22" => "N","23" => "P","24" => "Q","25" => "R","26" => "S","27" => "T",
						"28" => "U","29" => "V","30" => "W","31" => "X","32" => "Y");

	$digit0 = $fullname_sum % 1000;
	$digit0 = ($digit0 - ($digit1 = $digit0 % 34)) / 34;
	$rfc .= isset($table2[$digit0]) ? $table2[$digit0] : "Z";
	$rfc .= isset($table2[$digit1]) ? $table2[$digit1] : "Z";

	$table3 = array("A" => "10","B" => "11","C" => "12","D" => "13","E" => "14","F" => "15","G" => "16",
						"H" => "17","I" => "18","J" => "19","K" => "20","L" => "21","M" => "22","N" => "23",
						"O" => "25","P" => "26","Q" => "27","R" => "28","S" => "29","T" => "30","U" => "31",
						"V" => "32","W" => "33","X" => "34","Y" => "35","Z" => "36","0" => "0","1" => "1",
						"2" => "2","3" => "3","4" => "4","5" => "5","6" => "6","7" => "7","8" => "8",
						"9" => "9","" => "24"," " => "37");

	$rfc_table3 = 0;
	for($i = 0;$i < strlen($rfc);++$i)if(isset($table3[substr($rfc,$i,1)]))$rfc_table3 += $table3[substr($rfc,$i,1)] * (13 - $i); 
	if($rfc_table3 % 11 == 0)$rfc .= "0";
	else{
		$rfc_table3 = 11 - ($rfc_table3 % 11);
		if($rfc_table3 == 10)$rfc .= "A";
		else $rfc .= $rfc_table3;
	}

	return substr($rfc,0,10);	
}

function rfc_text($string){
	$string = str_replace(array("�","�","�","�","�"),array("A","E","I","O","U"),mb_strtoupper(trim($string),"UTF-8"));
	if(substr($string,0,2) == "CH")$string = substr_replace($string,"C",0,2);
	if(substr($string,0,2) == "LL")$string = substr_replace($string,"L",0,2);
	return $string; 
}

function rfc_filter($string){
	return str_replace(array("DEL ","LAS ","DE ","LA ","Y ","A ","MC ","LOS ","VON ","VAN "),array(),$string);        
}

function rfc_vowel($char){
	return $char == "A" || $char == "E" || $char == "I" || $char == "O" || $char == "U";
}

?>