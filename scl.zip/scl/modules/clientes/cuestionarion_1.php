<?
require_once("../includes/includes.inc.php");
initialize("clientes","Busqueda de Clientes");

$u_persona = $_REQUEST['u_persona'];
$u_registro = $_REQUEST['u_registro'];
//echo 'http://172.20.1.77/PagosFijos/cuestionarion.asp?surveyid=1&u_persona='.$u_persona.'&u_registro='.$u_registro.'&u_user='.get_varname_session('iuserid').'&inicio=y';
echo '
		<iframe name="cuestionarioasp" id="cuestionarioasp" src="http://172.20.1.77/PagosFijos/cuestionarion.asp?surveyid=1&u_persona='.$u_persona.'&u_registro='.$u_registro.'&u_user='.get_varname_session('iuserid').'&inicio=y" frameborder="0" width="100%" height="90%" scrolling="no"></iframe>';

?>