<?php
# EditUser File 
# @uthor Mark 

require_once("../includes/includes.inc.php");
require_once("clientes.inc.php");

initialize("clientes","Clientes - Editar");

layout_menu($db, "ShowSolicitud()");
$u_persona = $_REQUEST['u_persona'];
$u_registro = $_REQUEST['u_registro'];
?>
<p class="textbold">Clientes &gt; Solicitud</p>
<br>
	<p id="text">Capture los datos de la solicitud</p>
	<form method="post" action="<?=$linkpath?>clientes/process_data.php?action=1" name="frm1">
		<input type="hidden" name="u_persona" id="u_persona" value="<?=$u_persona?>">
		<input type="hidden" name="u_registro" id="u_registro" value="<?=$u_registro?>">
	</form>
	<br><br>
	<table border="1" width="90%">
		<tr>
			<td height="600px">
			<div id="script" align="center" style="height:755px"></div>
			</td>
		</tr>
	</table>
	<br>
	<input type="button" value="Regresar" onclick="back()">
	<input type="button" value="Simulador" onclick="MuestraSimulador()">
	<br>
<?php
layout_footer();
?>          