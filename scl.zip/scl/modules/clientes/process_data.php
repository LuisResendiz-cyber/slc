<?php
# Process_data File 
# @uthor Mark       

require_once("../includes/includes.inc.php");
require_once("clientes.inc.php");

initialize_nolayout("clientes","");

$action = $_REQUEST['action'];
$header = "clientes.php";

if(isset($action) && $action == 1){ //CAMBIA EL ESTADO A RESERVADO
	
	$folio = $_REQUEST['u_persona'];
	$estatus = 2;	
	if(isset($folio) && strlen($folio) != 0){
		//$update_estatus = update_cliente_estatus($folio,$estatus,get_varname_session("iuserid"));
		set_varname_session("folio_cliente",$folio);
		$header = "sim_cliente.php?action=2";
	}
}elseif (isset($action) && $action == 2){ //CAMBIA EL ESTADO A LIBRE
	
	$estatus = 1;	
	if(strlen(get_varname_session("folio_cliente")) != 0){
		//$update_estatus = update_cliente_estatus(get_varname_session("folio_cliente"),$estatus,get_varname_session("iuserid"));
		unset_varname_session("folio_cliente");
		$header = "clientes.php";
	}
	
}elseif (isset($action) && $action == 3){ //GUARDA EL DATO EN BD

	$estatus = 3;	
	if(strlen(get_varname_session('folio_cliente')) != 0){

		$query_up = "update surveypersonas set validando = 2  WHERE customerid = ".get_varname_session('folio_cliente');
		execute($query_up);
		unset_varname_session("folio_cliente");
		$header = $linkpath.'index.php';
	}
}elseif (isset($action) && $action == 4){ //EJECUTA EL SP PARA GUARDAR LA INFORMACION DEL USUARIO REFERIDO
	
	require_once('../includes/openConnection.php');
	
	$folio = $_SESSION['nomina'].date("mdHi"); 
	$nombre = strtoupper($_POST['nombre']);
	$paterno = strtoupper($_POST['paterno']);
	$materno = strtoupper((isset($_POST['materno'])?$_POST['materno']:""));
	$fecha_nac = $_POST['fecha_nac'];
	$digitos_16 = $_POST['tarjeta'];

	$sp = $db->PrepareSP("BEGIN XSP_INSERTARXC(:nombre, :paterno, :materno, :fecha_na, :digitos_16, :p_u_persona, :p_u_rpc); END;");
	$db->InParameter($sp, $nombre, 'nombre');
	$db->InParameter($sp, $paterno, 'paterno');
	$db->InParameter($sp, $materno, 'materno');
	$db->InParameter($sp, $fecha_na, 'fecha_na');
	$db->InParameter($sp, $digitos_16, 'digitos_16');
	$db->OutParameter($sp, $p_u_persona, 'p_u_persona');
	$db->OutParameter($sp, $p_u_rpc, 'p_u_rpc');
	$db->Execute($sp);
	
	$header = "new_referido.php?u_p=".base64_encode($p_u_persona)."&rxc=".base64_encode($p_u_rpc)."&action=1";
	
}elseif (isset($action) && $action == 5){ //CALCULA EL RFC
	
	require_once("rfc.inc.php");
	
	$nombre = strtoupper($_POST['nombre']);
	$paterno = strtoupper($_POST['paterno']);
	$materno = strtoupper((isset($_POST['materno'])?$_POST['materno']:""));
	$fecha_nac = $_POST['fecha_nac'];
	echo rfc($paterno,$materno,$nombre,$fecha_nac);
	die();
	
}elseif (isset($action) && $action == 6){ //VALIDA QUE NO EXISTA DUPLICADOS EN NUMERO DE CUENTAS
	
	$cuenta = $_POST['cuenta_val'];
	$exist = get_cuentasDuplicadas($cuenta);
	if($exist == 0){
		echo 'NO';
	}else{
		echo 'SI';
	}
	die();
	
}elseif (isset($action) && $action == 7){ //NUEVO MODULO QUE PERMITE ACTUALIZAR EL TIPO DE TARJETA DE LOS CLIENTES
	
	$light = $_POST['light'];
	$saldo = $_POST['saldo'];
	$customerid = $_POST['idSelected'];
	
	if($light == 1){
        $cod_oferta = 'PPF8';
    }else{
        if($saldo >= 10000) {
			$cod_oferta = 'PPF3';
        }else if ($saldo < 10000) {
            $cod_oferta = 'PPF10';
		}
	}

	set_cuentaoferta($customerid, $cod_oferta);

}elseif (isset($action) && $action == 8){

	$pagos_vencidos = $_POST['pagos_vencidos'];
	$motivo_llamada = $_POST['motivo_llamada'];

	if($motivo_llamada == 1){
        $header = $linkpath.'clientes/clientes.php';
    }else{
		set_estadistico($pagos_vencidos,$motivo_llamada,$db);
		$header = $linkpath.'clientes/index.php';
	}
	
}

header("location: ".$header);
?>