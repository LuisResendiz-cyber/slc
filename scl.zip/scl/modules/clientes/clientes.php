<?php
# Clientes File 
# @uthor Mark

require_once("../includes/includes.inc.php");
require_once("clientes.inc.php");

initialize("clientes","Busqueda de Clientes");

$tipo_llamada = (isset($_POST['tipollamada'])?$_POST['tipollamada']:"");
$nombre = (isset($_POST['nombre'])?$_POST['nombre']:"");
$paterno = (isset($_POST['paterno'])?$_POST['paterno']:"");
$materno = (isset($_POST['materno'])?$_POST['materno']:"");
$estado = trim((isset($_POST['estado'])?$_POST['estado']:""));	
$telefono= (isset($_POST['telefono'])?$_POST['telefono']:"");
$num_cliente = (isset($_POST['num_cliente'])?$_POST['num_cliente']:"");	
$tdc = (isset($_POST['tdc'])?$_POST['tdc']:"");	

echo "<script>
	var selection = null;
	function select(object,id){
		document.getElementById('folio').value = \"\";
		if(selection) selection.style.fontWeight = 'normal';
		else{
			document.getElementById('linkedit').style.display = 'inline';
			document.getElementById('linkshow').style.display = 'inline';
		} 
		selection = object;
		document.getElementById('folio').value = id;
		selection.style.fontWeight = 'bold';
	}
	
	function edit(prfid){
		if(prfid == 3){
			solicitud = document.getElementById('folio').value;
			document.location = '{$linkpath}clientes/edi_cliente.php?sol='+solicitud;
		}else{
			alert('No disponible por el momento');
			return false;
		}
	}
	
	function new_ref(){
		document.location = '{$linkpath}clientes/new_referido.php';
	}
	
	function show_sim(){
		if(document.getElementById('folio').value != \"\"){
			document.fmr4.submit();
		}else{
			alert(\"Debes seleccionar un registro\");
			return false;
		}
	}
	
	function  LimpiaDatos(){
		document.location = '{$linkpath}clientes/clientes.php';
	}
	var url =".$linkpath.";
</script>";

layout_menu($db);

echo '	<p class="textbold">Busqueda &gt; Clientes</p>
		<p>&nbsp;</p>
		<form method="post" action="'.$linkpath.'clientes/clientes.php?action=1" name="frm1">
			<table class="text" border="0">
				<tr>
					<td colspan="2"><b>Sr. (a) me puede proporcionar su nombre completo por favor? [Buscar al cliente en sistema para confirmar que no est� dado de alta].</b></td>
				</tr><tr>
					<td class="textright" width="15%"><b>Nombre:&nbsp;</b></td>
					<td><input type="text" name="nombre" id="nombre" value="'.$nombre.'"></td>
				</tr><tr>
					<td class="textright"><b>Paterno:&nbsp;</b></td>
					<td><input type="text" name="paterno" id="paterno" value="'.$paterno.'"></td>
				</tr><tr>
					<td class="textright"><b>Materno:&nbsp;</b></td>
					<td><input type="text" name="materno" id="materno" value="'.$materno.'"></td>
				</tr><tr>
					<td class="textright"><b>Telefono:</b><br>(Lada+Telefono)&nbsp;</td>
					<td><input type="text" name="telefono" value="'.$telefono.'" id="telefono" maxlength="10"></td>
				</tr><tr>
					<td colspan="2"><b>En caso de no encontrarlo solicitar n�mero de TDC que requiere el plan</b></td>
				</tr><tr>
					<td colspan="2">&nbsp;</td>
				</tr><tr>
					<td class="textright"><b>N�mero de TDC:</b></td>
					<td><input type="text" name="tdc" value="'.$tdc.'" id="tdc" maxlength="16"></td>
				</tr><tr>
					<td class="textright"><b>Estado:&nbsp;</b></td>
					<td>
						<select name="estado" id="estado">
							<option value="">Elige opcion </option>';
								$estados = get_estados();
								while($estado_g = get_row($estados))
									echo '<option value="'.$estado_g[3].'" '.($estado_g[3]==$estado?' selected':'').'>'.$estado_g[1].'</option>';
					echo '</select>
					</td>
				</tr><tr>
					<td colspan="2">
						<input type="button" value="Buscar" onclick="ValidaBusqueda()"/>&nbsp;&nbsp;
						<input type="button" value="Limpiar Datos" onclick="LimpiaDatos()"/>
					</td>
				</tr>
			</table>
		</form>
	  <p>&nbsp;</p>';


	
if(isset($_GET["action"]) == 1){
	$bandera_reg = 0;
	$nombre = $_REQUEST["nombre"];
	$paterno = $_REQUEST["paterno"];
	$materno = $_REQUEST["materno"];
	$estado = $_REQUEST["estado"];
	$telefono = $_REQUEST["telefono"];
	$tdc = $_REQUEST["tdc"];
	/*<p>
		<a href="#" onclick="edit('.get_varname_session("profileedit").')" class="optionlink" id="linkedit" style="display: none;">Editar registro</a>&nbsp;&nbsp;&nbsp;
		<a href="#" onclick="show_sim()" class="optionlink" id="linkshow" style="display: none;">Simulador</a>&nbsp;&nbsp;&nbsp;
	</p>*/
	echo '
		<form method="post" action="'.$linkpath.'clientes/process_data.php?action=1" name="fmr4">
		<input type="hidden" name="folio" id="folio"></form>
		<p><font color="blue"><b>RESULTADOS</font></b></p>
		<hr>
		<table border="0">
			<tr bgcolor="gray">
				<td><b># Reg.</b></td>
				<td><b>NOMBRE</b></td>
				<td align="center"><b>ESTADO</b>&nbsp;&nbsp;&nbsp;</td>
				<td align="center"><b>CIUDAD</b>&nbsp;&nbsp;&nbsp;</td>
				<td align="center"><b>TELEFONO</b>&nbsp;&nbsp;&nbsp;</td>
				<td align="center"><b> TERMINACION</b>&nbsp;&nbsp;&nbsp;</td>
				<td align="center"><b>SOLICITUD</b></td>
				<td align="center"><b>RETROALIMENTACION</b></td>
			</tr>';
			$d = 1;
			$clientes = get_clientes_by_search(strtoupper($nombre),strtoupper($paterno),strtoupper($materno),$estado,$telefono,$tdc);
			//<td><a href="#" onclick="select(this,'.$cliente[24].')" class="textlink">'.$cliente[3].' '.$cliente[4].' '.$cliente[5].'</a>&nbsp;&nbsp;&nbsp;</td>
			while($cliente = get_row($clientes)){
				echo '<tr>
						<td>'.$d.'</td>
						<td>'.$cliente[3].' '.$cliente[4].' '.$cliente[5].'&nbsp;&nbsp;&nbsp;</td>
						<td align="center">'.(isset($cliente[13])?$cliente[13]:"").'</td>
						<td align="center">--</td>
						<td><center>'.$cliente[6].' '.$cliente[7].'</center></td>
						<td><center>'.$cliente[64].'</center></td>
						<td align="center">'.$cliente[24].'</td>
						<td align="center">--</td>
					</tr>';
				$d++;
			}
		echo '<tr>
					<td colspan="8">&nbsp;</td>
			</tr><tr>
				<td colspan="8">
					<b>
						<font color="red">En caso de no estar el cliente:</font><br><br>
						Sr. (a)  (nombre del cliente) Para iniciar con este tr�mite ser� necesario que conozca Usted el saldo total de la deuda de la tarjeta que Usted requiere tenga un Plan de Pagos Fijos y el n�mero de cuenta as� como sus fechas l�mites de pago, cuenta con todo esto?
					</b>
				</td>
			</tr><tr>
				<td colspan="8">&nbsp;</td>
			</tr><tr>
				<td colspan="8">
					<b>
						<font color="red">Si lo conozco</font><br><br>
						Sr. (a)  (nombre del cliente) el plan de pagos que Santander ofrece, tiene como beneficio el contar on una tasa m�s baja de la que maneja actualmente en su TDC y un pago fijo mensual mayor al pago m�nimo liquidando as� el saldo de su tarjeta en un plazo establecido. En caso que sea lo que usted busca en unos momentos le confirmar�a el monto de sus mensualidades y la tasa preferencial.					
					</b>
				</td>
			</tr><tr>
				<td colspan="8">&nbsp;</td>
			</tr><tr>
				<td colspan="8">
					<b>De acuerdo, Sr. (a) (mencionar nombre), le informo que el tr�mite que realizar� con nosotros es un tr�mite pre  aprobatorio lo que significa que no es un convenio y por lo tanto Santander puede activar, modificar o declinar su plan de pagos.  Con este Plan de Pagos a partir de este momento Usted no podr� utilizar su Tarjeta de Cr�dito hasta la vigencia del mismo. La cuenta ser� reportada al bur� como reestructurada y debe seguir al corriente con sus pagos m�nimos hasta recibir una respuesta por parte del banco para ser considerada est� usted de acuerdo?</b>
				</td>
			</tr><tr>
				<td colspan="8">
					<br>
					<input type="button" value="Nuevo cliente" onclick="NuevoRegistro()">
				</td>
			</tr>
		</table>
		<br>';
}

layout_footer();
?>