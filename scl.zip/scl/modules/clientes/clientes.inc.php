<?php

function get_clientes_by_search($nombre,$paterno,$materno,$estado,$telefono,$tdc){
	$query = "SELECT * FROM BD WHERE U_PERSONA != 0";
	$query .= ($nombre==""?"":" AND NOMBRE LIKE '{$nombre}%'");
	$query .= ($paterno==""?"":" AND PATERNO LIKE '{$paterno}%'");
	$query .= ($materno==""?"":" AND MATERNO LIKE '{$materno}%'");
	$query .= ($estado==""?"":" AND ESTADO LIKE '{$estado}%'");
	$query .= ($telefono==""?"":" AND ((lada_casa || tel_casa) = '{$telefono}' or (lada_oficina || tel_oficina) = '{$telefono}' or (lada3 || tel3) = '{$telefono}' or (lada_alt4 || tel_alt4) = '{$telefono}')");
	$query .= ($tdc==""?"":" AND digitos_16 = '{$tdc}'");
	$query .= " AND rownum <= 30";
	//echo $query;
	return execute($query);
}

function get_cliente_by_folio($folio){
	return execute("select r1.responsefreeform ||' '|| r2.responsefreeform ||' '|| r3.responsefreeform  as nombre, 
					r4.responsefreeform as light,
					r5.responsefreeform as saldo, r6.responsefreeform as tdc
					from surveyresponse r1 join surveyresponse r2 on r1.customerid = r2.customerid
					join surveyresponse r3 on r1.customerid = r3.customerid
					join surveyresponse r4 on r1.customerid = r4.customerid
					join surveyresponse r5 on r1.customerid = r5.customerid
					join surveyresponse r6 on r1.customerid = r6.customerid
					where customerid = ".$folio." and r1.choiceid = 1
					and r2.choiceid = 2
					and r3.choiceid =3
					and r4.choiceid =13
					and r5.choiceid =14
					and r6.choiceid =16
					order by choiceid"
				);
}

function update_cliente_estatus($folio,$estatus,$userid){
	return execute("UPDATE BD SET IESTATUSCLIENTEID = ".$estatus.", IUSERID = ".$userid." WHERE IFOLIO = '".$folio."'");
}


function update_cliente_data($icompanyid,$iemployeeid,$iprofileid, $susuario,$semployeename,$spaterno,$smaterno,$brestricted,$inss,$srfc,$scurp,$saddress,$snumber,$sneighborhood,$icityid,$izipcode,$iphone,$imobilephone,$smail,$bgender,$imaritalstatusid,$ibankid,$ibankaccount,$bvehicle,$idriverlicensenumber,$ischoolingid,$idatastatusid){
	return execute("update cliente set susername = '{$susuario}',sname = '{$semployeename}',splastname = '{$spaterno}',smlastname = '{$smaterno}',brestricted = '{$brestricted}',inss = '{$inss}',srfc = '{$srfc}',scurp = '{$scurp}',saddress = '{$saddress}',snumber = '{$snumber}',sneighborhood = '{$sneighborhood}',icityid = '{$icityid}',izipcode = '{$izipcode}',iphone = '{$iphone}',imobilephone = '{$imobilephone}',smail = '{$smail}',bgender = '{$bgender}',imaritalstatusid = '{$imaritalstatusid}',ibankid = '{$ibankid}',ibankaccount = '{$ibankaccount}',bvehicle = '{$bvehicle}',idriverlicensenumber = '{$idriverlicensenumber}',ischoolingid = '{$ischoolingid}',idatastatusid = '{$idatastatusid}', iprofileid={$iprofileid} where icompanyid = {$icompanyid} and iemployeeid = {$iemployeeid}");
}

function get_estados(){
	return execute("SELECT * FROM ESTADOS");
}

function get_motivosolicitud(){
	return execute("SELECT * FROM usr_solicitudplan where solicitudplanid not in (9,10,11,12)");
}

function get_bines(){
	return execute("SELECT * FROM usrprefijos");
}

function get_cliente_by_folio_and_last4($folio, $last4){
	return execute("SELECT * FROM BD WHERE U_PERSONA=".$folio." and ULT_4_DIG_CTA='".$last4."'");
}

function get_cliente_tdcs($folio){
	return execute("SELECT * FROM USR_SIMULACION WHERE U_PERSONA=".$folio);
}

function get_cliente_folio($folio){
	$query = "select NOMBRE, PATERNO || ' ' ||MATERNO AS APELLIDO from bd WHERE u_persona = ".$folio;
	return execute($query);
}

function get_cliente_tel($folio){
	return execute("SELECT * FROM registrostelefonicos WHERE U_PERSONA=".$folio);
}

function get_cuentasDuplicadas($cuenta){
	$query_cuenta = "select count(*) from 
	surveyresponse sr join surveypersonas sp using(customerid)
	where sr.questionid = 1 and sr.choiceid = 16
	and sp.validavoz > 1 and sp.validando >= 4 
	and sp.razoncancelacionid = 0 and sr.responsefreeform = '".$cuenta."'";
	
	//$query_cuenta = "select count(*) from bd where digitos_16 = '".$cuenta."'";
	$exist = get_row(execute($query_cuenta));
	return $exist[0];
}

function set_cuentaoferta($customerid, $cod_oferta){
	return execute("update bd set cod_oferta = '{$cod_oferta}' where u_persona = {$customerid}");
}

function get_motivos_llamada(){
	return execute("select * from usr_motivosllamada order by valor");
}

function set_estadistico($pagos_vencidos,$motivo_llamada,$db){
	return execute("insert into estadistico_llamadas (ID_PAGOVENCIDO,ID_MOTIVOLLAMADA,FECHA) values (".$pagos_vencidos.",".$motivo_llamada.",sysdate)");
}
?>