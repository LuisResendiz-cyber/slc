<?php
# Clientes File 
# @uthor Mark

require_once("../includes/includes.inc.php");
require_once("clientes.inc.php");

initialize("clientes","Busqueda de Clientes");

$tipo_llamada = (isset($_POST['tipollamada'])?$_POST['tipollamada']:"");
$nombre = (isset($_POST['nombre'])?$_POST['nombre']:"");
$paterno = (isset($_POST['paterno'])?$_POST['paterno']:"");
$materno = (isset($_POST['materno'])?$_POST['materno']:"");
$estado = trim((isset($_POST['estado'])?$_POST['estado']:""));	
$telefono= (isset($_POST['telefono'])?$_POST['telefono']:"");
$num_cliente = (isset($_POST['num_cliente'])?$_POST['num_cliente']:"");	
$invitacion = (isset($_POST['invitacion'])?$_POST['invitacion']:"");	

echo "<script>	var url =".$linkpath.";</script>";

layout_menu($db);

echo '
	<p class="textbold">Busqueda &gt; Clientes</p><p>&nbsp;</p>
	<form method="post" action="'.$linkpath.'clientes/process_data.php?action=8" name="frm1">
		<table class="text" border="0">
			<tr>
				<td colspan="2">Buenos (as) d�as/tardes/noches, Asesor�a Financiera Santander le atiende '.(isset($_SESSION["sname"])?$_SESSION["sname"]:"...").' en que le puedo servir.</td>
			</tr><tr>
				<td colspan="2"><font color="blue">
					<br><b>SELECCIONAR EL MOTIVO DE LA LLAMADA.</b>
					<br><br>
				</td>
			</tr><tr>
				<td class="textright">
					<b>Pagos Vencidos:&nbsp;</b>
				</td><td>
					<select name="pagos_vencidos" id="pagos_vencidos">
						<option value="0">Elige opcion </option>
						<option value="1">0 PV</option>
						<option value="2">1 o mas PV</option>
					</select>
				</td>
			</tr><tr>
				<td class="textright">
					<b>Motivo de Llamada:&nbsp;</b>
				</td><td>
					<select name="motivo_llamada" id="motivo_llamada" onchange="valida_combos(2)">
						<option value="0">Elige opcion </option>
						<option value="1">Interesado en el plan</option>
						<option value="2">Solo pregunta - Desempleo</option>
						<option value="3">Fuera de campa�a</option>
						<option value="4">Solo pregunta - Decremento ingresos</option>
						<option value="5">Solo pregunta - Sobredeuda</option>
						<option value="6">Solo pregunta - Negocio peque�o</option>
						<option value="7">Solo pregunta - Troblemas temporales</option>
						<option value="8">Plan de Pagos Fijos no activado</option>
						<option value="9">Saldo Total exigible</option>
						<option value="10">TDC no Desbloqueada</option>
						<option value="11">Alta de Planes de Pagos Fijos Err�neas</option>
						<option value="12">Confusi�n Por Ofertas Distintas</option>
					</select>
				</td>
			</tr>	
		</table>
	</form>';
layout_footer();
?>