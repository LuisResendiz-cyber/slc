<?php
#Index File 
#@uthor Mark

require_once("../includes/includes.inc.php");
require_once("../layoutFile/layoutFile.inc.php");

$error = (isset($_GET['error'])?$_GET['error']:0);

load_session();
get_header("Inicio");
get_menu();

	
	echo "<b>Seleccione el tipo de reporte que desea consultar y d� click en aceptar.</b><br><br>";
	echo "<form name=\"fmr5\" method=\"post\" action=\"{$linkpath}layoutFile/process_data.php?action=4\" onSubmit=\"location.href='".$linkpath."index.php'\">
		
		<table>
			<tr>
				<td width=\"40%\" valign=\"bottom\" >
					<table border =\"0\">
						<tr>
							<td colspan=\"2\">
								<b>Buscar por:</b>
								&nbsp;&nbsp;&nbsp;
								<select name=\"clasificacion\" id=\"clasificacion\" onChange=\"showInputs()\">
									<option value=\"5\">Enviadas (10)</option>
									<option value=\"1\">Rechazadas (25)</option>
									<option value=\"2\">Aprobadas (30)</option>
									<option value=\"3\">Declinadas (35)</option>
									<option value=\"4\">Canceladas (50)</option>
								</select>
							</td>
						</tr><tr>
							<td colspan=\"2\">&nbsp;</td>
						</tr><tr>
							<td><b>Shot:</b>&nbsp;<input type=\"text\" name=\"shot\" size=\"10\">&nbsp;&nbsp;</td>
							<td><b>Remesa #:</b>&nbsp;<input type=\"text\" name=\"num_remesa\" size=\"10\"></td>
						</tr>
					</table>
				</td>
			</tr><tr>
				<td colspan=\"2\">&nbsp;</td>
			</tr><tr>
					<td colspan=\"2\">
						<input type=\"button\" value=\"Terminar\" onclick=\"location.href='".$linkpath."index.php'\"/>&nbsp;&nbsp;
						<input type=\"button\" value=\"Continuar\"/ name=\"continuar\" onclick=\"validaFormReport()\">
					</td>
			</tr><tr>
				<td colspan=\"2\">&nbsp;<div id=\"loading\" style=\"display:none\">Realizando peticion, espere un momento.&nbsp;<img src=\"".$linkpath."includes/imgs/loading.gif\"></div></td>
			</tr>
		</table>
		</form>";
if(isset($error) && $error != 0){

	echo 'Actualizaci&oacute;n de remesas.<br><br>';
	
	if($error == 1){
		$valor_error = "El archivo no se cargo correctamente, intente de nuevo!!!!";
	}else if($error == 2){
		$valor_error = "No se recibio un tipo de archivo de texto, intente de nuevo!!!!";
	}else if($error == 3){
		$valor_error = "Los datos se actualizaron correctamente!!!!";
	}else if($error == 4){
		$valor_error = "No se pudo realizar la peticion, intente nuvamente!!!!";
	}
	
	echo "<table width=\"50%\" border =\"0\">
			<tr>
				<td>
					<b>Mensaje:</b>
				</td><td>
					<font color=\"red\">".$valor_error."</font>
				</td>
			</tr><tr>
				<td colspan=\"2\">
					<br><br>
					<input type=\"button\" value=\"Terminar\" onclick=\"location.href='".$linkpath."index.php'\" />&nbsp;
				</td>
			</tr>
		</table>";
}
		
		
get_footer();
?>