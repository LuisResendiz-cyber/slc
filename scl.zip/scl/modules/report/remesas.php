<?php
#Remesas File 
#@uthor Mark


require_once("../includes/includes.inc.php");
require_once("../layoutFile/layoutFile.inc.php");

	$action = (isset($_POST['actionn'])?$_POST['actionn']:0);
	$shot = (isset($_POST['shot'])?$_POST['shot']:0);
	$num_remesa = (isset($_POST['num_remesa'])?$_POST['num_remesa']:0);
	$factura = (isset($_POST['factura'])?$_POST['factura']:0);
	$clas = (isset($_POST['clas'])?$_POST['clas']:0);

	$fecha_din = 'Venta';
	
	$output = '<table border="1">
				 <tr>
					<td colspan="8">Resultados</td>
				</tr><tr style="background-color:'.getColor(0).'">
					<td class="textright">Registro</td>
					<td>Shot</td>
					<td>Remesa</td>
					<td>Solicitud</td>
					<td>Producto</td>
					<td>Cuenta</td>
					<td>Estado</td>
					<td>Fecha '.$fecha_din.'</td>
		 </tr>
			
			
			';
	
	$rs = get_data_report($shot, $num_remesa, $clas, $factura, $conn);
	$i = 1;
	if(!$rs->EOF){
		while(!$rs->EOF) {
			$output.= '<tr style="background-color:'.getColor($i).'">
				<td class="textright">'.$i.'</td>
				<td>'.$rs->fields["shot"].'</td>
				<td>'.$rs->fields["remesa"].'</td>
				<td>'.$rs->fields["solicitud"] .'</td>
				<td>'. $rs->fields["producto"] .'</td>
				<td>'.$rs->fields["cuenta"].'</td>
				<td>'.$rs->fields["estado"].'</td>
				<td>'.$rs->fields["fecha"].'</td>
			 </tr>';
			$rs->MoveNext();
			$i++;
		}
	}else{
		$output.= '<tr><td colspan ="8">No se encontraron resultados</td></tr>';
	}
	
	$output.= '</table><br>';
	/*	
		<table>
			<tr>
				<td width=\"40%\" valign=\"bottom\" >
					<table border =\"1\">
						<tr>
							<td colspan=\"2\">
								<b>Buscar por:</b>
								&nbsp;&nbsp;&nbsp;
								<select name=\"clasificacion\" id=\"clasificacion\" onChange=\"showInputs()\">
									<option value=\"1\">Rechazadas (25)</option>
									<option value=\"2\">Aprobadas (30)</option>
									<option value=\"3\">Declinadas (35)</option>
									<option value=\"4\">Canceladas (50)</option>
								</select>
							</td>
						</tr><tr>
							<td colspan=\"2\">&nbsp;</td>
						</tr><tr>
							<td><b>Shot:</b>&nbsp;<input type=\"text\" name=\"shot\" size=\"10\">&nbsp;&nbsp;</td>
							<td><b>Remesa #:</b>&nbsp;<input type=\"text\" name=\"num_remesa\" size=\"10\"></td>
						</tr>
					</table>
				</td>
			</tr><tr>
				<td colspan=\"2\">&nbsp;</td>
			</tr><tr>
				<td colspan=\"2\">&nbsp;<div id=\"loading\" style=\"display:none\">Realizando peticion, espere un momento.&nbsp;<img src=\"".$linkpath."includes/imgs/loading.gif\"></div></td>
			</tr><tr>
				<td colspan=\"2\">
					<input type=\"button\" value=\"Terminar\" onclick=\"location.href='".$linkpath."index.php'\"/>&nbsp;&nbsp;
					<input type=\"button\" value=\"Continuar\"/ name=\"continuar\" onclick=\"validaFormReport()\">
				</td>
			</tr>
		</table>
*/
echo $output;
?>