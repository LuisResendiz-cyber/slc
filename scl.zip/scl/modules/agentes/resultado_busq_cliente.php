<?php
# @uthor Mark
# resultado_busq_cliente File

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("agente","Resultado de la Busqueda");

if(get_session_varname("log_registro") === 3){
    set_session_varname('log_registro',3);
}else{
    set_session_varname('log_registro',3);
    set_evento_registro(get_session_varname("s_usr_id"),-1,'CONSULTA BUSQUEDA',$db);
}

layout_menu($db,"");

$solicitud = ($_REQUEST['solicitud'] != null?$_REQUEST['solicitud']:0);
$nombre = $_REQUEST['nombre'];
$paterno = $_REQUEST['paterno'];
$materno = $_REQUEST['materno'];
$agente = $_SESSION['s_usr_id'];
$telefono = ($_REQUEST['telefono'] != null?$_REQUEST['telefono']:0);



$registros = set_busca_cliente($solicitud, $nombre, $paterno, $materno, $agente, $telefono,$db);


if($registros->EOF){
    $encontro = 0;
}else{
    $encontro = 1;
}

?>

<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#">Agentes</a></li>
        <li class="breadcrumb-item active" aria-current="page">Resultado de la Busqueda</li>
    </ol>
</nav>


<form method="post" name="frm1" action="#">
<input type="hidden" name="u_persona" id="u_persona" readonly>
<input type="hidden" name="u_registro" id="u_registro" readonly>
<input type="hidden" name="trabajado" id="trabajado" readonly>

<table class="text" border="0">
    <tr>
        <td><b>Detalles del Cliente</b></td>
    </tr><tr>
        <td>&nbsp;</td>
    </tr><tr>
        <td>
<?php      if($encontro ==1){ ?>
    <?php
    
if (!$registros->EOF) {
    echo '<table border="1">';
    echo '<tr style="font-weight:bold;" align="center" bgcolor="#99CCFF">';
    echo '<td>PRODUCTO</td>';
    echo '<td>REGISTRO</td>';
    echo '<td>U_PERSONA</td>';
    echo '<td>NOMBRE</td>';
    echo '<td>COMENTARIO</td>';
    echo '<td>BLOQUEO</td>';
    echo '<td>BANDERA</td>';
    echo '</tr>';

    while (!$registros->EOF) {
        echo '<tr>';
        echo '<td>' . $registros->fields["PRODUCTO"] . '</td>';
        echo '<td>' . $registros->fields["REGISTRO"] . '</td>';
        echo '<td>' . $registros->fields["U_PERSONA"] . '</td>';
        echo '<td>' . $registros->fields["NOMBRE"] . '</td>';
        echo '<td>' . $registros->fields["COMENTARIO"] . '</td>';
        echo '<td>' . $registros->fields["BLOQUEO"] . '</td>';
        echo '<td align="center">
        <a href="#" onclick="mostrar_registro('.$registros->fields["PRODUCTO"].', '.$registros->fields["BLOQUEO"].','.$registros->fields["BANDERA"].','.$registros->fields["U_PERSONA"].','.$registros->fields["REGISTRO"].','.$registros->fields["RAZONCANCELACION"].',\''.encripta(3).'\')">
            <img src="'.$linkpath.'includes/imgs/'.($registros->fields["BANDERA"]== 0?'Comenzar.gif':'Terminar.gif').'">
         </a>
    </td>';
        echo '</tr>';
        $registros->MoveNext();
    }

    echo '</table>';
} else {
    echo 'No hay resultados';
}
?>



<?php      }else{      ?>
            <table>
                <tr>
                    <td>La b&uacute;squeda que ingreso no genero ning&uacute;n resultado int&eacute;ntelo nuevamente.</td>
                </tr>
            </table>
<?php      }       ?>
        </td>
    </tr><tr>
        <td>&nbsp;</td>
    </tr><tr>
	<td>
            <input class="btn btn-success" type="button" value="Regresar" onclick="Atras()" />
        </td>
    </tr>
</table>
</form>
<?php
layout_footer();
?>