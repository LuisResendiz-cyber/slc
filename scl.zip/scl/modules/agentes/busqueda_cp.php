<?php
# @uthor Mark
# Cuestionario File
//libxml_use_internal_errors(true);
require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

//initialize("agente,supervisor", "Solicitud");

//layout_menu($db, "");

?>

<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <script>
            function borrar(){
                cp = document.getElementById("cp").value = "";
                edo = document.getElementById("edo").value = "";
                mun = document.getElementById("mun").value = "";
                cdd = document.getElementById("cdd").value = "";
                col = document.getElementById("col").value = "";
                document.getElementById("buscar_cp").disabled = false;
            }
            
            function busqueda_cp2(boton) {
                cp = document.getElementById("cp").value;
                edo = document.getElementById("edo").value;
                mun = document.getElementById("mun").value;
                cdd = document.getElementById("cdd").value;
                col = document.getElementById("col").value;
                document.getElementById("result_cp2").innerHTML="";
                //alert(mun);
                if(cp == "" && edo == "" && mun == "" && cdd == "" && col == ""){
                    alert("Almenos ingrese un p�rametro de busqueda.");
                    boton.disabled = false;
                    return false;
                } else {
                    var xmlhttp;
                    if (window.XMLHttpRequest)
                    {// code for IE7+, Firefox, Chrome, Opera, Safari
                        xmlhttp=new XMLHttpRequest();
                    }
                    else
                    {// code for IE6, IE5
                        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
                    }
                    xmlhttp.onreadystatechange=function()
                    {
                        if (xmlhttp.readyState==4 && xmlhttp.status==200)
                        {
                            //alert(xmlhttp.responseText);
                            document.getElementById("result_cp2").innerHTML=xmlhttp.responseText;
                        }
                    }
                    xmlhttp.open("POST","modules.php?mod=agentes&op=process_data&act=<?= encripta('33') ?>",true);
                    xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
                    xmlhttp.send("cp="+cp+"&edo="+edo+"&mun="+mun+"&cdd="+cdd+"&col="+col+"&act2=1");
                }
            }
            
            function b_municipio(edo,act) {

                /*if (edo=="")
                {*/
                    document.getElementById("mun").innerHTML="";
                    document.getElementById("cdd").value="";
                    document.getElementById("col").value="";
                    document.getElementById("cp").value="";
                    document.getElementById("result_cp2").innerHTML="";
//                    return;
//                }
                if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
                    xmlhttp=new XMLHttpRequest();
                } else {// code for IE6, IE5
                    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
                }
                
                xmlhttp.onreadystatechange=function() {
                    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
                        //document.getElementById("DIR_CDDMUN").value=xmlhttp.responseText;
                        if(xmlhttp.responseText != "") {
                            document.getElementById("mun").innerHTML=xmlhttp.responseText;
                        }
                    }
                }
                
                xmlhttp.open("POST","modules.php?mod=agentes&op=process_data&act=<?= encripta('33') ?>",true);
                xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
                xmlhttp.send("edo="+edo+"&act2="+act);
                
            }
            
            function b_ciudad(mun,act) {
                edo = document.getElementById("edo").value;

                if (edo == "") {
                    document.getElementById("cdd").value="";
                    return;
                }
                if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
                    xmlhttp=new XMLHttpRequest();
                } else {// code for IE6, IE5
                    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange=function() {
                    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
                        //document.getElementById("DIR_CDDMUN").value=xmlhttp.responseText;
                        if(xmlhttp.responseText != "") {         
                            document.getElementById("cdd").value="";
                            document.getElementById("cdd").value=xmlhttp.responseText;
                        }
                    }
                }
                
                xmlhttp.open("POST","modules.php?mod=agentes&op=process_data&act=<?= encripta('33') ?>",true);
                xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
                xmlhttp.send("edo="+edo+"&act2="+act+"&mun="+mun);
                
            }
        </script>
        <style>
            table.cp tr:nth-child(2n) td {
                border: 2px solid silver;
                border-collapse: separate;
                border-radius: 2%;
                font-size: 10px;
                background: #e0e0e0;
            }

            table.cp tr td {
                border: 2px solid silver;
                border-collapse: separate;
                border-radius: 2%;
                font-size: 10px;
            }

            table.cp caption {
                font-size: 14px;
                font-weight: bold;
                color: red;
            }

            table.cp tr:hover td {
                /*border: 2px solid black;*/
                background: grey;
                color: white;
            }
        </style>
    </head>    
<body style="background: #3F738D;">
<?php
$xml = simplexml_load_file("modules/agentes/Edos.xml");

echo "<pre>";
//print_r($xml);
echo "</pre>";

?>
<form method="post" action="modules.php?mod=agentes&op=resultado_cp" name="frm1">
    <table align="center">
        <tr>
            <th colspan="2" align="center">
                <h2>Par&aacute;metros:</h2>
            </th>
        </tr>
        <tr>
            <td>
                <label for="cp">CP:</label>
            </td>
            <td>
                <input type="text" class="number" maxlength="5" name="cp" id="cp" size="10" maxlength="10" onclick="borrar();"/>
            </td>
        </tr>
        <tr>
            <td>
                <label for="edo">Estado:</label>
            </td>
            <td>
                <select name="edo" id="edo" onchange="b_municipio(this.value,2)">
            <?php   
                //print $rs->GetMenu('edo',true,false,0,0,'id="edo" onchange="b_municipio(this.value,2)"');
                    /*echo "<option value=''>Elige opci&oacute;n</option>";                    
                    
                    for ($indice_cal = 0; $indice_cal < count($rs->_array); $indice_cal++) {
                        echo '<option value="' . $rs->_array[$indice_cal]['NOMBRE'] . '" >' . $rs->_array[$indice_cal]['NOMBRE'] . '</option>';
                    }*/
                    echo "<option value=''>Elige opci&oacute;n</option>";
                    foreach ($xml as $xml_child){
                        echo '<option value="' .$xml_child. '" >' . $xml_child. '</option>';
                    }
                    ?>
                </select>
            </td>
        </tr>
        <tr>
            <td>
                <label for="mun">Municipio:</label>
            </td>
            <td>                        
                <select name="mun" id="mun" onchange="b_ciudad(this.value,3);">
                </select>
            </td>
        </tr>
        <tr>
            <td>
                <label for="cdd">Ciudad:</label>
            </td>
            <td>
                <!--select name="cdd" id="cdd">                            
                </select-->
                <input type="text" name="cdd" id="cdd" size="35"/>
            </td>
        </tr>
        <tr>
            <td>
                <label for="col">Colonia:</label>
            </td>
            <td>
                <input type="text" name="col" id="col" size="35"/>
                <!--input list="col">
                <datalist id="col" name="col">
                </datalist-->
            </td>
        </tr>
        <tr>
            <td align="center" colspan="2">
                <input type="button" value="Buscar" id="buscar_cp" onclick="this.disabled=true;busqueda_cp2(this);">
                <input type="button" value="Limpiar..." onclick="borrar();">
            </td>
        </tr>
    </table>
    <div id="result_cp2">        
    </div>
</form>
</body>
</html>
<?
//layout_footer();
?>