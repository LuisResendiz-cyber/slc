<?php

##### OBTIENE EL NUMERO DE SOLICITUD DE PREDICTIVO

function get_preavail($s_usr_id, $db) {
    $rs = $db->ExecuteCursor("BEGIN TDCAMEXONLINE.xsp_getPreAvail_ws(" . $s_usr_id . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs->fields[0];
}



##### OBTIENE EL TELEFONO DE SOLICITUD DE PREDICTIVO

function get_PreAvail_Telefono($s_usr_id, $db) {
    $rs = $db->ExecuteCursor("BEGIN TDCAMEXONLINE.xsp_getPreAvail_Telefono_ws(" . $s_usr_id . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs->fields[0];
}

##### OBTIENE LA GRABACION DE SOLICITUD DE PREDICTIVO

function get_PreAvail_Grabacion($s_usr_id, $db) {
    $rs = $db->ExecuteCursor("BEGIN TDCAMEXONLINE.xsp_getPreAvail_Grabacion_ws(" . $s_usr_id . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs->fields[0];
}

#####  OBTIENE REGISTRO ESPECICFICO PREDICTIVO

function get_registro_especifico_pred($u_registro, $telefono, $usr_id, $tipo_campana, $duracion, $grabacion, $db) {
    $query = "BEGIN TDCAMEXONLINE.xsp_getRegistroEsp_Pred_Time(:u_registro, :telefono, :usr_id, :tipo_campana, :duracion, :grabacion, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $u_registro, 'u_registro');
    $db->InParameter($stmt, $telefono, 'telefono');
    $db->InParameter($stmt, $usr_id, 'usr_id');
    $db->InParameter($stmt, $tipo_campana, 'tipo_campana');
    $db->InParameter($stmt, $duracion, 'duracion');
    $db->InParameter($stmt, $grabacion, 'grabacion');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

##### OBTIENE LAS NOTAS DEL USUARIO

function get_notas($s_usr_id, $db) {
    $rs = $db->ExecuteCursor("BEGIN TDCAMEXONLINE.XSP_GETNOTASPERSONALES(" . $s_usr_id . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

##### GUARDA LAS NOTAS PERSONALES DEL USUARIO

function set_notas($s_usr_id, $nota, $db) {
    $stmt = $db->PrepareSP("BEGIN TDCAMEXONLINE.XSP_SETNOTASPERSONALES(:p_usr_id, :nota); END;");
    $db->InParameter($stmt, $s_usr_id, 'p_usr_id');
    $db->InParameter($stmt, $nota, 'nota');
    $db->Execute($stmt);
}

##### OBTIENE UN NUEVO REGISTRO Y DEVUELVE EL NUMERO DE SOLICITUD
function get_registro_solicitud($db, $s_usr_id, $camp, $prioridad, $estatus, $intentos, $rand_, $reg, $tipoCampana) {
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    
    $stmt = $db->PrepareSP("BEGIN TDCAMEXONLINE.XSP_GETNUEVOREGISTRO(:camp, :prioridad, :estatus, :intentos, :user_, :rand_, :reg, :tipoCampana, :rc); END;");
    
    $db->InParameter($stmt, $camp, 'camp');
    $db->InParameter($stmt, $prioridad, 'prioridad');
    $db->InParameter($stmt, $estatus, 'estatus');
    $db->InParameter($stmt, $intentos, 'intentos');
    $db->InParameter($stmt, $s_usr_id, 'user_');
    $db->InParameter($stmt, $rand_, 'rand_');
    $db->OutParameter($stmt, $reg, 'reg', 32); # return varchar(32)
    $db->InParameter($stmt, $tipoCampana, 'tipoCampana');
    
    $rs = $db->ExecuteCursor($stmt, 'rc');

    return $rs;
}

##### OBTIENE LAS CALIFICACIONES DE NO CONTACTO

function get_cal_NC($camp, $id_solicitud, $db) {
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    $query = "BEGIN TDCAMEXONLINE.XSP_CALNOCONTACTO_NC(:camp, :sol, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $camp, 'camp');
    $db->InParameter($stmt, $id_solicitud, 'sol');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    return $rs;
}

##### OBTIENE LAS CALIFICACIONES DE NO CONTACTO, BASE SIN NOMBRE

function get_cal_NC_SN($camp, $db) {
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    $query = "BEGIN TDCAMEXONLINE.XSP_GETCALNOCONTACTO(:camp, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $camp, 'camp');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    return $rs;
}

##### OBTIENE LAS CALIFICACIONES DE SI CONTACTO

function get_cal_SC($camp, $db) {
    $db->SetFetchMode(ADODB_FETCH_BOTH);
//    $query = "BEGIN xsp_getListaEstatusNoContacto(:camp, :rc); END;";
    $query = "BEGIN TDCAMEXONLINE.XSP_GETLISTAESTATUSSICONTACTO(:camp, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $camp, 'camp');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    return $rs;
}

##### GUARDA EL HISTORICO DE LA CALIFICACION DE LOS TELEFONOS

function set_califica_telefono($telefono, $cal_tel, $num_tel, $db) {
    set_session_varname("caltelefono" . $num_tel, $cal_tel);

    $stmt = $db->PrepareSP("BEGIN TDCAMEXONLINE.spU_setRegistroTelefonico(:iRegTelefono, :iStatusLlamada); END;");
    $db->InParameter($stmt, $telefono, 'iRegTelefono');
    $db->InParameter($stmt, $cal_tel, 'iStatusLlamada');
    $db->Execute($stmt);
}

##### GUARDA EL HISTORICO DE LA CALIFICACION DE LOS TELEFONOS

function set_estatus_registro($id_registro, $s_usr_id, $telefono, $cal_tel, $elapsed, $comment, $camp, $segundos, $tipo_campana, $db) {

    $stmt = $db->PrepareSP("BEGIN TDCAMEXONLINE.xsp_setEstatusRegistro_pnd(:u_registro, :agente, :u_telefono, :cal_telefono, :elapsed, :comment, :campana, :segundos, :tipoCampana); END;");
    $db->InParameter($stmt, $id_registro, 'u_registro');
    $db->InParameter($stmt, $s_usr_id, 'agente');
    $db->InParameter($stmt, $telefono, 'u_telefono');
    $db->InParameter($stmt, $cal_tel, 'cal_telefono');
    $db->InParameter($stmt, $elapsed, 'elapsed');
    $db->InParameter($stmt, $comment, 'comment');
    $db->InParameter($stmt, $camp, 'campana');
    $db->InParameter($stmt, $segundos, 'segundos');
    $db->InParameter($stmt, $tipo_campana, 'tipoCampana');
    $db->Execute($stmt);
}

##### GUARDA LA SUBCALIFICACIÓN

function set_subcalificacion_registro($id_registro, $id_subcalificacion, $telefono, $db) {

    $stmt = $db->PrepareSP("BEGIN XSP_SETSUBCALIFICACIONREGISTRO(:u_registro, :u_subcalificacion, :telefono); END;");
    $db->InParameter($stmt, $id_registro, 'u_registro');
    $db->InParameter($stmt, $id_subcalificacion, 'u_subcalificacion');
    $db->InParameter($stmt, $telefono, 'telefono');
    $db->Execute($stmt);
}

##### GUARDA EL HISTORICO DE LA CALIFICACION DE LOS TELEFONOS

function set_estatus_registro_normal($id_registro, $estatusllamada, $estatusregistro, $prioridad, $s_usr_id, $elapsed, $comment, $camp, $segundos, $tipo_campana, $db)

//set_estatus_registro_normal($id_registro, 406, 'AGENDADO', 1, $usr_id, 1, $id_telefono, 1, 0, '1');

{
    $stmt = $db->PrepareSP("BEGIN TDCAMEXONLINE.xsp_setEstatusRegistro(:reg, :stat, :llam, :pri, :user_, :elapsed, :comm, :camp, :segundosEnllamda, :tipoCampana); END;");
    $db->InParameter($stmt, $id_registro, 'reg');
    $db->InParameter($stmt, $estatusllamada, 'stat');
    $db->InParameter($stmt, $estatusregistro, 'llam');
    $db->InParameter($stmt, $prioridad, 'pri');
    $db->InParameter($stmt, $s_usr_id, 'user_');
    $db->InParameter($stmt, $elapsed, 'elapsed');
    $db->InParameter($stmt, $comment, 'comm');
    $db->InParameter($stmt, $camp, 'camp');
    $db->InParameter($stmt, $segundos, 'segundosEnllamda');
    $db->InParameter($stmt, $tipo_campana, 'tipoCampana');
    $db->Execute($stmt);
}

##### OBTIENE LAS CALIFICACIONES DE SI CONTACTO

function get_valida_acceso($usr_id, $function, $languaje, $db) {
    $rs = $db->ExecuteCursor("BEGIN xsp_verifyAccess(" . $usr_id . ", " . $function . ", " . $languaje . ", :rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

#####  REALIZA LA BUSQUEDA DE LOS CLIENTES EN LA BASE DE DATOS

function set_busca_cliente($solicitud, $nombre, $paterno, $materno, $agente, $telefono, $db) {
    $rs = $db->ExecuteCursor("BEGIN TDCAMEXONLINE.XSP_BUSCAREGISTRO(" . $solicitud . ",'" . strtoupper($nombre) . "','" . strtoupper($paterno) . "','" . strtoupper($materno) . "', " . $agente . "," . $telefono . " ,:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

#####  REALIZA LA BUSQUEDA DE LOS DATOS DE CLIENTES EN LA BASE DE DATOS

function set_busca_datos($db, $solicitud = null, $nombre = null, $paterno = null, $materno = null, $clave = null, $rfc = null, $telefono = null, $tipo = null, $agente = null) {
    $db->SetFetchMode(ADODB_FETCH_ASSOC);
    try {
        $query = "BEGIN SPS_BUSQUEDACLIENTE(:tipo, :nombre, :paterno, :materno, :solicitud, :clave, :telefono, :rfc, :rc); END;";
        $stmt = $db->PrepareSP($query);
        $db->InParameter($stmt, $tipo, 'tipo');
        $db->InParameter($stmt, $nombre, 'nombre');
        $db->InParameter($stmt, $paterno, 'paterno');
        $db->InParameter($stmt, $materno, 'materno');
        $db->InParameter($stmt, $rfc, 'rfc');
        $db->InParameter($stmt, $telefono, 'telefono');
        $db->InParameter($stmt, $clave, 'clave');
        $db->InParameter($stmt, $solicitud, 'solicitud');
        $rs = $db->ExecuteCursor($stmt, 'rc');
    } catch (exception $e) {
        pa($e->getTrace());
        die();
        exit();
    }

    return $rs;
}

#####  REALIZA LA BUSQUEDA DE LOS DATOS DE CLIENTES EN LA BASE DE DATOS

function set_busca_datos2($db, $solicitud = null, $nombre = null, $paterno = null, $materno = null, $clave = null, $rfc = null, $telefono = null, $tipo = null, $agente = null, $busqueda = null) {
    $db->SetFetchMode(ADODB_FETCH_ASSOC);
//    $query = "BEGIN CSP_GETLISTACLIENTES(:nombre, :paterno, :materno, :rfc, :telefono, :clave, :solicitud, :rc); END;";
//    $stmt = $db->PrepareSP($query);
//    $db->InParameter($stmt, $nombre, 'nombre');
//    $db->InParameter($stmt, $paterno, 'paterno');
//    $db->InParameter($stmt, $materno, 'materno');
//    $db->InParameter($stmt, $rfc, 'rfc');
//    $db->InParameter($stmt, $telefono, 'telefono');
//    $db->InParameter($stmt, $clave, 'clave');
//    $db->InParameter($stmt, $solicitud, 'solicitud');
    try {
        $query = "BEGIN SPS_BUSQUEDACLIENTE2(:tipo, :nombre, :paterno, :materno, :solicitud, :clave, :telefono, :rfc, :busqueda, :rc); END;";
        $stmt = $db->PrepareSP($query);
        $db->InParameter($stmt, $tipo, 'tipo');
        $db->InParameter($stmt, $nombre, 'nombre');
        $db->InParameter($stmt, $paterno, 'paterno');
        $db->InParameter($stmt, $materno, 'materno');
        $db->InParameter($stmt, $rfc, 'rfc');
        $db->InParameter($stmt, $telefono, 'telefono');
        $db->InParameter($stmt, $clave, 'clave');
        $db->InParameter($stmt, $solicitud, 'solicitud');
        $db->InParameter($stmt, $busqueda, 'busqueda');
        $rs = $db->ExecuteCursor($stmt, 'rc');
    } catch (exception $e) {
        pa($e->getTrace());
        die();
        exit();
    }

    return $rs;
}

#####  REALIZA LA BUSQUEDA DE LOS DATOS DE SOLICITUD EN LA BASE DE DATOS (Mantenimiento)

function set_datos_solicitud($customerid, $surveyid, $user, $db) {
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    $query = "BEGIN sps_DatosSolicitud_SJR(:customerid, :surveyid, :user, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $customerid, 'customerid');
    $db->InParameter($stmt, $surveyid, 'surveyid');
    $db->InParameter($stmt, $user, 'user');
    $rs = $db->ExecuteCursor($stmt, 'rc');

    return $rs;
}

#####  REALIZA LA BUSQUEDA DE LOS DATOS DE SOLICITUD EN LA BASE DE DATOS (Mantenimiento)

function set_datos_empresas($estado, $municipio, $empresa, $db) {
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    $query = "BEGIN SPS_EMPRESAS(:estado, :municipio, :empresa, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $estado, 'estado');
    $db->InParameter($stmt, $municipio, 'municipio');
    $db->InParameter($stmt, $empresa, 'empresa');
    $rs = $db->ExecuteCursor($stmt, 'rc');

    return $rs;
}

#####  REALIZA LA BUSQUEDA DE LOS CLIENTES EN LA BASE DE DATOS

function get_registro_especifico($u_registro, $usr_id, $tipo_campana, $db) {
    $query = "BEGIN TDCAMEXONLINE.XSP_GETREGISTROESPECIFICO(:registro,:u_user,:tipo_campana,:rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $u_registro, 'registro');
    $db->InParameter($stmt, $usr_id, 'u_user');
    $db->InParameter($stmt, $tipo_campana, 'tipo_campana');
    $rs = $db->ExecuteCursor($stmt, 'rc');
//$db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

#####  INSERT UN NUEVO REGISTRO EN BASE

function set_registro_especifico($campana, $usr_id, $nombre, $paterno, $materno, $rfc, $fec_nacimiento, $pais, $lada, $telefono, $localizacion, $tipobase, $db) {
    
/* echo $campana . "*<br>*". $usr_id. "*<br>*".$nombre. "*<br>*".$paterno. "*<br>*".$materno. "*<br>*".$rfc. "*<br>*".$fec_nacimiento. "*<br>*".$pais. "*<br>*".$lada. "*<br>*".$telefono. "*<br>*".$localizacion. "*<br>*".$tipobase;
 */
/* echo "m_e: ". $mensaje_error;
die(); 
 */
    $stmt = $db->PrepareSP("BEGIN tdcamexonline.xsp_insertaRegistroTelefonico3(:campana, :usr_id, :nombre, :paterno, :materno, :rfc, :fec_nacimiento, :pais, :lada, :telefono, :localizacion, :u_persona, :u_telefono, :u_registro, :tipobase,:mensaje_error); END;");
    $db->InParameter($stmt, $campana, 'campana');
    $db->InParameter($stmt, $usr_id, 'usr_id');
    $db->InParameter($stmt, $nombre, 'nombre');
    $db->InParameter($stmt, $paterno, 'paterno');
    $db->InParameter($stmt, $materno, 'materno');
    $db->InParameter($stmt, $rfc, 'rfc');
    $db->InParameter($stmt, $fec_nacimiento, 'fec_nacimiento');
    $db->InParameter($stmt, $pais, 'pais');
    $db->InParameter($stmt, $lada, 'lada');
    $db->InParameter($stmt, $telefono, 'telefono');
    $db->InParameter($stmt, $localizacion, 'localizacion');
    
    $db->OutParameter($stmt, $u_persona, 'u_persona');
    $db->OutParameter($stmt, $u_telefono, 'u_telefono');
    $db->OutParameter($stmt, $u_registro, 'u_registro');

    $db->InParameter($stmt, $tipobase, 'tipobase');
    $db->OutParameter($stmt, $mensaje_error, 'mensaje_error');
    $db->Execute($stmt);

    return $u_persona . '-' . $u_telefono . '-' . $u_registro . '-' . $mensaje_error;
}

#####  INSERT UN NUEVO REGISTRO EN BASE

function set_relacion_registro($referente, $referido, $tipobase, $db) {
    $stmt = $db->PrepareSP("BEGIN XSP_INSERTARELACIONREGISTRO_WS(:referente, :referido, :tipobase); END;");
    $db->InParameter($stmt, $referente, 'referente');
    $db->InParameter($stmt, $referido, 'referido');
    $db->InParameter($stmt, $tipobase, 'tipobase');
    $db->Execute($stmt);
}

#####  VERIFICA QUE LA SOLICITUD SE ENCUENTRE EN SURVEYPERSONAS

function set_valida_solicitud_capturada($id_registro, $db) {
    $stmt = $db->PrepareSP("BEGIN xsp_isSolicitudOK(:id_solicitud, :res); END;");
    $db->InParameter($stmt, $id_registro, 'id_solicitud');
    $db->OutParameter($stmt, $res, 'res');
    $db->Execute($stmt);
    return $res;
}

#####  ACTUALIZA VALIDANDO A 2 PARA VER LA SOLICITU EN VALIDACION

function set_valida_solicitud($id_solicitud, $id_producto, $bandera, $segundosllamda, $origen, $db) {
    $stmt = $db->PrepareSP("BEGIN TDCAMEXONLINE.XSP_BLOQUEOVALIDACION(:id_solicitud, :id_producto, :bandera, :segundosllamda, :origen); END;");
    $db->InParameter($stmt, $id_solicitud, 'id_solicitud');
    $db->InParameter($stmt, $id_producto, 'id_producto');
    $db->InParameter($stmt, $bandera, 'bandera');
    $db->InParameter($stmt, $segundosllamda, 'segundosllamda');
    $db->InParameter($stmt, $origen, 'origen');

    $db->Execute($stmt);
}

##### DEVUELVE INFORMACION DE LOS REGISTROS AGENDADOS POR AGENTE

function get_detalle_agendados_usuario($id_usr, $anio, $mes, $dia, $campana, $db) {
    $rs = $db->ExecuteCursor("BEGIN XSP_GETAGENDAXFECHA(" . $id_usr . ", " . $anio . ", " . $mes . ", " . $dia . ", " . $campana . ", :rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

##### DEVUELVE INFORMACION DEL 01800

function get_detalle_01800_usuario($s_usr_id, $anio, $mes, $dia, $db) {
    $rs = $db->ExecuteCursor("BEGIN SOL_REPORTE01800_WS(" . $s_usr_id . ", " . $anio . ", " . $mes . ", " . $dia . ", :rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

##### DEVUELVE INFORMACION DE LAS MEDIAS HORAS

function get_medias_horas($u_media_hora, $db) {
    $rs = $db->ExecuteCursor("BEGIN CSP_GETMEDIASHORAS(" . $u_media_hora . ", :rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

##### DEVUELVE INFORMACION DE LAS MEDIAS HORAS

function get_lista_medias_horas($number, $db) {
    $rs = $db->ExecuteCursor("BEGIN CSP_GETLISTAMEDIASHORAS(:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

##### INSERTA UN NUEVO REGISTRO TELFONICO

function set_nuevo_telefono($id_solicitud, $lada, $telefono, $tipo, $s_usr_id, $db) {
    //$stmt = $db->PrepareSP("BEGIN xsp_setNuevoTelefono3(:v_u_persona, :v_lada, :v_telefono, :v_tipo, :mensaje_error); END;"); //, :mensaje_error
    $stmt = $db->PrepareSP("BEGIN tdcamexonline.xsp_setNuevoTelefono2(:v_u_persona, :v_lada, :v_telefono, :v_tipo, :v_u_user,:v_bl_reus); END;"); //, :mensaje_error
    $db->InParameter($stmt, $id_solicitud, 'v_u_persona');
    $db->InParameter($stmt, $lada, 'v_lada');
    $db->InParameter($stmt, $telefono, 'v_telefono');
    $db->InParameter($stmt, $tipo, 'v_tipo');
    $db->InParameter($stmt, $s_usr_id, 'v_u_user');
    $db->OutParameter($stmt, $bl_reus, 'v_bl_reus');
    //$db->OutParameter($stmt, $mensaje_error, 'mensaje_error');
    $db->Execute($stmt);

    return $bl_reus;
}

##### DEVUELVE EL CUESTIONARIO

function get_cuestionario($producto, $lang, $exist, $name, $desc, $db) {
    $stmt = $db->PrepareSP("BEGIN proc_Survey_GetSurvey(:SurveyId_, :Lang, :Exist, :Name_, :Desc_); END;");
    $db->InParameter($stmt, $producto, 'SurveyId_');
    $db->InParameter($stmt, $lang, 'Lang');
    $db->OutParameter($stmt, $exist, 'Exist');
    $db->OutParameter($stmt, $name, 'Name_');
    $db->OutParameter($stmt, $desc, 'Desc_');
    $db->Execute($stmt);

    return $name . '-' . $desc;
}

##### DEVUELVE LAS PREGUNTAS DE LA SOLICITUD

function get_preguntas($producto, $solicitud, $lang, $exist, $db) {

    $stmt = $db->PrepareSP("BEGIN TDCAMEXONLINE.PROC_SURVEY_GETQUESTIONS(:SurveyId_ ,:Lang, :Exist, :rc); END;");
    $db->InParameter($stmt, $producto, 'SurveyId_');
    $db->InParameter($stmt, $lang, 'Lang');
    $db->InParameter($stmt, $exist, 'Exist');
    $db->OutParameter($stmt, $rc, 'rc');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

##### DEVUELVE LAS REPUESTAS DE LAS PREGUNTAS

function get_respuestas($producto, $question, $lang, $solicitud, $mostrar, $exist, $db) {
    
    $stmt = $db->PrepareSP("BEGIN TDCAMEXONLINE.PROC_SURVEY_GETQUESTCHOICESCU2(:SurveyId_, :QuestionId_, :Lang, :persona, :mostrar, :Exist, :rc); END;");
    $db->InParameter($stmt, $producto, 'SurveyId_');
    $db->InParameter($stmt, $question, 'QuestionId_');
    $db->InParameter($stmt, $lang, 'Lang');
    $db->InParameter($stmt, $solicitud, 'persona');
    $db->InParameter($stmt, $mostrar, 'mostrar');
    $db->InParameter($stmt, $exist, 'Exist');
    $db->OutParameter($stmt, $rc, 'rc');
    $rs = $db->ExecuteCursor($stmt, 'rc');

    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

##### DEVUELVE LAS REPUESTAS POR DEFAUL
function get_respuestas_default($solicitud, $field, $db) {
    $stmt = $db->PrepareSP("BEGIN PROC_SURVEY_GETQUESTIONDEFAULT(:user_, :field, :rc); END;");
    $db->InParameter($stmt, $solicitud, 'user_');
    $db->InParameter($stmt, $field, 'field');
    $db->OutParameter($stmt, $rc, 'rc');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

##### DEVUELVE LOS VALORES DE UN QUERY DE LA SOLICITUD

function get_datos_query($query, $db) {

    $stmt = $db->PrepareSP("BEGIN " . $query . "(:rc); END;");
    $db->OutParameter($stmt, $rc, 'rc');
    $rs = $db->ExecuteCursor($stmt, 'rc');

    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

function get_datos_query2($query, $db) {

    $stmt = $db->PrepareSP("BEGIN " . $query . "; END;");
    $db->OutParameter($stmt, $rc, 'rc');
    $rs = $db->ExecuteCursor($stmt, 'rc');

    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

##### DEVUELVE LOS VALORES DE UN QUERY DE LA SOLICITUD PARA LOS CAMPOS CODIGO POSTAL
function get_datos_query_CP($query, $cp, $id, $db) {

    $stmt = $db->PrepareSP("BEGIN TDCAMEXONLINE." . $query . "(:cp, :rc); END;");
    $db->InParameter($stmt, $cp, 'cp');
    $rs = $db->ExecuteCursor($stmt, 'rc');

    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

##### ELIMINA LA SOLICITUD DEL PRODUCTO Y SOLICITUD

function set_delete_survey($id_solicitud, $id_producto, $lang, $db) {
    $stmt = $db->PrepareSP("BEGIN TDCAMEXONLINE.PROC_DELETESURVEY(:varUserID, :varSurveyID, :Lang); END;");
    $db->InParameter($stmt, $id_solicitud, 'varUserID');
    $db->InParameter($stmt, $id_producto, 'varSurveyID');
    $db->InParameter($stmt, $lang, 'Lang');
    $db->Execute($stmt);
}

##### GUARDA LOS QUESTIONDS LA SOLICITUD EN SURVEYRESPONSE

function set_insert_survey($id_solicitud, $id_producto, $questionid, $choiceid, $date, $response, $lang, $db) {
    $stmt = $db->PrepareSP("BEGIN TDCAMEXONLINE.PROC_INSERTSURVEYINT(:varUserID, :varSurveyID, :varQuestionNo, :varChoiceNo, :responseDate, :responseNo, :Lang); END;");
    $db->InParameter($stmt, $id_solicitud, 'varUserID');
    $db->InParameter($stmt, $id_producto, 'varSurveyID');
    $db->InParameter($stmt, $questionid, 'varQuestionNo');
    $db->InParameter($stmt, $choiceid, 'varChoiceNo');
    $db->InParameter($stmt, $date, 'responseDate');
    $db->InParameter($stmt, $response, 'responseNo');
    $db->InParameter($stmt, $lang, 'Lang');
    $db->Execute($stmt);
}

##### GUARDA LOS DATOS DE LA SOLICITUD EN SURVEYRESPONSE

function set_update_results($id_solicitud, $id_producto, $questionid, $choiceid, $lang, $respuesta, $db) {
    $stmt = $db->PrepareSP("BEGIN TDCAMEXONLINE.PROC_UPDATESURVEYRESULTS(:varUserID, :varSurveyID, :varQuestionNo, :varChoiceNo, :Lang, :responseText); END;");
    $db->InParameter($stmt, $id_solicitud, 'varUserID');
    $db->InParameter($stmt, $id_producto, 'varSurveyID');
    $db->InParameter($stmt, $questionid, 'varQuestionNo');
    $db->InParameter($stmt, $choiceid, 'varChoiceNo');
    $db->InParameter($stmt, $lang, 'Lang');
    $db->InParameter($stmt, $respuesta, 'responseText');
    $db->Execute($stmt);
}

##### GUARDA LOS DATOS DE LA SOLICITUD EN SURVEYPERSONAS MODO PROCESAR

function set_datos_solicitud_exitosa($id_registro, $id_producto, $id_solicitud,$u_telefono, $grabacion, $s_usr_id, $db) {
    $stmt = $db->PrepareSP("BEGIN TDCAMEXONLINE.XSP_SOLICITUDEXITOSAVALIDACION(:p_registro, :p_solicitud, :p_u_persona, :p_u_telefono, :p_grabacion, :p_u_user); END;");
    $db->InParameter($stmt, $id_registro, 'p_registro');
    $db->InParameter($stmt, $id_producto, 'p_solicitud');
    $db->InParameter($stmt, $id_solicitud, 'p_u_persona');
    $db->InParameter($stmt, $u_telefono, 'p_u_telefono');
    $db->InParameter($stmt, $grabacion, 'p_grabacion');
    $db->InParameter($stmt, $s_usr_id, 'p_u_user');
    $db->Execute($stmt);
}

##### GUARDA LOS DATOS DE LA SOLICITUD EN SURVEYPERSONAS MODO GUARDAR
function set_datos_solicitud_exitosa_s($id_registro, $id_producto, $id_solicitud, $db) {
    $stmt = $db->PrepareSP("BEGIN TDCAMEXONLINE.XSP_SOLICITUDEXITOSA_SAVE(:p_registro, :p_solicitud, :p_u_persona); END;");
    $db->InParameter($stmt, $id_registro, 'p_registro');
    $db->InParameter($stmt, $id_producto, 'p_solicitud');
    $db->InParameter($stmt, $id_solicitud, 'p_u_persona');
    $db->Execute($stmt);
}


##### MUESTRA LA LISTA DE LOS PRODUTOS POR CAMPANA
function get_productos_campana($id_solicitud,$db) {
     $stmt = $db->PrepareSP("BEGIN TDCAMEXONLINE.CSP_GETPRODUCTOS_VALIDACION(:u_persona, :rc); END;");//-- Solo se ocupa si se vende por base o producto
      $db->InParameter($stmt, $id_solicitud, 'u_persona');
      $rs = $db->ExecuteCursor($stmt, 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}


##### INSERTA UN NUEVO REGISTRO REFERIDO
function set_guarda_referido($s_usr_id, $id_solicitud, $id_producto, $tipo_registro1, $nombre1, $nombre1_2, $paterno1, $materno1, $lada1_1, $telefono1_1/*, $lada1_2, $telefono1_2*/, $tipo_registro2, $nombre2, $nombre2_2, $paterno2, $materno2, $lada2_1, $telefono2_1/*, $lada2_2, $telefono2_2*/, $tipo_registro3, $nombre3, $nombre3_2, $paterno3, $materno3, $lada3_1, $telefono3_1/*, $lada3_2, $telefono3_2*/, $db) {
    $stmt = $db->PrepareSP("BEGIN tdcamexonline.XSP_INSERTAREGISTROREFERIDO(:P_User, :P_Customerid, :P_surveyid, :P_Tipo_registro_1, :P_Nombre1_1, :P_Nombre1_2 , :P_Paterno1, :P_Materno1, :P_Lada1_1, :P_Telefono1_1, :P_Tipo_registro_2, :P_Nombre2, :P_Nombre2_2, :P_Paterno2, :P_Materno2, :P_Lada2_1, :P_Telefono2_1, :P_Tipo_registro_3, :P_Nombre3, :P_Nombre3_2, :P_Paterno3, :P_Materno3, :P_Lada3_1, :P_Telefono3_1); END;");
    $db->InParameter($stmt, $s_usr_id, 'P_User');
    $db->InParameter($stmt, $id_solicitud, 'P_Customerid');
    $db->InParameter($stmt, $id_producto, 'P_surveyid');

    $db->InParameter($stmt, $tipo_registro1, 'P_Tipo_registro_1');
    $db->InParameter($stmt, $nombre1, 'P_Nombre1_1');
    $db->InParameter($stmt, $nombre1_2, 'P_Nombre1_2');
    $db->InParameter($stmt, $paterno1, 'P_Paterno1');
    $db->InParameter($stmt, $materno1, 'P_Materno1');
    $db->InParameter($stmt, $lada1_1, 'P_Lada1_1');
    $db->InParameter($stmt, $telefono1_1, 'P_Telefono1_1');

    $db->InParameter($stmt, $tipo_registro2, 'P_Tipo_registro_2');
    $db->InParameter($stmt, $nombre2, 'P_Nombre2');
    $db->InParameter($stmt, $nombre2_2, 'P_Nombre2_2');
    $db->InParameter($stmt, $paterno2, 'P_Paterno2');
    $db->InParameter($stmt, $materno2, 'P_Materno2');
    $db->InParameter($stmt, $lada2_1, 'P_Lada2_1');
    $db->InParameter($stmt, $telefono2_1, 'P_Telefono2_1');

    $db->InParameter($stmt, $tipo_registro3, 'P_Tipo_registro_3');
    $db->InParameter($stmt, $nombre3, 'P_Nombre3');
    $db->InParameter($stmt, $nombre3_2, 'P_Nombre3_2');
    $db->InParameter($stmt, $paterno3, 'P_Paterno3');
    $db->InParameter($stmt, $materno3, 'P_Materno3');
    $db->InParameter($stmt, $lada3_1, 'P_Lada3_1');
    $db->InParameter($stmt, $telefono3_1, 'P_Telefono3_1');
    $db->Execute($stmt);
}

##### VALIDA QUE EL RFC NO EXISTA EN LA APLICACION

function get_valida_rfc($id_solicitud, $id_producto, $num_reconocedor, $lang, $rfc, $existe, $db) {
    $stmt = $db->PrepareSP("BEGIN TDCAMEXONLINE.proc_CompareSurveyResults_WS1(:varUserID, :varSurveyID, :Varrecnocedor, :Lang, :responseText, :YaExiste); END;");
    $db->InParameter($stmt, $id_solicitud, 'varUserID');
    $db->InParameter($stmt, $id_producto, 'varSurveyID');
    $db->InParameter($stmt, $num_reconocedor, 'Varrecnocedor');
    $db->InParameter($stmt, $lang, 'Lang');
    $db->InParameter($stmt, $rfc, 'responseText');
    $db->OutParameter($stmt, $existe, 'YaExiste');
    $db->Execute($stmt);

    return $existe;
}

function get_datos_valida_rfc($id_solicitud, $db) {
    $stmt = $db->PrepareSP("BEGIN TDCAMEXONLINE.SPS_RESULTRFC_WS_P(:customerid,:rc); END;");
    $db->InParameter($stmt, $id_solicitud, 'customerid');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    $rs = $db->ExecuteCursor($stmt, 'rc');

    return $rs;
}

##### MUESTRA LA LISTA DE LOS PRODUTOS POR CAMPANA


function get_datos_complementarios($id_solicitud, $db) {
    $rs = $db->ExecuteCursor("BEGIN TDCAMEXONLINE.CSP_GETDATOSSOLICITUD_WS(" . $id_solicitud . ", :rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);

    return $rs;
}

##### OBTIENE LOS DATOS PREVIAMENTE GUARDADOS DE LA SOLICITUD

function get_datos_grabados($id_solicitud ,$id_producto , $db) {
    $rs = $db->ExecuteCursor("BEGIN TDCAMEXONLINE.PROC_SURVEY_GETQUESTCHOICESCU3(" . $id_solicitud  . ",".$id_producto  . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);

    return $rs;
}

##### OBTIENE LOS DATOS DE BASE LONG APP

function get_datos_long_app($id_solicitud, $db) {
    //return $id_solicitud;
  $rs = $db->ExecuteCursor("BEGIN TDCAMEXONLINE.PROC_SURVEY_GETDATALONGAPP(" . $id_solicitud  . ", :rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);

    if (!$rs) {
        var_dump("Error al ejecutar el procedimiento almacenado: " . $db->ErrorMsg());
        return false;
    } else {
        return $rs;
    } 
}



/* function get_datos_long_app($id_solicitud, $db) {
    //return $db;
    $rs = $db->ExecuteCursor("BEGIN TDCAMEXONLINE.PROC_SURVEY_GETDATALONGAPP(" . $id_solicitud  . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    
    if (!$rs) {
        //return "jswefrhiwjksdf";
        die($db->ErrorMsg());
    }else{
        return $rs;
    } 
}  */

# OBTIENE UN NUEVO REGISTRO

function get_detalle_solicitud($s_usr_id, $db) {
    $rs = $db->ExecuteCursor("BEGIN SPS_DETALLESSOLICITUD(" . $s_usr_id . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

function get_detalle_telefono($s_usr_id, $action, $db) {
    $rs = $db->ExecuteCursor("BEGIN SPS_DETALLESTELEFONO(" . $s_usr_id . "," . $action . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# OBTIENE LA LISTA DE CATALOGOS DE FORMA DINAMICA

function get_catalogo($v_id_campo, $db) {
    $rs = $db->ExecuteCursor("BEGIN spS_Catalogo('" . $v_id_campo . "',:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# OBTIENE LA LISTA DE CATALOGOS DE FORMA DINAMICA

function get_catalogo_prod($v_id_campo, $p_id_etapa, $db) {
    $rs = $db->ExecuteCursor("BEGIN SPS_CATALOGO_PROD('" . $v_id_campo . "'," . $p_id_etapa . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# OBTIENE LA LISTA DE CATALOGOS DE FORMA DINAMICA

function get_catalogo_prod_in($v_id_campo, $p_id_etapa, $db) {
    $rs = $db->ExecuteCursor("BEGIN SPS_CATALOGO_PROD_IN('" . $v_id_campo . "'," . $p_id_etapa . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# OBTIENE LA LISTA DE CATALOGOS DE FORMA DINAMICA PARA LA ZONA 998 (VISITAS DOMICILIARIAS)

function get_catalogo_prod_in_vd($v_id_campo, $p_id_etapa, $db) {
    $rs = $db->ExecuteCursor("BEGIN SPS_CATALOGO_PROD_IN_VD('" . $v_id_campo . "'," . $p_id_etapa . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# OBTIENE LA LISTA DE CATALOGOS DE FORMA DINAMICA PARA IN

function get_catalogoin($v_id_campo, $db) {
    $rs = $db->ExecuteCursor("BEGIN spS_CatalogoIn('" . $v_id_campo . "',:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# CALIFICA EL NUMERO DE TELEFONO DE UN REGISTRO

function set_calificacion_telefono($p_solicitud, $p_telefono, $p_calificacion, $etapa, $db) {
    $stmt = $db->PrepareSP("BEGIN SPX_CALIFICA_TELEFONO(:p_solicitud, :p_telefono, :p_calificacion, :p_etapa, :p_actualiza); END;");
    $db->InParameter($stmt, $p_solicitud, 'p_solicitud');
    $db->InParameter($stmt, $p_telefono, 'p_telefono');
    $db->InParameter($stmt, $p_calificacion, 'p_calificacion');
    $db->InParameter($stmt, $etapa, 'p_etapa');
    $db->OutParameter($stmt, $p_actualiza, 'p_actualiza');
    $db->Execute($stmt);
    return $p_actualiza;
}

# CALIFICA LOS NUMEROS DE TELEFONO DE UN REGISTRO

function set_calificacion_telefono_in($p_user, $p_solicitud, $p_calificacion, $db) {
    $stmt = $db->PrepareSP("BEGIN SPX_CALIFICA_TELEFONO_IN(:p_user, :p_solicitud, :p_calificacion, :p_actualiza); END;");
    $db->InParameter($stmt, $p_user, 'p_user');
    $db->InParameter($stmt, $p_solicitud, 'p_solicitud');
    $db->InParameter($stmt, $p_calificacion, 'p_calificacion');
    $db->OutParameter($stmt, $p_actualiza, 'p_actualiza');
    $db->Execute($stmt);
    return $p_actualiza;
}

# BUSCA LA CALIFICACION PARA VERIFICAR SI EL REGISTRO FUE ABANDONADO

function set_busca_calif_reg_in($p_solicitud, $db) {
    $stmt = $db->PrepareSP("BEGIN SPS_BUSCA_CAL_REG_IN(:p_solicitud, :p_calif); END;");
    $db->InParameter($stmt, $p_solicitud, 'p_solicitud');
    $db->OutParameter($stmt, $p_calif, 'p_calif');
    $db->Execute($stmt);
    return $p_calif;
}

#MUESTRA SCRIPT A MOSTRAR

function set_muestra_script($id_solicitud, $db) {
    $stmt = $db->PrepareSP("BEGIN SPS_MUESTRA_SCRIPT(:p_solicitud, :p_script); END;");
    $db->InParameter($stmt, $id_solicitud, 'p_solicitud');
    $db->OutParameter($stmt, $p_script, 'p_script');
    $db->Execute($stmt);

    return $p_script;
}

#TRAE LOS BINES  DE LAS TDC

function get_bines($db) {
    $rs = $db->ExecuteCursor("BEGIN SPS_BINES(:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    $cont = 0;
    while (!$rs->EOF) {
        $bines .= $rs->fields["CPREFIJO"] . ',';
        $cont = $cont + 1;
        $rs->MoveNext();
    }

    return substr($bines . '0', 0, strlen($bines . '0') - 2);
}

##### ABANDONA EL REGISTRO PARA SALIR DE LA APLICACION

function set_libera_solicitud($id_registro, $elapsed, $camp, $db) {
    $stmt = $db->PrepareSP("BEGIN TDCAMEXONLINE.XSP_LIBERAREGISTRO(:reg, :elapsed, :tipoCampana); END;");
    $db->InParameter($stmt, $id_registro, 'reg');
    $db->InParameter($stmt, $elapsed, 'elapsed');
    $db->InParameter($stmt, $camp, 'tipoCampana');
    $db->Execute($stmt);
}

##### BLOQUEA EL REGISTRO CLIENTE MUY MOLESTO

function set_bloquea_cliente_molesto($id_registro, $cal, $status, $db) {
    $stmt = $db->PrepareSP("BEGIN TDCAMEXONLINE.XSP_BLOQUEAREGISTRO_CM(:reg, :cal, :status); END;");
    $db->InParameter($stmt, $id_registro, 'reg');
    $db->InParameter($stmt, $cal, 'cal');
    $db->InParameter($stmt, $status, 'status');
    $db->Execute($stmt);
}

##### ELIMINA EL REGISTRO DE LLAMADAS AGENDADAS PARA NO VOLVERLO A TOMAR

function set_libera_agendado($id_registro, $s_usr_id, $db) {
    $stmt = $db->PrepareSP("BEGIN TDCAMEXONLINE.XSP_LIBERAAGENDA(:id_registro, :s_usr_id); END;");
    $db->InParameter($stmt, $id_registro, 'id_registro');
    $db->InParameter($stmt, $s_usr_id, 's_usr_id');
    $db->Execute($stmt);
}

##### AGENDA EL REGISTRO CON SUS RESPECTIVOS COMENTARIOS

function set_agenda_registro($s_usr_id, $id_registro, $anio, $mes, $day, $hora, $nombre, $comentarios, $camp, $db) {
    $stmt = $db->PrepareSP("BEGIN TDCAMEXONLINE.XSP_SETAGENDAXFECHA(:agente, :reg, :ano, :mes, :dia, :media, :nombre_, :comment_, :camp); END;");
    $db->InParameter($stmt, $s_usr_id, 'agente');
    $db->InParameter($stmt, $id_registro, 'reg');
    $db->InParameter($stmt, $anio, 'ano');
    $db->InParameter($stmt, $mes, 'mes');
    $db->InParameter($stmt, $day, 'dia');
    $db->InParameter($stmt, $hora, 'media');
    $db->InParameter($stmt, $nombre, 'nombre_');
    $db->InParameter($stmt, $comentarios, 'comment_');
    $db->InParameter($stmt, $camp, 'camp');
    $db->Execute($stmt);
//return $v_actualizado;
}

# DEVUELVE EL DETALLE DEL REGISTRO AGENDADO

function get_detalle_agendado($s_usr_id, $db) {
    $rs = $db->ExecuteCursor("BEGIN SPS_DETALLESAGENDADO(" . $s_usr_id . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# DEVUELVE LOS REGISTROS AGENDADOS POR EL AGENTE

function get_registros_agendado($s_usr_id, $db) {
    $rs = $db->ExecuteCursor("BEGIN TDCAMEXONLINE.XSP_GETLLAMADASAGENDADAS(" . $s_usr_id . ", 1, :rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# DEVUELVE LOS COMENTARIOS DE LAS DISTINTAS AGENDAS

function get_comentarios_agenda($s_usr_id, $db) {
    $rs = $db->ExecuteCursor("BEGIN SPS_COMENTARIOASAGENDA(" . $s_usr_id . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# DATOS DEL CLIENTE

function get_detalle_cliente($id_solicitud, $db) {
    $rs = $db->ExecuteCursor("BEGIN SPS_DETALLE_CLIENTE(" . $id_solicitud . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# CALIFICA LOS REGISTROS PARA LOS CASOS DE FINADO Y NO QUIERE QUE LO MOLESTEN

function set_califica_registros($id_solicitud, $cal_reg, $producto, $db) {
    $rs = $db->ExecuteCursor("BEGIN SPU_CALIFICAREGISTRO(" . $id_solicitud . "," . $cal_reg . "," . $producto . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# CALIFICA LOS REGISTROS PARA LA BUSQUEDA DE CLIENTES IN

function set_califica_registros_in($id_solicitud, $calificacion, $db) {
    $rs = $db->ExecuteCursor("BEGIN SPU_CALIFICAREGISTRO_IN(" . $id_solicitud . "," . $calificacion . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# GUARDA EL HISTORICO DE LA CALIFICACION DE LOS TELEFONOS

function set_telefono_historico($s_usr_id, $id_solicitud, $telefono, $calificacion, $db) {
    $stmt = $db->PrepareSP("BEGIN SPI_TEL_CAL_HISTO(:p_id_user, :p_id_solicitud, :p_telefono, :p_calificacion); END;");
    $db->InParameter($stmt, $s_usr_id, 'p_id_user');
    $db->InParameter($stmt, $id_solicitud, 'p_id_solicitud');
    $db->InParameter($stmt, $telefono, 'p_telefono');

    $db->Execute($stmt);
}
function sms_calf_($s_usr_id, $id_solicitud, $calificacion,$Razon,$estado, $db){
    $stmt = $db->PrepareSP("BEGIN TDCAMEXONLINE.SPI_LOG_PREG_DETALLE(:V_CUSTOMERID, :v_logged_user, :v_calificacion,:v_Razon,:v_estado,:v_resultado); END;");
    $db->InParameter($stmt, $id_solicitud, 'V_CUSTOMERID');
    $db->InParameter($stmt, $s_usr_id, 'v_logged_user');
    $db->InParameter($stmt, $calificacion, 'v_calificacion');
    $db->InParameter($stmt, $Razon, 'v_Razon');
    $db->InParameter($stmt, $estado, 'v_estado');
    $db->OutParameter($stmt, $v_resultado, 'v_resultado');
    $db->Execute($stmt);
    return $v_resultado;
}
/*
function sms_calf($s_usr_id, $id_solicitud, $calificacion, $db){
    $stmt = $db->PrepareSP("BEGIN TDCAMEXONLINE.SPI_LOG_PREG_SMS(:V_CUSTOMERID, :v_logged_user, :v_calificacion,:v_resultado); END;");
    $db->InParameter($stmt, $id_solicitud, 'V_CUSTOMERID');
    $db->InParameter($stmt, $s_usr_id, 'v_logged_user');
    $db->InParameter($stmt, $calificacion, 'v_calificacion');
    $db->OutParameter($stmt, $v_resultado, 'v_resultado');
    $db->Execute($stmt);
    return $v_resultado;
}  */




# ACTUALIZA A 0 LA CALIFICACION DE LOS TELEFONOS CUANDO EL REGISTRO ES ABANDONADO

function set_libera_telefonos_abandonado($id_solicitud, $s_usr_id, $producto, $db) {
    $stmt = $db->PrepareSP("BEGIN SPU_LIBERATELEFONOS(:p_id_solicitud, :s_usr_id, :p_producto); END;");
    $db->InParameter($stmt, $id_solicitud, 'p_id_solicitud');
    $db->InParameter($stmt, $s_usr_id, 's_usr_id');
    $db->InParameter($stmt, $producto, 'p_producto');
    $db->Execute($stmt);
}

# OBTIENE LA LISTA DE CATALOGOS DE FORMA DINAMICA

function get_subcatalogo($v_id_campo, $calif, $etapa, $id_solicitud, $db) {
    $rs = $db->ExecuteCursor("BEGIN spS_Sub_Catalogo('" . $v_id_campo . "'," . $calif . "," . $etapa . "," . $id_solicitud . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# REGRESA LAS CALIFICACIONES Contacto No Efectivo

function get_calcne($id_etapa, $db) {
    $rs = $db->ExecuteCursor("BEGIN SPS_CALCNE(" . $id_etapa . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# REGRESA LAS CALIFICACIONES CONSUMIBLES

function get_calconsumibles($id_etapa, $db) {
    $rs = $db->ExecuteCursor("BEGIN SPS_CALCONSUMIBLES(" . $id_etapa . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# REGRESA LA CALIFICACION DE CONTACTO EFECTIVO PARA ENV�AR A LA SOLICITUD // nO SE ESTA UTILIZANDO EN ESTE MOMENTO 22052009

function get_cal_ce_solicitud($id_etapa, $db) {
    $stmt = $db->PrepareSP("BEGIN SPS_CALCESOLICITUD(:p_id_etapa, :p_cal_ce); END;");
    $db->InParameter($stmt, $id_etapa, 'p_id_etapa');
    $db->OutParameter($stmt, $p_cal_ce, 'p_cal_ce');
    $db->Execute($stmt);
    return $p_cal_ce;
}

# REGRESA LAS CALIFICACIONES  CE Y QUE ENV�A A SOLICITUD

function get_cal_ce($id_etapa, $db) {
    $rs = $db->ExecuteCursor("BEGIN SPS_CALCONTACTOEFECTIVO(" . $id_etapa . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# REGRESA LAS DESCRIPCION DE LAS CALIFICACIONES

function get_desc_calif($id_etapa, $db) {
    $rs = $db->ExecuteCursor("BEGIN SPS_DESC_CALIF(" . $id_etapa . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# VERIFICA SI LA CALIFICACION DE CE TIENE O NO UNA SUBCALIF, PARA MOSTRAR LA PREGUNTA EN LA SOLICITUD.

function get_sub_calif($cal_telefono, $db) {
    $stmt = $db->PrepareSP("BEGIN SPS_CAL_SUBCALIF(:p_cal_telefono, :p_ban_subcalif); END;");
    $db->InParameter($stmt, $cal_telefono, 'p_cal_telefono');
    $db->OutParameter($stmt, $p_ban_subcalif, 'p_ban_subcalif');
    $db->Execute($stmt);

    return $p_ban_subcalif;
}

#GUARDA EL SEGUIMEINTO DE UNA SOLICITUD

function set_guardaseguimiento($id_solicitud, $etapa, $calificacion, $statuscalif, $telefono, $maquina, $id_usr, $usr_super, $activo, $id_zona, $sub_calregistro, $id_tipo_evento, $num_intentos, $db) {
    $stmt = $db->PrepareSP("BEGIN SPI_SEGUIMIENTO(:p_solicitud, :p_etapa, :p_calificacion, :p_statuscalif, :p_telefono, :p_id_user, :p_maquina, :p_usr_super, :p_activo, :p_id_zona, :p_sub_calregistro, :p_id_tipo_evento, :p_num_intentos ); END;");
    $db->InParameter($stmt, $id_solicitud, 'p_solicitud');
    $db->InParameter($stmt, $etapa, 'p_etapa');
    $db->InParameter($stmt, $calificacion, 'p_calificacion');
    $db->InParameter($stmt, $statuscalif, 'p_statuscalif');
    $db->InParameter($stmt, $telefono, 'p_telefono');
    $db->InParameter($stmt, $maquina, 'p_maquina');
    $db->InParameter($stmt, $id_usr, 'p_id_user');
    $db->InParameter($stmt, $usr_super, 'p_usr_super');
    $db->InParameter($stmt, $activo, 'p_activo');
    $db->InParameter($stmt, $id_zona, 'p_id_zona');
    $db->InParameter($stmt, $sub_calregistro, 'p_sub_calregistro');
    $db->InParameter($stmt, $id_tipo_evento, 'p_id_tipo_evento');
    $db->InParameter($stmt, $num_intentos, 'p_num_intentos');
    $db->Execute($stmt);
}

# OBTIENE LA INFORMACI�N PARA LA SOLICITUD DE RP1 , RP2 Y PP, SI EXISTE TRAE LA INFORMACION SI NO  EXISTE TRAE LO VACIO.

function get_detalle_solicitud_pp($s_usr_id, $db) {
    $rs = $db->ExecuteCursor("BEGIN SPS_DETALLESSOLICITUD_PP(" . $s_usr_id . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# GUARDA EL ALTA DE UN NUEVO CLIENTE

function set_nuevo_registro($s_usr_id, $nombre, $paterno, $materno, $nombre_completo, $telefono, $tdc, $tipo_tdc, $celular, $email, $db) {
    $stmt = $db->PrepareSP("BEGIN SPI_GUARDAREGISTROLLAMADA(:p_user,:p_nombre,:p_paterno,:p_materno,:p_nombre_completo, :p_telefono , :p_tdc ,:p_tipo_tdc, :p_celular, :p_email, :v_reg_nuevo); END;");
    $db->InParameter($stmt, $s_usr_id, 'p_user');
    $db->InParameter($stmt, $nombre, 'p_nombre');
    $db->InParameter($stmt, $paterno, 'p_paterno');
    $db->InParameter($stmt, $materno, 'p_materno');
    $db->InParameter($stmt, $nombre_completo, 'p_nombre_completo');
    $db->InParameter($stmt, $telefono, 'p_telefono');
    $db->InParameter($stmt, $tdc, 'p_tdc');
    $db->InParameter($stmt, $tipo_tdc, 'p_tipo_tdc');
    $db->InParameter($stmt, $celular, 'p_celular');
    $db->InParameter($stmt, $email, 'p_email');
    $db->OutParameter($stmt, $v_reg_nuevo, 'v_reg_nuevo');
    $db->Execute($stmt);

    return $v_reg_nuevo;
}

# CALIFICA EL NUMERO DE REGISTRO QUE SE INGRESO A LA TABLA AUXILIAR DE TD_REGISTROS DE UNA NUEVA LLAMADA

function set_califica_llamada($user, $id_registro, $calificacion, $db) {
    $stmt = $db->PrepareSP("BEGIN SPU_CALIFICALLAMADA(:p_user, :p_id_registro, :p_calificacion, :p_cal_llamada); END;");
    $db->InParameter($stmt, $user, 'p_user');
    $db->InParameter($stmt, $id_registro, 'p_id_registro');
    $db->InParameter($stmt, $calificacion, 'p_calificacion');
    $db->OutParameter($stmt, $p_cal_llamada, 'p_cal_llamada');
    $db->Execute($stmt);
    return $p_cal_llamada;
}

# OBTIENE LA INFORMACI�N DEL NUEVO REGISTRO DADO DE ALTA EN TD_REGISTROS

function get_detalle_calif($id_registro, $db) {
    $rs = $db->ExecuteCursor("BEGIN SPS_DETALLESCALIF_NR(" . $id_registro . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# INFORMACION DEL CLIENTE DE UNA NUEVA LLAMADA

function get_seguimiento_registro($id_registro, $s_usr_id, $db) {
    $rs = $db->ExecuteCursor("BEGIN SPX_SEGUIMIENTO(" . $id_registro . "," . $s_usr_id . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# Devuelve los ultimos valores con los cuales esta guardado el registro en TBL_DATOS.

function set_status_registro($id_solicitud, $db) {
    $rs = $db->ExecuteCursor("BEGIN SPS_STATUS_REGISTRO(" . $id_solicitud . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# DEVUELVE LOS REGISTROS AGENDADOS POR HORA

function get_agendados_dia($p_usr_id, $db) {
    $rs = $db->ExecuteCursor("BEGIN SPS_AGENDADOSDIA(" . $p_usr_id . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# DETALLE DE SOLICITUD INBOUND PARA INSCRIPCION

function get_detalle_solicitud_IN($s_usr_id, $db) {
    $rs = $db->ExecuteCursor("BEGIN SPS_SOLICITUDIN(" . $s_usr_id . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# OBTIENE LA LISTA DE CATALOGOS DE FORMA DINAMICA

function get_subcatalogo_in($v_id_campo, $calif, $etapa, $id_solicitud, $db) {
    $rs = $db->ExecuteCursor("BEGIN SPS_SUB_CATALOGO_IN('" . $v_id_campo . "'," . $calif . "," . $etapa . "," . $id_solicitud . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# Verifica si la Calificacion arroja una Subcalificacion o no en las solicitudes inbound

function get_subcalifiacion($calif_, $id_etapa, $id_solicitud, $id_campo, $db) {
    $stmt = $db->PrepareSP("BEGIN SPS_ENVIASUBCALIFICACION (:p_calif, :p_id_etapa, :p_id_solicitud, :p_id_campo, :p_sub_calif); END;");
    $db->InParameter($stmt, $calif_, 'p_calif');
    $db->InParameter($stmt, $id_etapa, 'p_id_etapa');
    $db->InParameter($stmt, $id_solicitud, 'p_id_solicitud');
    $db->InParameter($stmt, $id_campo, 'p_id_campo');
    $db->OutParameter($stmt, $p_sub_calif, 'p_sub_calif');
    $db->Execute($stmt);
    return $p_sub_calif;
}

# Trae informaci�n para poner una nueva pregunta que es la de Cuanto va a Pagar o Cuanto Pago.

function get_promesadepago($calif_, $id_etapa, $id_solicitud, $db) {
    $stmt = $db->PrepareSP("BEGIN SPS_PROMESAPAGO (:p_calif, :p_id_etapa, :p_id_solicitud, :p_promesa); END;");
    $db->InParameter($stmt, $calif_, 'p_calif');
    $db->InParameter($stmt, $id_etapa, 'p_id_etapa');
    $db->InParameter($stmt, $id_solicitud, 'p_id_solicitud');
    $db->OutParameter($stmt, $p_promesa, 'p_promesa');
    $db->Execute($stmt);
    return $p_promesa;
}

#AGREGA AL REGISTRO ENCONTRADO EN TD_REGISTROS LA SOLICITUD QUE SE ENCONTRO DEL CLIENTE.

function set_guardasolicitud_registros($id_registro, $id_solicitud, $db) {
    $stmt = $db->PrepareSP("BEGIN SPU_GUARDASOL_REGISTROS(:p_registro,:p_solicitud); END;");
    $db->InParameter($stmt, $id_registro, 'p_registro');
    $db->InParameter($stmt, $id_solicitud, 'p_solicitud');
    $db->Execute($stmt);
}

#RESERVA LA SOLICITUD PARA EL AGENTE QUE LO ENCONTRO

function set_reservasolicitud($id_solicitud, $usuario, $usr_super, $db) {
    $stmt = $db->PrepareSP("BEGIN SPU_RESERVA_SOLICITUD(:p_solicitud, :p_usuario, :p_usr_super, :p_u_registro); END;");
    $db->InParameter($stmt, $id_solicitud, 'p_solicitud');
    $db->InParameter($stmt, $usuario, 'p_usuario');
    $db->InParameter($stmt, $usr_super, 'p_usr_super');
    $db->OutParameter($stmt, $p_u_registro, 'p_u_registro');
    $db->Execute($stmt);
    return $p_u_registro;
}

#GUARDA EN TBL_DATOS , EN TBL_TELEFONOS Y EN TD_REGISTRO Y OBTENEMOS LA SOLICITUD NUEVA.

function get_obtiene_guarda_sol($id_registro, $usr_super, $db) {
    $stmt = $db->PrepareSP("BEGIN SPX_OBTIENE_GUARDA_SOL(:p_id_registro, :p_usr_super, :p_id_solicitud); END;");
    $db->InParameter($stmt, $id_registro, 'p_id_registro');
    $db->InParameter($stmt, $usr_super, 'p_usr_super');
    $db->OutParameter($stmt, $p_id_solicitud, 'p_id_solicitud');
    $db->Execute($stmt);
    return $p_id_solicitud;
}

# DETALLE DE SOLICITUDES NUEVAS PARA HACER LA VENTA DE INTERESADO

function get_detalle_solicitud_nueva($s_usr_id, $db) {
    $rs = $db->ExecuteCursor("BEGIN SPS_SOLICITUDNUEVA(" . $s_usr_id . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# DETALLE DE REGISTRO DE BUSQUEDA

function get_detalle_registro($id_registro, $db) {
    $rs = $db->ExecuteCursor("BEGIN SPS_DETALLEREGISTRO(" . $id_registro . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# SI SE REGRESAN EN LA BUSQUEDA AL IREGISTRO DE TD_REGISTROS SOLO ACTUALIZA LOS DATOS Y NO INSERTA OTRO

function set_actualiza_registro($id_registro, $s_usr_id, $nombre, $paterno, $materno, $nombre_completo, $telefono, $tdc, $tipo_tdc, $celular, $email, $db) {
    $stmt = $db->PrepareSP("BEGIN SPU_ACTUALREGISTROLLAMADA(:p_id_registro,:p_user,:p_nombre,:p_paterno,:p_materno,:p_nombre_completo, :p_telefono , :p_tdc ,:p_tipo_tdc, :p_celular, :p_email, :v_reg_actual); END;");
    $db->InParameter($stmt, $id_registro, 'p_id_registro');
    $db->InParameter($stmt, $s_usr_id, 'p_user');
    $db->InParameter($stmt, $nombre, 'p_nombre');
    $db->InParameter($stmt, $paterno, 'p_paterno');
    $db->InParameter($stmt, $materno, 'p_materno');
    $db->InParameter($stmt, $nombre_completo, 'p_nombre_completo');
    $db->InParameter($stmt, $telefono, 'p_telefono');
    $db->InParameter($stmt, $tdc, 'p_tdc');
    $db->InParameter($stmt, $tipo_tdc, 'p_tipo_tdc');
    $db->InParameter($stmt, $celular, 'p_celular');
    $db->InParameter($stmt, $email, 'p_email');
    $db->OutParameter($stmt, $v_reg_actual, 'v_reg_actual');
    $db->Execute($stmt);
    return $v_reg_actual;
}

#CALIFICA EL REGISTRO CUANDO EL AGENTE ABANDONA LA SOLICITUD SIN PROCESAR.

function set_cal_reg_nvo($id_registro, $cont, $maquina, $usr_super, $db) {
    $stmt = $db->PrepareSP("BEGIN SPU_CAL_REG_NVO_SOL(:p_id_registro,:p_cont,:p_maquina,:p_super); END;");
    $db->InParameter($stmt, $id_registro, 'p_id_registro');
    $db->InParameter($stmt, $cont, 'p_cont');
    $db->InParameter($stmt, $maquina, 'p_maquina');
    $db->InParameter($stmt, $usr_super, 'p_super');
    $db->Execute($stmt);
}

# REALIZA LA BUSQUEDA DE LOS CODIGOS POSATALES

function get_datos_cp($p_cp, $db) {
    $rs = $db->ExecuteCursor("BEGIN SPS_CODIGOSPOSTALES('" . $p_cp . "',:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

## OBTIENE LAS CALIFICACIONES DISPONIBLES PARA EL REGISTRO

function get_calificacion($tipo, $id_solicitud, $id_etapa, $db) {
    $rs = $db->ExecuteCursor("BEGIN SPS_CALIFICACION('" . $tipo . "'," . $id_solicitud . "," . $id_etapa . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

## OBTIENE LAS SUBCALIFICACIONES PARA LA CACLIFICACION SELECCIONADA

function get_subcalificacion_m($tipo, $calif, $etapa, $id_solicitud, $db) {
    $rs = $db->ExecuteCursor("BEGIN SPS_SUBCALIFICACION('" . $tipo . "'," . $calif . "," . $etapa . "," . $id_solicitud . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

## VALIDA QUE LA SOLICITUD SEA CAPTURA COMPLETAMENTE

function get_valida_solicitud_capturada($id_solicitud, $db) {
    $rs = $db->ExecuteCursor("BEGIN TDCAMEXONLINE.XSP_GETDATOSCLIENTEINICIO(" . $id_solicitud . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

## DATOS DE INICIO PARA SUPP

function get_datoscliente_sup($id_solicitud, $db) {
    $rs = $db->ExecuteCursor("BEGIN XSP_GETDATOSCLIENTEINICIO_SUPP(" . $id_solicitud . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# MUESTRA LOS DATOS TELEFONO EN LA SOLICITUD

function get_sps_telefonos_sol($id_solicitud, $db) {
    $rs = $db->ExecuteCursor("BEGIN SPS_TELEFONOS_SOL(" . $id_solicitud . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

## CAMBIA EL ESTADO DE LA SOLICTUD PARA QUE SE PUEDA ABRIR EN VALIDACION

function set_validando_estado($id_solicitud, $db) {
    $stmt = $db->PrepareSP("BEGIN SPU_SOLICITUD_VALIDANDO(:p_id_registro); END;");
    $db->InParameter($stmt, $id_solicitud, 'p_id_registro');
    $db->Execute($stmt);
}

function get_validacionrfc($id_solicitud, $db) {
    $query = "BEGIN CSP_VERIFICACIONRFC(:customerid, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $id_solicitud, 'customerid');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    return $rs;
}

function get_validarcps($id_solicitud, $db) {
    $query = "BEGIN SPS_VALIDARCPs(:customerid, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $id_solicitud, 'customerid');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    return $rs;
}

function get_detalle_cp($cp, $colonia, $estado, $municipio, $ciudad, $db) {
    $query = "BEGIN CSP_GETLISTACP2(:cp, :colonia, :estado, :municipio, :ciudad, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $cp, 'cp');
    $db->InParameter($stmt, $colonia, 'colonia');
    $db->InParameter($stmt, $estado, 'estado');
    $db->InParameter($stmt, $municipio, 'municipio');
    $db->InParameter($stmt, $ciudad, 'ciudad');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    return $rs;
}

function get_procesos_detenidos($user, $db) {
    $query = "BEGIN SPS_PROCESOSDETENIDOS(:user, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $user, 'user');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    return $rs;
}

function get_registro_campaña($solicitud, $db) {
    $query = "BEGIN SPS_REG_CAMP(:solicitud, :registro); END;";
    $stmt = $db->PrepareSP($query);
    $registro = -1;
    $db->InParameter($stmt, $solicitud, 'solicitud');
    $db->OutParameter($stmt, $registro, 'registro');
    $db->Execute($stmt);

    return $registro;
}

function set_actualizarnombre($solicitud, $nombre, $apaterno, $amaterno, $db) {
    $query = "BEGIN spU_NombrePersonas(:solicitud, :nombre,:apaterno,:amaterno); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $solicitud, 'solicitud');
    $db->InParameter($stmt, $nombre, 'nombre');
    $db->InParameter($stmt, $apaterno, 'apaterno');
    $db->InParameter($stmt, $amaterno, 'amaterno');
    $db->Execute($stmt);
}

function get_mensaje_registro($u_registro, $db) {
    $query = "BEGIN TDCAMEXONLINE.SPS_MENSAJE_REGISTRO(:u_registro, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $u_registro, 'u_registro');
//    $rs = $db->ExecuteCursor("BEGIN SPS_MENSAJE_REGISTRO(" . $u_registro . ", :rc); END;", 'rc');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# Genera el listado completo de la agenda del usuario

function get_agenda_usuario_dia($s_usr_id, $fecha, $db) {
    $query = "BEGIN TDCAMEXONLINE.spS_AgendaUsuarioDia(:v_user, :v_date, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $s_usr_id, 'v_user');
    $db->InParameter($stmt, $fecha, 'v_date');
    $rs = $db->ExecuteCursor($stmt, 'rc');

    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

/**
 * Obtener el u_telefono a partir de la solicitud y el telefono
 * @param int $solicitud
 * @param string $telefono
 * @param connection $db
 * @return int
 */
function get_id_telefono($solicitud, $telefono, $db) {
    $query = "SELECT TDCAMEXONLINE.get_IdTelefono(:solicitud, :telefono) AS U_TELEFONO FROM DUAL";
    $rs = $db->Execute($query, array('solicitud' => $solicitud, 'telefono' => $telefono));
    return $rs->fields['U_TELEFONO'];
}

/**
 * Obtener recordset de llamadas al 01800
 * @param int $usr_id
 * @param connection $db
 * @return recordset
 */
function get_800($usr_id, $db) {
    $query = "BEGIN SPS_LLAMADA800(:usr_id, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $usr_id, 'usr_id');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    return $rs;
}

function set_verifica_tel($numero,$db){
    $query = "BEGIN TDCAMEXONLINE.sps_verifcar_numero(:numero,:resultado); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $numero, 'numero');
    $db->OutParameter($stmt, $resultado, 'resultado');
    /*$rs = */$db->Execute/*Cursor*/($stmt/*, 'rc'*/);
    return $resultado;
}

/*
 * Se genara el codigo de IVR y se guarda en base
 */
function get_obtiene_ivr_sec($solicitud,$id_producto,$db){
    $query = "BEGIN TDCAMEXONLINE.sps_registrar_ivr(:solicitud, :producto, :resultado); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $solicitud, 'solicitud');
    $db->InParameter($stmt, $id_producto, 'producto');
    $db->OutParameter($stmt, $resultado, 'resultado');
    /*$rs = */$db->Execute/*Cursor*/($stmt/*, 'rc'*/);
    return $resultado;
}

/*
 * Obtiene el Id del Proveedor a usar para envio de SMS
 */
function get_proveedor_sms($db){
    $query = "BEGIN TDCAMEXONLINE.xps_getproveedorsms(:resultado); END;";
    $stmt = $db->PrepareSP($query);
    $db->OutParameter($stmt, $resultado, 'resultado');
    $db->Execute($stmt);
    return $resultado;
};
/*
 * Se actualiza la base con el codigo de IVR generado y su id de sms para rastreo
 */
function set_UID_sms_ivr($id_solicitud,$id_producto,$uid,$codigo_ivr_sms,$db){
    $query = "BEGIN TDCAMEXONLINE.sps_actualizar_ivr(:solicitud, :producto, :uid, :codigo_ivr_sms); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $id_solicitud, 'solicitud');
    $db->InParameter($stmt, $id_producto, 'producto');
    $db->InParameter($stmt, $uid, 'uid');
    $db->InParameter($stmt, $codigo_ivr_sms, 'codigo_ivr_sms');
    $db->Execute($stmt);
}

##

//xsp_count_tel_ingresado
function set_count_tel($numero,$db){
    $query = "BEGIN xsp_count_tel_ingresado(:u_persona,:resultado); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $numero, 'u_persona');
    $db->OutParameter($stmt, $resultado, 'resultado');
    /*$rs = */$db->Execute/*Cursor*/($stmt/*, 'rc'*/);
    return $resultado;
}


#####  OBTIENE SI HAY REGISTROS REFERIDOS

function get_count_referidos($s_usr_id, $camp, $db) {
    $stmt = $db->PrepareSP("BEGIN XSP_GETCOUNTREFERIDOS(:user, :camp, :res); END;");
    $db->InParameter($stmt, $s_usr_id, 'user');
    $db->InParameter($stmt, $camp, 'camp');
    $db->OutParameter($stmt, $res, 'res');
    $db->Execute($stmt);
    return $res;
}

function set_insert_nombre_grabacion($solicitud,$nomina,$telefono,$empresa, $db) {

    $query = "BEGIN xsp_insert_nombregrabacion(:nomina,:telefono,:solicitud,:empresa,:v_result); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $nomina, 'nomina');
    $db->InParameter($stmt, $telefono, 'telefono');
    $db->InParameter($stmt, $solicitud, 'solicitud');
    $db->InParameter($stmt, $empresa, 'empresa');
    $db->OutParameter($stmt, $result, 'v_result');
    $db->Execute($stmt);
    echo $result;
}

function get_datos_referido($customerid, $db) {
    $query = "BEGIN xsp_datos_referido(:v_customerid,:v_nombre); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $customerid, 'v_customerid');
    $db->InParameter($stmt, $nombre, 'v_nombre');
    //$rs = $db->ExecuteCursor($stmt, 'rc');
    $db->Execute($stmt);
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $nombre;
}

function get_forma_pago($producto,$value, $db) {
    $query = "BEGIN TDCAMEXONLINE.xsp_get_forma_pago(:producto,:valor,:rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $producto, 'producto');
    $db->InParameter($stmt, $value, 'valor');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);

    return $rs;
}

function get_prima_values($plan,$formapago, $producto,$db) {
    $query = "BEGIN TDCAMEXONLINE.xsp_get_prima_values_x(:plan,:formapago,:producto,:rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $plan, 'plan');
    $db->InParameter($stmt, $formapago, 'formapago');
    $db->InParameter($stmt, $producto, 'producto');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);

    return $rs;
}
function get_prima_values_rh($plan,$aseg,$formapago, $producto,$db) {
    $query = "BEGIN TDCAMEXONLINE.xsp_get_prima_values_rh(:plan,:aseg,:formapago,:producto,:rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $plan, 'plan');
    $db->InParameter($stmt, $aseg, 'aseg');
    $db->InParameter($stmt, $formapago, 'formapago');
    $db->InParameter($stmt, $producto, 'producto');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);

    return $rs;
}

function get_prima_values_7($plan,$formapago,$solicitud,$edad,$db) {
    //$query = "BEGIN xsp_get_prima_values_7(:plan,:formapago,:solicitud,:rc); END;";
    $query = "BEGIN TDCAMEXONLINE.xsp_get_prima_values_7_jl(:plan,:formapago,:solicitud,:edad,:rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $plan, 'plan');
    $db->InParameter($stmt, $formapago, 'formapago');
    $db->InParameter($stmt, $solicitud, 'solicitud');
    $db->InParameter($stmt, $edad, 'edad');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);

    return $rs;
}
function get_prima_values_A($plan,$sexo,$formapago,$solicitud,$edad,$db) {
    //$query = "BEGIN xsp_get_prima_values_7(:plan,:formapago,:solicitud,:rc); END;";
    $query = "BEGIN TDCAMEXONLINE.xsp_get_prima_values_A(:plan,:sexo,:formapago,:solicitud,:edad,:rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $plan, 'plan');
    $db->InParameter($stmt, $sexo, 'sexo');
    $db->InParameter($stmt, $formapago, 'formapago');
    $db->InParameter($stmt, $solicitud, 'solicitud');
    $db->InParameter($stmt, $edad, 'edad');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);

    return $rs;
}


function get_prima($producto,$value, $db) {
    $query = "BEGIN TDCAMEXONLINE.xsp_get_prima_segura(:producto,:valor,:rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $producto, 'producto');
    $db->InParameter($stmt, $value, 'valor');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);

    return $rs;
}
//
function get_DATOS_COPY($solicitud,$producto, $db) {
    $query = "BEGIN TDCAMEXONLINE.XSP_GET_DATOS_COPY(:solicitud,:producto,:rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $solicitud, 'solicitud');
    $db->InParameter($stmt, $producto, 'producto');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);

    return $rs;
}

/*function set_autorizacion($nomina,$act, $db) {
    $query = "BEGIN xsp_autorizacion_LOGOUT(:nomina, :act,:resultado); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $nomina, 'nomina');
    $db->InParameter($stmt, $act, 'act');
    $db->InParameter($stmt, $resultado, 'resultado');
    $db->Execute($stmt);
    $db->SetFetchMode(ADODB_FETCH_BOTH);

    return $resultado;
}*/


function set_result_cajero($persona,$respuesta,$act,$db){
    $query = "BEGIN xspu_result_cajero(:v_persona,:v_respuesta,:v_act); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $persona, 'v_persona');
    $db->InParameter($stmt, $respuesta, 'v_respuesta');
    $db->InParameter($stmt, $act, 'v_act');
    $db->Execute($stmt);

    return $resultado;
}

/* obtiene el plan y costo seleccionado */
function ObtenerPlan($comb, $db) {
    $query = "BEGIN TDCAMEXONLINE.GET_PLAN(:comb, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $comb, 'comb');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;


    /*$stmt = $db->PrepareSP("BEGIN GET_PLAN(:comb, :res); END;");
    $db->InParameter($stmt, $comb, 'comb');
    $db->OutParameter($stmt, $res, 'res');
    $db->Execute($stmt);
    return $res;*/
}

function set_recuperada($solicitud, $surveyid, $db){
    $query = "BEGIN TDCAMEXONLINE.xsp_recupera_cancelada(:solicitud, :surveyid, :resultado); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $solicitud, 'solicitud');
    $db->InParameter($stmt, $surveyid, 'surveyid');
    $db->OutParameter($stmt, $resultado, 'resultado');
    $db->Execute($stmt);
    return $resultado;
}

function verifcar_numero ($v_numero, $db)
{
    // $v_numero = $v_numero/5;
    // echo $v_numero;
    try {
        $query = "BEGIN TDCAMEXONLINE.sps_verifcar_numero(:v_numero,:resultado); END;";
        $stmt = $db->PrepareSP($query);
        $db->InParameter($stmt, $v_numero, 'v_numero');
        $db->OutParameter($stmt, $resultado, 'resultado');
        $db->Execute($stmt);
        return $resultado;
    } catch (Exception $e) {
        pa($e->getTraceAsString());
        die();
        exit();
    }
}

function get_consulta_ol($u_user, $db) {
    $db->SetFetchMode(ADODB_FETCH_BOTH);

    $stmt = $db->PrepareSP("BEGIN tdcamexonline.Xsp_Oferta_Abo(:u_user, :oferta); END;");
    $db->InParameter($stmt, $u_user, 'u_user');
    $db->OutParameter($stmt, $oferta, 'oferta');
    $db->Execute($stmt);

    return $oferta;
}

function get_consulta_zona($u_persona, $db) {
    $db->SetFetchMode(ADODB_FETCH_BOTH);

    $stmt = $db->PrepareSP("BEGIN tdcamexonline.xsp_consulta_zona(:u_persona, :zona); END;");
    $db->InParameter($stmt, $u_persona, 'u_persona');
    $db->OutParameter($stmt, $u_zona, 'zona');
    $db->Execute($stmt);

    return $u_zona;
}
// requerimiento 11400:
function get_registro_val($u_persona, $db) {
    $db->SetFetchMode(ADODB_FETCH_BOTH);

    $stmt = $db->PrepareSP("BEGIN tdcamexonline.xps_registroval(:u_persona,:v_registroval); END;");
    $db->InParameter($stmt, $u_persona, 'u_persona');
    $db->OutParameter($stmt, $v_registroval, 'v_registroval');
    $db->Execute($stmt);

    return $v_registroval;
}

function es_grabada($id_solicitud, $db) {
    $query = "BEGIN tdcamexonline.SPS_GRABADA(:customerid, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $id_solicitud, 'customerid');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    return $rs;
}
function get_datos_prescrining($solicitud,$db){

    $query = "BEGIN tdcamexonline.sps_prescreening(:CUSTOMERID,:rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $solicitud, 'CUSTOMERID');
    $rs = $db->ExecuteCursor($stmt,'rc');

    return $rs;
}

function set_prescrining($solicitud,$nombre,$apaterno,$amaterno,$rfc,$u_user,$cp,$direccion,$ciudad,$db){

    $query = "BEGIN tdcamexonline.XSP_PRESCREENING2(:solicitud,:nombre,:apaterno,:amaterno,:rfc,:u_user,:cp,:direccion,:ciudad,:resultado); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $solicitud, 'solicitud');
    $db->InParameter($stmt, $nombre, 'nombre');
    $db->InParameter($stmt, $apaterno, 'apaterno');
    $db->InParameter($stmt, $amaterno, 'amaterno');
    $db->InParameter($stmt, $rfc, 'rfc');
    $db->InParameter($stmt, $u_user, 'u_user');
    $db->InParameter($stmt, $cp, 'cp');
    $db->InParameter($stmt, $direccion, 'direccion');
    $db->InParameter($stmt, $ciudad, 'ciudad');
    $db->OutParameter($stmt, $resultado, 'resultado');
    $db->Execute($stmt);

    return $resultado;
}

function get_listElegible_face($calificacion,$db){

    $query = "BEGIN tdcamexonline.xsp_listElegible_face(:v_u_estats,:rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $calificacion, 'v_u_estats');
    $rs = $db->ExecuteCursor($stmt,'rc');

    return $rs;
}

function get_conteo_agendas($id_usr, $db) {

    $query = "BEGIN TDCAMEXONLINE.XSP_GETCONTEOAGENDAS(:id_usr, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $id_usr, 'id_usr');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    
    if(isset($rs->fields[0])){
        return $rs->fields[0];
    }
}



##### TRAE LOS DATOS DE ONBOARDING

function get_datos_ob($id_solicitud,$db) {
    $stmt = $db->PrepareSP("BEGIN TDCAMEXONLINE.SPS_DATOS_OB(:u_persona, :rc); END;");
    $db->InParameter($stmt, $id_solicitud, 'u_persona');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}


function set_prescrining_($solicitud, $nombre, $apaterno, $amaterno, $rfc, $u_user, $cp, $direccion, $ciudad, $db) {
    try {
        $query = "BEGIN tdcamexonline.XSP_PRESCREENING2_(:solicitud, :nombre, :apaterno, :amaterno, :rfc, :u_user, :cp, :direccion, :ciudad, :resultado); END;";
        $stmt = $db->PrepareSP($query);
        
        $db->InParameter($stmt, $solicitud, 'solicitud');
        $db->InParameter($stmt, $nombre, 'nombre');
        $db->InParameter($stmt, $apaterno, 'apaterno');
        $db->InParameter($stmt, $amaterno, 'amaterno');
        $db->InParameter($stmt, $rfc, 'rfc');
        $db->InParameter($stmt, $u_user, 'u_user');
        $db->InParameter($stmt, $cp, 'cp');
        $db->InParameter($stmt, $direccion, 'direccion');
        $db->InParameter($stmt, $ciudad, 'ciudad');
        
        $db->OutParameter($stmt, $resultado, 'resultado');
        
        $db->Execute($stmt);

        if ($resultado !== false) {
            return $resultado;
        } else {
            echo "No se recibieron resultados.";
            return 0;
        }
    } catch (Exception $e) {
        error_log("Error: " . $e->getMessage());
        throw $e;
    }
}



function get_actualizaciones($flag, $nomina, $db){
    try {
    $query = "BEGIN TDCAMEXONLINE.SPS_GET_ACTUALIZACIONES(:v_flag, :v_usuario, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $flag, 'v_flag');
    $db->InParameter($stmt, $nomina, 'v_usuario');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    

    } catch (Exception $e) {
        return $e->get_message();
    }

    $len = 0;

    if($rs){
    $len = count($rs->_array);

    $data = array();
    for($i=0; $i<$len; $i++){
        $data[] = array(
            '0' => $rs->_array[$i]['ID_ACTUALIZACION'],
            '1' => nl2br($rs->_array[$i]['ACTUALIZACION']),
            '2' => $rs->_array[$i]['CREADO'],
            '3' => $rs->_array[$i]['SUPERVISOR'],
            '4' => $rs->_array[$i]['NOMINA'],
            '5' => $rs->_array[$i]['NOMBRE_AGENTE'],
            '6' => $rs->_array[$i]['LEIDO'],
            '7' => $rs->_array[$i]['FECHA_LEIDO'],
            '8' => $rs->_array[$i]['ESTATUS']
        );
    }
    return $data;
}else{
        $data = array();
        $data[] = array(
            '0' => ['ID_ACTUALIZACION'],
            '1' => ['ACTUALIZACION'],
            '2' => ['CREADO'],
            '3' => ['SUPERVISOR'],
            '4' => ['NOMINA'],
            '5' => ['NOMBRE_AGENTE'],
            '6' => ['LEIDO'],
            '7' => ['FECHA_LEIDO'],
            '8' => ['ESTATUS']
        );
    
    return $data;
}

}

function marcar_leido($id, $nomina, $db){
    $query = "BEGIN TDCAMEXONLINE.SPI_MARCAR_LEIDO(:v_id, :v_usuario, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $id, 'v_id');
    $db->InParameter($stmt, $nomina, 'v_usuario');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs->_array[0]['MENSAJE'];
}


function guardarDatosAutenticacion($customerid, $u_user, $folio, $score, $intentos, $v_leyenda1, $v_leyenda2, $v_leyenda3,$db) {
    try {
        $query = "BEGIN TDCAMEXONLINE.SPI_GUARDAR_AUT(:v_customerid, :v_u_user, :v_folio, :v_score, :v_intentos, :v_leyenda1, :v_leyenda2, :v_leyenda3, :rc); END;";

        $stmt = $db->PrepareSP($query);

        $db->InParameter($stmt, $customerid, 'v_customerid');
        $db->InParameter($stmt, $u_user, 'v_u_user');
        $db->InParameter($stmt, $folio, 'v_folio');
        $db->InParameter($stmt, $score, 'v_score');
        $db->InParameter($stmt, $intentos, 'v_intentos');
        $db->InParameter($stmt, $v_leyenda1, 'v_leyenda1');
        $db->InParameter($stmt, $v_leyenda2, 'v_leyenda2');
        $db->InParameter($stmt, $v_leyenda3, 'v_leyenda3');

        $rs = $db->ExecuteCursor($stmt, 'rc');
        $db->SetFetchMode(ADODB_FETCH_BOTH);
        
        if ($rs !== false) {
            $response = $rs->fields['RESPONSE'];
            return $response;
        } else {
            return "No se Inserto Corrcetamente los Datos";
        }        
} catch (Exception $e) {
    error_log("Error: " . $e->getMessage());
    throw $e;
}

}

function get_descripcion_tarjeta($tarjeta,$db){
    $query = "BEGIN TDCAMEXONLINE.SPS_DESCRIPCION_TARJETA(:v_tarjeta, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $tarjeta, 'v_tarjeta');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);

    return $rs;

}

##### GUARDA LOS DATOS DE LA SOLICITUD EN SURVEYPERSONAS MODO PROCESAR
function set_datos_solicitud_exitosa_validacion_local($id_solicitud , $id_producto, $id_agente, $db) {
    try{
        $stmt = $db->PrepareSP("BEGIN tdcamexonline.XSP_FINALIZAREGISTRO(:u_persona, :id_producto, :u_agente); END;");
        $db->InParameter($stmt, $id_solicitud, 'u_persona');
        $db->InParameter($stmt, $id_producto, 'id_producto');
        $db->InParameter($stmt, $id_agente, 'u_agente');
        $db->Execute($stmt);
    }catch(Exception $e){

    }
}



//MUESTRA PLANES SEGUN LAS POLIZAS
function get_tipo_seguro($POLISA,$db) {
    try{
        $stmt = $db->PrepareSP("BEGIN tdcamexonline.sps_tipo_seguros_cross(:POLISA,:rc); END;");    
        $db->InParameter($stmt, $POLISA, 'POLISA');    
        $rs = $db->ExecuteCursor($stmt, 'rc');
        return $rs;

    }catch(Exception $e){

    }
}


//RAZON DE CANCELACION PRODUCTO 100
 function get_razon_cancelacion($db) {
    try{
        $stmt = $db->PrepareSP("BEGIN tdcamexonline.XSP_GETRAZONESCANCELACION(:rc); END;");    
        $rs = $db->ExecuteCursor($stmt, 'rc');    
        return $rs;
    }catch(Exception $e){

    }
}

#GET RAZON DE CANCELACION ID
function get_razoncancelacionid($id_solicitud,$id_producto,$db) {
    $razon_cancelacion =null;
    try{
        $stmt = $db->PrepareSP("BEGIN tdcamexonline.Sps_razoncancelacion(:solicitud,:producto,:razoncancelacion); END;"); 
        $db->InParameter($stmt, $id_solicitud, 'solicitud');    
        $db->InParameter($stmt, $id_producto, 'producto');    
        $db->OutParameter($stmt, $razon_cancelacion, 'razoncancelacion');    
        $db->Execute($stmt);    
        $rc = ["razon_cancelacion" => $razon_cancelacion];
        return json_encode($rc);


    }catch(Exception $e){

    }
}

#CREAR RAZON CANCELACION
function set_razon_cancelacion ($id_solicitud,$id_producto,$usr_id,$valor,$nota,$db) {
    try{
        $stmt = $db->PrepareSP("BEGIN XSP_SETCANCELASOLICITUD(:varcustomerid, :varSurveyID,:v_valor,:v_user,:v_nota); END;");
        $db->InParameter($stmt, $id_solicitud, 'varcustomerid');
        $db->InParameter($stmt, $id_producto, 'varSurveyID');
        $db->InParameter($stmt, $valor, 'v_valor');
        $db->InParameter($stmt, $usr_id , 'v_user');
	    $db->InParameter($stmt, $nota , 'v_nota');
        $db->Execute($stmt);
        return 1;

    }catch(Exception $e){
        echo $e->getMessage();
        exit;
    }
}


//DUPLICIDAD EN PCN
function get_pcn_duplicado($pcn,$custumerid, $id_pruducto, $db) {
    try{
        $stmt = $db->PrepareSP("BEGIN tdcamexonline.XSP_buscar_pcn_duplicado(:v_pcn,:v_customerid,:v_result,:v_customerid2,:v_fecha); END;"); 
        $db->InParameter($stmt, $pcn, 'v_pcn');    
        $db->InParameter($stmt, $custumerid, 'v_customerid');            
        $db->OutParameter($stmt,$result , 'v_result');    
        $db->OutParameter($stmt,$customerid2 , 'v_customerid2');    
        $db->OutParameter($stmt,$v_fecha , 'v_fecha');    
        $db->Execute($stmt); 
        $resultado = ["1" => $result, "2" => $customerid2, "3" => $v_fecha];
        return json_encode($resultado);
    }catch(Exception $e){

    }
}


//AGREGAR CLAVEAUTENTICACION (PCN)
function set_XSP_SETAUTENTICO_local($id_solicitud,$claveautenticacion,$resultado,$db){
    try{
        $stmt = $db->PrepareSP("BEGIN tdcamexonline.XSP_SETAUTENTICO(:varUserID,:claveaut,:result); END;");
        $db->InParameter($stmt, $id_solicitud, 'varUserID');
        $db->InParameter($stmt, $claveautenticacion, 'claveaut');
        $db->InParameter($stmt, $resultado, 'result');    
        $db->Execute($stmt);
    }catch(Exception $e){
        
    }

}

//OBTENER INFORMACION DE VALIDACION - 100
function get_datos_inicio($id_solicitud,$id_producto,$db) {
    try{
        $stmt = $db->PrepareSP("BEGIN tdcamexonline.XSP_GETDATOSCLIENTEINICIO_VAL(:varUserID,:rc); END;");
        $db->InParameter($stmt, $id_solicitud, 'varUserID');    
    //$db->InParameter($stmt, $id_producto, 'v_producto');    
        $rs = $db->ExecuteCursor($stmt, 'rc');
        
        return $rs;
    }catch(Exception $e){

    }
}

//OBTENER EDAD PARA PRODUCTO 100
function get_datos_edad($id_solicitud,$id_producto,$db) {
    try{
        $stmt = $db->PrepareSP("BEGIN sps_edad(:varUserID,:v_edad); END;");
        $db->InParameter($stmt, $id_solicitud, 'varUserID');    
        $db->OutParameter($stmt, $edad, 'v_edad');    
        $db->Execute($stmt);
        
        return $edad;
    }catch(Exception $e){

    }
}

//GET_NAMES agente/supervisor
function get_datos_agentesuper($id_solicitud,$id_producto,$db) {
            try{
                $stmt = $db->PrepareSP("BEGIN tdcamexonline.CSP_GETSOLICITUDAGENTESUPER(:varUserID,:v_surveyid,:rc); END;");
                $db->InParameter($stmt, $id_solicitud, 'varUserID');
                $db->InParameter($stmt, $id_producto, 'v_surveyid');
                $rs = $db->ExecuteCursor($stmt,'rc');
                return $rs;
            }catch(Exception $e){
                echo $e->getMessage();
            }
    }


function get_sol_capturada_local($p_solicitud, $id_producto, $db) {
    try{
        $stmt = $db->PrepareSP("BEGIN tdcamexonline.SPS_SOL_CAPTURADA(:p_solicitud,:d_producto,:p_existe,:p_calregistro, :p_statusllamada); END;");
        $db->InParameter($stmt, $p_solicitud, 'p_solicitud');
        $db->InParameter($stmt, $id_producto, 'd_producto');
        $db->OutParameter($stmt, $p_existe, 'p_existe');
        $db->OutParameter($stmt, $p_calregistro, 'p_calregistro');
        $db->OutParameter($stmt, $p_statusllamada, 'p_statusllamada');
        $db->Execute($stmt);
        return $p_existe . '-' . $p_calregistro . '-' . $p_statusllamada;
    }catch(Exception $e){
        echo $e->getMessage();
    }
}


function get_cuestionario_validacion_local($producto, $lang, $exist, $name, $desc, $db) {
    try{
        $stmt = $db->PrepareSP("BEGIN tdcamexonline.proc_Survey_GetSurvey(:SurveyId_, :Lang, :Exist, :Name_, :Desc_); END;");
        $db->InParameter($stmt, $producto, 'SurveyId_');
        $db->InParameter($stmt, $lang, 'Lang');
        $db->OutParameter($stmt, $exist, 'Exist');
        $db->OutParameter($stmt, $name, 'Name_');
        $db->OutParameter($stmt, $desc, 'Desc_');
        $db->Execute($stmt);

        return $name . '-' . $desc;
    }catch(Exception $e){

    }
}



## DEVUELVE LAS PREGUNTAS DE LA SOLICITUD
function get_preguntas_validacion_local($producto, $solicitud, $lang, $exist, $db) {
    try{
        $stmt = $db->PrepareSP("BEGIN tdcamexonline.PROC_SURVEY_GETQUESTIONSVALIDA(:SurveyId_ ,:Lang, :Exist, :rc); END;");
        $db->InParameter($stmt, $producto, 'SurveyId_');
        $db->InParameter($stmt, $lang, 'Lang');
        $db->InParameter($stmt, $exist, 'Exist');
        $db->OutParameter($stmt, $rc, 'rc');
        $rs = $db->ExecuteCursor($stmt, 'rc');
        $db->SetFetchMode(ADODB_FETCH_BOTH);
        return $rs;
    }catch(Exception $e){

    }
}

function get_datos_query_1valor_val_local($query, $cp, $db) {
    try{
        $stmt = $db->PrepareSP("BEGIN tdcamexonline." . $query . "(:cp, :rc); END;");
        $db->InParameter($stmt, $cp, 'cp');
        $rs = $db->ExecuteCursor($stmt, 'rc');

        $db->SetFetchMode(ADODB_FETCH_BOTH);
        return $rs;
    }catch(Exception $e){

    }
}


##### DEVUELVE LAS REPUESTAS DE LAS PREGUNTAS
function get_respuestas_validacion_local($producto, $question, $lang, $solicitud, $mostrar, $exist, $db) {
    try{
        $stmt = $db->PrepareSP("BEGIN tdcamexonline.PROC_SURVEY_GETQUESTCHOICESCU2(:SurveyId_, :QuestionId_, :Lang, :persona, :mostrar, :Exist, :rc); END;");
        $db->InParameter($stmt, $producto, 'SurveyId_');
        $db->InParameter($stmt, $question, 'QuestionId_');
        $db->InParameter($stmt, $lang, 'Lang');
        $db->InParameter($stmt, $solicitud, 'persona');
        $db->InParameter($stmt, $mostrar, 'mostrar');
        $db->InParameter($stmt, $exist, 'Exist');
        $db->OutParameter($stmt, $rc, 'rc');
        $rs = $db->ExecuteCursor($stmt, 'rc');

        $db->SetFetchMode(ADODB_FETCH_BOTH);
        return $rs;
    }catch(Exception $e){

    }
}


##### DEVUELVE LAS REPUESTAS DE LAS PREGUNTAS
function get_datos_query_val_local($query, $db) {
    try{
        $stmt = $db->PrepareSP("BEGIN tdcamexonline." . $query . "(:rc); END;");
        $db->OutParameter($stmt, $rc, 'rc');
        $rs = $db->ExecuteCursor($stmt, 'rc');

        $db->SetFetchMode(ADODB_FETCH_BOTH);
        return $rs;
    }catch(Exception $e){

    }
}

//RESPUESTAS EN SURVEY RESPONSE
function buscar_respuestas($customerid, $surveyid, $db) {
    try {
        $ADODB_FETCH_MODE = ADODB_FETCH_ASSOC;
        $query = "BEGIN tdcamexonline.SPS_RESPUESTAS(:customerid, :surveyid, :rc); END;";
        $stmt = $db->PrepareSP($query);
        $db->InParameter($stmt, $customerid, 'customerid');
        $db->InParameter($stmt, $surveyid, 'surveyid');
        $rs = $db->ExecuteCursor($stmt, 'rc');
        $resultArray = $rs->GetArray();
        echo json_encode($resultArray);

    } catch (ADODB_Exception $e) {
    }
}

//VALIDA SI YA SE PROCESARON AMBOS PRODUCOS PARA PODER FINALIZAR VENTA
function get_procesada($id_solicitud,$db) {
    try{
        $stmt = $db->PrepareSP("BEGIN tdcamexonline.SPS_VALIDA_PROCESADA(:u_persona,:existe); END;"); 
        $db->InParameter($stmt, $id_solicitud, 'u_persona');       
        $db->OutParameter($stmt, $existe, 'existe');    
        $db->Execute($stmt);    
        $rc = ["procesada" => $existe] ?? ["procesada" => 2];
        return json_encode($rc);
    }catch(Exception $e){
        echo $e->getMessage();
    }
}