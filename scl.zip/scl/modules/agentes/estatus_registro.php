<?php
require_once('includes/includes.inc.php');
require_once('agentes.inc.php');

initialize("agente", "");

$nomina = get_session_varname("s_usr_nomina");
$empresa = get_session_varname("s_usr_centro");

        $dbuser = str_replace("APP", "", strtoupper($dbuser));
        //obtiene la OCC 
        $occ = number_format(get_occ_agente($nomina, $dbuser, $db),2);
        //obtiene el tiempo en llamada
        $en_llamada = get_time_llamada_agente($nomina, $dbuser, $db);


        echo '<style>
        p {
            font-size: 25px;
        }
        </style>';

        if ($empresa == 5){
            if($occ<70) {$color1 = "FF0000";} //hasta 69.999 --rojo
            else if($occ<75) {$color1 = "FFFF7F";} //desde 74.999 hasta 72.999  -- amarillo
            else {$color1 = "00FF00";}	//desde 75.0 en adelante -- verde                                    
        } else {
            if($occ<68) {$color1 = "FF0000";} //hasta 67.999
            else if($occ<73) {$color1 = "FFFF7F";} //desde 68.0 hasta 72.999
            else {$color1 = "00FF00";}	//desde 73.0 en adelante            
        }
        
        $occ = number_format($occ, 0);    

        echo '<table class="table table-bordered">
                <thead>
                    <tr>
                        <th style="text-align:center"><span>OCUPACION</span></th>
                        <th style="text-align:center">TIEMPO EN LLAMADA</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th style="text-align:center"><p style="color:#'.$color1.'">'.$occ.'%</p></th>
                        <td style="text-align:center"><p style="color:#'.$color1.'">'. $en_llamada.'</p></td>
                    </tr>
                </tbody>
            </table>';
        ?>