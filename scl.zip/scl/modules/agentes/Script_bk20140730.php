<html xmlns="http://www.w3.org/1999/xhtml">
    <head profile="http://dublincore.org/documents/dcmi-terms/">
        <meta http-equiv="Content-Type" content="application/xhtml+xml; charset=utf-8"/>
        <title>Script de Venta Volaris</title>
        <style type="text/css">
            body, tbody {
                font-family: Verdana, Tahoma, Arial, sans-serif;
                font-size: 12px
            }
            .title {
                background: Navy;
                color: White;
            }
        </style>
    </head>
    <body>
        <h1>Script de Venta Volaris</h1>
        <p>Muy buenos tardes Sr.(a) (Nombre y Apellido del cliente), le habla (Nombre y Apellido) de Grupo Financiero Invex.
            Gracias por atender mi llamada, el motivo por el cual me comunico con usted es para informarle que gracias a sus excelentes referencias banco Invex en alianza con Volaris 
            tiene para usted su nueva tarjeta de crédito Volaris.</p>
        <br />
        <p>Es una tarjeta nivel Platinum respaldada por Visa Internacional la cual  podrá utilizarla en más de 25 mil
            millones de establecimientos a nivel mundial además de disponer efectivo en cualquier cajero red.</p>
        <br />
        <p>Por ser usted cliente selecto Volaris le otorga un bono de bienvenida por $1,000 y adicional se le estará
            bonificando el 1.5% de todas las compras que realice en cualquier comercio para que usted comience a viajar
            gratis con la mejor aerolínea ya que tiene los aviones más nuevos y de bajo costo.</p>
        <h2>Interacción con el cliente (utilizar 1 opción)</h2>
        <ul>
            <li>&iquest;Ha volado con o ha escuchado de Volaris?</li>
            <li>&iquest;Le gusta viajar?</li>
        </ul>
        <p>Mejor aún, usted en cuanto le llegue la tarjeta tendrá beneficios exclusivos como (dar 3  beneficios):</p>
        <ul>
            <li>Prioridad en documentación y abordaje.</li>
            <li>10 Kg adicional de equipaje extras para usted y acompañantes.</li>
            <li>30% de descuento en el estacionamiento del aeropuerto en la Cd de México.</li>
            <li>3, 6 y 11 meses sin intereses en sus compras Volaris.</li>
            <li>Acceso al Salón VIP Grand Lounge.</li>
            <li>Promociones exclusivas que le haremos llegar a su correo electrónico.</li>
        </ul>
        <p>De manera exclusiva aprobamos su tarjeta en menos de 5 minutos y le estaría llegando a su domicilio con un 
            monto del crédito igual o mayor a la que viene manejando hasta un máximo de 100 mil pesos. La tarjeta que 
            usted maneja, &iquest;de qu&eacute; banco es?</p>
        <br />
        <p>&iquest;Tiene más de 1 año con ella?</p>
        <br />
        <p>&iquest;Su límite de crédito es mayor de $7 mil pesos?</p>
        <br />
        <p>Sabemos de antemano para saber que tarjetas queremos tener es necesario estar plenamente convencidos es
            por eso que le enviamos a su domicilio un kit de bienvenida con toda la información por escrito para que
            usted la lea y confirme todo lo que le estoy mencionando, el plástico desactivado para que lo active en
            el mejor momento, &iquest;su nombre como aparece en su IFE es...?</p>
        <br />
        <p>Aviso de Privacidad</p>
    </body>
</html>
