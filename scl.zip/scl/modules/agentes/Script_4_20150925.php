<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=utf-8">
	<TITLE></TITLE>
	<META NAME="GENERATOR" CONTENT="LibreOffice 3.5  (Linux)">
	<META NAME="AUTHOR" CONTENT="calidad.atento13">
	<META NAME="CREATED" CONTENT="20150813;23000000">
	<META NAME="CHANGEDBY" CONTENT="Mendez Ortiz Irais">
	<META NAME="CHANGED" CONTENT="20150813;23000000">
	<META NAME="AppVersion" CONTENT="12.0000">
	<META NAME="Company" CONTENT="atento">
	<META NAME="DocSecurity" CONTENT="0">
	<META NAME="HyperlinksChanged" CONTENT="false">
	<META NAME="LinksUpToDate" CONTENT="false">
	<META NAME="ScaleCrop" CONTENT="false">
	<META NAME="ShareDoc" CONTENT="false">
	<STYLE TYPE="text/css">
	<!--
		@page { size: 21cm 29.7cm; margin-left: 1.5cm; margin-right: 2cm; margin-top: 1.25cm; margin-bottom: 1cm }
		P { margin-bottom: 0.21cm; direction: ltr; color: #000000; widows: 2; orphans: 2 }
	-->
	</STYLE>
</HEAD>
<BODY LANG="es-ES" TEXT="#000000" DIR="LTR">
<P ALIGN=JUSTIFY STYLE="margin-bottom: 0.35cm"><FONT FACE="Arial, serif"><FONT SIZE=2><I><B>Script
Inicio</B></I></FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><I><B>
Muerte Accidental </B></I></FONT></FONT>
</P>
<P LANG="es-MX" ALIGN=JUSTIFY STYLE="margin-bottom: 0.35cm"><BR><BR>
</P>
<P ALIGN=JUSTIFY STYLE="margin-bottom: 0.35cm"><FONT FACE="Arial, serif"><FONT SIZE=2><I>Buenas
tardes Sr./Sra./Srita </I></FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><I><U><B>Nombre
Completo Cliente</B></U></I></FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><I><B>
</B></I></FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><I>Mi
nombre es: </I></FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><I><B>**</B></I></FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><I><U><B>Nombre
Agente</B></U></I></FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><I><B>**
</B></I></FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><I>me
comunico de Seguros Bancomer. <BR><BR>Es un placer
notificarle/comentarle Sr./Sra./Srita </I></FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><I><U><B>apellido
cliente</B></U></I></FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><I>
que el d&iacute;a de hoy gracias a que es </I></FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><I><B>un
cliente MUY importante Bancomer,</B></I></FONT></FONT><SPAN LANG="es-MX">puede
activar en este momento el  </SPAN><SPAN LANG="es-MX"><B>Respaldo
para Muerte Accidental</B></SPAN><SPAN LANG="es-MX"> con el cual sus
beneficiarios recibir&aacute;n una suma de $300 mil pesos esto en caso de
que llegase a fallecer a causa de un accidente amparado y con la
ventaja de que esta suma se incrementa autom&aacute;ticamente al 3er y 5to
a�o a partir de la contrataci&oacute;n, por tan solo $124 pesos mensuales.</SPAN>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 100%"><FONT FACE="Arial, serif"><FONT SIZE=2>Este
servicio se liga autom&aacute;ticamente a su cuenta (libreton/Cr&eacute;dito)
para su mayor comodidad y Usted puede aprovechar esta gran
oportunidad en este momento, &uacute;nicamente debe cumplir con el rango de
edad que va de los </FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><U><B>12
a 70 a�os</B></U></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 100%"><BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 100%"><FONT FACE="Arial, serif"><FONT SIZE=2>Para
validar esta posibilidad y pueda gozar de este apoyo econ&oacute;mico, </FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><B>cual
es su fecha de nacimiento?/cuando naci&oacute;?/que edad tiene actualmente?</B></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 100%"><BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 100%"><SPAN LANG="es-MX"><B>Solicitar
ocupaci&oacute;n. Si es ambigua mencionar las siguientes preguntas:</B></SPAN>
</P>
<P ALIGN=JUSTIFY STYLE="margin-bottom: 0.35cm"><BR><BR>
</P>
<P ALIGN=JUSTIFY STYLE="margin-bottom: 0.35cm"><FONT FACE="Arial, serif"><FONT SIZE=2><SPAN STYLE="background: #ffff00">Para
garantizar la transparencia de nuestros servicios,</SPAN></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Calibri, serif"><FONT SIZE=2><SPAN STYLE="background: #ffff00">.
Es importante mencionarle que existen algunas exclusiones, por
ejemplo el uso indebido o il&iacute;cito de una TDC o D&eacute;bito o delitos
ocasionados intencionalmente por el asegurado.</SPAN></FONT></FONT></FONT></P>
<P ALIGN=JUSTIFY STYLE="margin-bottom: 0.35cm"><SPAN STYLE="background: #ffff00">Tiene
incapacidad total y permanente o tiene invalidez total y permanente,
Practica profesionalmente el buceo, boxeo, lucha, toreo,
paracaidismo, charrer&iacute;a, ala delta, motociclismo o automovilismo, Es
chofer de transporte urbano o for&aacute;neo (carga o pasajeros) u opera
camiones de volteo, palas mec&aacute;nicas o buldozer. Es ayudante,
auxiliar o similar o se desempe�a como alba�il, electricista de
alto voltaje, perforador, bombero o piloto fumigador, Presta sus
servicios en cualquier organismo polic&iacute;aco, cuerpos militares o de
marina, de seguridad privada, guardaespaldas o utiliza armas para el
desempe�o de su trabajo? </SPAN>
</P>
<P ALIGN=JUSTIFY STYLE="margin-bottom: 0cm"><FONT COLOR="#222222"><FONT FACE="Arial, serif"><FONT SIZE=2><SPAN STYLE="background: #ffff00">Usted
practica actualmente alguna de las actividades antes mencionadas?</SPAN></FONT></FONT></FONT></P>
<P LANG="es-MX" ALIGN=JUSTIFY STYLE="margin-bottom: 0.35cm"><BR><BR>
</P>
<P ALIGN=JUSTIFY STYLE="margin-bottom: 0.35cm">&nbsp;
<SPAN LANG="es-MX"><B>Sr./Sra./Srta.&nbsp;</B></SPAN><SPAN LANG="es-MX"><B>________
</B></SPAN><SPAN LANG="es-MX"><B>Este servicio NO SE LE ESTA
OTORGANDO GRATUITAMENTE Y TAMPOCO ES UNA RIFA PREMIO O BENEFICIO. Lo
que usted est&aacute; adquiriendo (cantidad de p&oacute;lizas) p&oacute;liza(s)Con un
costo mensual de 124 pesos correspondiente a la contrataci&oacute;n del
plan </B></SPAN><SPAN LANG="es-MX"><B>Muerte Accidental</B></SPAN><SPAN LANG="es-MX"><B>
con cargo a su tarjeta con terminaci&oacute;n  </B></SPAN><SPAN LANG="es-MX"><B>XXXX&nbsp;</B></SPAN><SPAN LANG="es-MX"><B>
�De acuerdo</B></SPAN><B>?</B></P>
<P ALIGN=JUSTIFY STYLE="margin-bottom: 0.35cm"><SPAN LANG="es-MX"><B>Con
su respuesta est&aacute; aceptando la contrataci&oacute;n del servicio que cuenta
renovaci&oacute;n autom&aacute;tica y </B></SPAN><SPAN LANG="es-MX"><B> </B></SPAN><SPAN LANG="es-MX"><B>la
vigencia de la misma, iniciar&aacute; a partir de las 12 hrs. del d&iacute;a
h&aacute;bil siguiente de que se efect&uacute;e el cargo. Su paquete de
bienvenida llegar&aacute; aproximadamente de 10 a 17 d&iacute;as h&aacute;biles al
domicilio que tenemos registrado. Mientras tanto su n&uacute;mero de
tarjeta ser&aacute; su identificador provisional en caso de tener alguna
duda.&nbsp; A continuaci&oacute;n le proporciono nuestro tel&eacute;fono de
Atenci&oacute;n a clientes 11 02 00 00 y 01 800 849 6600,</B></SPAN><SPAN LANG="es-MX"><B>
</B></SPAN><SPAN LANG="es-MX"><B>  donde se podr&aacute; comunicar en caso
de tener alg&uacute;n comentario o realizar alg&uacute;n tr&aacute;mite</B></SPAN><SPAN LANG="es-MX"><B>
</B></SPAN><SPAN LANG="es-MX"><B> y el n&uacute;mero para reportar el
siniestro es 01 800 874 3683. (Indicar al cliente tome nota)</B></SPAN><B>
</B>
</P>
<P ALIGN=JUSTIFY STYLE="margin-bottom: 0.35cm"><SPAN LANG="es-MX"><B>Seguros
BBVA Bancomer, Montes Urales 424, Colonia Lomas&nbsp;de&nbsp;Chapultepec,
Delegaci&oacute;n Miguel Hidalgo, C&oacute;digo Postal 11000, D.F. recaba sus
datos para verificar su identidad. El&nbsp;aviso&nbsp;de
Privacidad&nbsp;Integral actualizado est&aacute;
en&nbsp;www.segurosbancomer.com.mx.</B></SPAN><B> </B>
</P>
<P ALIGN=JUSTIFY STYLE="margin-bottom: 0.35cm"><SPAN LANG="es-MX">Agradezco
su tiempo y atenci&oacute;n mi nombre es: _________ de Seguros Bancomer,
que tenga un excelente d&iacute;a.</SPAN> 
</P>
<P ALIGN=JUSTIFY STYLE="margin-bottom: 0.35cm"><BR><BR>
</P>
</BODY>
</HTML>