<?php

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("agente", "Error");
$error = $_REQUEST["e"];

if ($error != 8) {
    layout_menu($db, "");
}

$isPredictivo = 0;
$sol = isset($_REQUEST["customerid"]) ? $_REQUEST["customerid"] : '';
$registro = isset($_REQUEST["u_registro"]) ? $_REQUEST["u_registro"] : '';
$hora = isset($_REQUEST["hora"]) ? $_REQUEST["hora"] : '';
$fecha = isset($_REQUEST["fecha"]) ? $_REQUEST["fecha"] : '';
$coment = isset($_REQUEST["com"]) ? $_REQUEST["com"] : '';

$usr_id = get_session_varname("s_usr_id");

if (isset($_REQUEST['activo_tz']))
    $activo_tz = $_REQUEST['activo_tz'];
if (isset($_REQUEST['u_zona']))
    $u_zona = $_REQUEST['u_zona'];
if (isset($_REQUEST['estatus']))
    $estatus = $_REQUEST['estatus'];
if (isset($_REQUEST['agendas']))
    $agendas = $_REQUEST['agendas'];
if (isset($_REQUEST['texto']))
    $texto = $_REQUEST['texto'];

    $bnd = isset($_REQUEST['bnd']) ? $_REQUEST['bnd']: '';

if ($error == 1) {
    
    if ($bnd == 1) {
        $msg_error = 'No estas asignado a una zona';
    } else if ($bnd == 2) {
        $msg_error = 'Se excedido el numero de registros permitidos por hora';
    } else if ($bnd == 3) {
        $msg_error = 'No hay mas registros Libres y Abandonados';
    } elseif ($bnd == 4) {
        if ($activo_tz != 1) {
            $msg_error .= 'La solicitud ' . $sol . ' ha sido bloqueada por Inteligencia de Mercado <br>Descripci&oacute;n: ' . $texto;
        }elseif ($estatus == 0) {
            $msg_error .= 'La zona ' . $u_zona . ' esta inactiva de la solicitud ' . $sol . '. <br>';
        }elseif ($agendas == 0) {
            $msg_error .= 'No se pueden tomar agendados de la zona ' . $u_zona . ' de la solicitud ' . $sol . '. M�s informacion en Inteligencia de Mercado <br>';
        }
    }
} else if ($error == 2) {
    $msg_error = 'El registro no se pudo liberar correctamente, intente de nuevo!!!';
} else if ($error == 3) {
    $msg_error = 'No tienes permitido realizar busqueda de registros!!!';
} else if ($error == 4) {
    $msg_error = 'Se encontr� un error al obtener un registro especifico!!!';
} else if ($error == 61) {
    $msg_error = 'Se encontr� un error al obtener un registro de predictivo (29)!!!';
} else if ($error == 62) {
    $msg_error = 'Se encontr� un error al obtener un registro de predictivo (28)!!!';
} else if ($error == 7) {
    $msg_error = 'Tienes un registro agendado!!! Por favor t�malo o reag�ndalo...<br>Solicitud: ' . $sol . '<br>Hora: ' . $hora . '<br>Fecha: ' . $fecha . '<br>Comentario: ' . $coment;
} else if ($error == 8) {
    $header = "modules.php?mod=agentes&op=standby&e=10";
    header("location: ". $header);
} else if ($error == 9) {
    $msg_error = 'Error de Conexi�n a Predictivo';
} else if ($error == 10) {
    $msg_error = $_REQUEST['mensaje_error'];
} else if ($error == 11) {
    $msg_error = $_REQUEST['mensaje_error'];
} else if ($error == 12) {
    $msg_error = 'Tu linea esta ocupada, favor de COLGARLA!!!';
}
?>
<form method="post" action="modules.php?mod=agentes&op=process_data&act=1" name="frm1">


    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#">Agentes</a></li>
        <li class="breadcrumb-item active" aria-current="page">Mensaje</li>
      </ol>
    </nav>


    <table border="0">
        <tr>
            <td>Mensaje: <?php echo $bnd ?>&nbsp;</td>
            <td class="textleft" colspan="2"><b class="mensaje"><?= $msg_error ?></b></td>
        </tr>
        <tr>
            <td colspan="3">&nbsp;</td>
        </tr>
        <tr>
            <td colspan="3">
                <input type="hidden" name="u_persona" id ="u_persona">
                <input type="hidden" name="u_registro" id ="u_registro">
                <input type="hidden" name="trabajado" id ="trabajado">

                <?php if ($error == 7) { ?>
                    <input type="button" value="Obtener Agenda" id="ObtAgenda" onclick="Mostrar_agendado2(0,<?= $registro ?>,<?= $sol ?>, '<?= encripta(3) ?>', 1)"/>&nbsp;&nbsp;
                <?php } elseif ($error == 10) { ?>
                    <a class="boton_error" id="agenda" href="<?= $linkpath ?>modules.php?mod=agentes&op=index">Regresar al Registro</a> &nbsp;
                    <a class="boton_error" id="agenda" href="<?= $linkpath ?>modules.php?mod=agentes&op=process_data&act=<?= encripta(8) ?>">Abandonar el Registro</a>
                <?php } ?>
            </td>
        </tr>
    </table>
</form>
<?
layout_footer();
?>