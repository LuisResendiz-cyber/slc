    <div class="speed-dial">
        <button class="speed-dial-button">+</button>
        <div class="speed-dial-options">
            <button class="speed-dial-option"><img src="includes/imgs/escritura.png" alt=""></button>
            <button class="speed-dial-option">A</button>
            <button class="speed-dial-option">S</button>
        </div>
    </div>

<style>
        .speed-dial {
            position: fixed;
            bottom: 20px;
            right: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .speed-dial-button, .speed-dial-option {
            background-color: #f50057;
            border: none;
            border-radius: 50%;
            color: white;
            width: 56px;
            height: 56px;
            font-size: 24px;
            cursor: pointer;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
            display: flex;
            justify-content: center;
            align-items: center;
            transition: transform 0.3s;
        }

        .speed-dial-options {
            position: absolute;
            bottom: 70px;
            display: flex;
            flex-direction: column;
            align-items: center;
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.3s, visibility 0.3s;
        }

        .speed-dial:hover .speed-dial-options {
            opacity: 1;
            visibility: visible;
        }

        .speed-dial:hover .speed-dial-option:nth-child(1) {
            transform: translateY(123px);
        }

        .speed-dial:hover .speed-dial-option:nth-child(2) {
            transform: translateY(0px);
        }

        .speed-dial:hover .speed-dial-option:nth-child(3) {
            transform: translateY(-120px);
        }

    </style>