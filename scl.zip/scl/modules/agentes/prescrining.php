<?php
# @uthor Mark
# Cuestionario File
//libxml_use_internal_errors(true);
require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

//initialize("agente,supervisor", "Solicitud");
//layout_menu($db, "");
$nomina = get_session_varname('s_usr_nomina');;
$u_user = get_session_varname("s_usr_id");
?>

<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <script>
            function loading_fun() {
                Html = '<div id="ajControl" width="100%">' +
                        '<table cellpadding="0" cellspacing="0" width="100%" height="100%" align="center">' +
                        '<tr id="ajControlBody">' +
                        '<td>Cargando...<br><br>Su peticion esta siendo procesada</td>' +
                        '</tr>' +
                        '</table>' +
                        '</div>';

                var div = document.createElement('div');
                div.id = 'div_padre';
                div.innerHTML = Html;

                document.body.appendChild(div);
            }

            function Actualizar(boton) {

                //boton.hidden = true;

                var xmlhttp;
                if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
                    xmlhttp = new XMLHttpRequest();
                } else {// code for IE6, IE5
                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                }
                
                document.getElementById(boton.id).setAttribute("class","menulink2");
                setTimeout(function(){ boton.disabled = false; document.getElementById(boton.id).setAttribute("class","menulink"); }, 15000);
                
                xmlhttp.onreadystatechange = function() {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                        document.getElementById("result").innerHTML = xmlhttp.responseText;
                        //boton.disabled = false;
                    }
                };

                xmlhttp.open("POST", "modules.php?mod=agentes&op=process_data&act=<?= encripta('48') ?>", true);
                xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                xmlhttp.send("nomina=<?= $nomina ?>&u_user=<?= $u_user ?>");
            }
            
            
            function f5(that, val) {
                //alert("entro");
                if (val)
                {
                    that.on('keydown', function(e) {
                        var code = (e.keyCode ? e.keyCode : e.which);
                        if (code == 116 /*|| code == 8*/) {
                            e.preventDefault();
                        }
                    });
                } else {
                    that.off('keydown');
                }
            }

            $(document).ready(function() {
                f5($(document), true);
            });

        </script>
        <style>
            table.indicadores tr td {
                border: 2px solid #7BA1B1;    
                border-collapse: separate;
                border-radius: 2%;
                font-size: 10px;
                text-align: center;
                transition:width 1s, height 1s, transform 1s;
            }

            table.indicadores th {
                border: 2px solid #7BA1B1;
                border-collapse: collapse;
                border-radius: 2%;
                font-size: 12px;    
                background-color: #CCCCFF;
            }

            table.indicadores caption {
                font-size: 12px;
                font-weight: bold;
                color: red;
            }

            table.indicadores tr:hover td {
                border: 2px solid black;
            }
            
            .menulink/*a:link,a:visited**/
            {
                display:block;
                font-weight:bold;
                color:#FFFFFF;
                background-color:#2A6AD7;
                width:120px;
                text-align:center;
                font-size: 12px;
                padding:4px;
                border-radius:25px;
                text-decoration:none;
                text-transform:capitalize;
            }
            .menulink2/*a:link,a:visited**/{
                display:block;
                font-weight:bold;
                color:#FFFFFF;
                background-color:#132D5A;
                width:120px;
                text-align:center;
                font-size: 12px;
                padding:4px;
                border-radius:25px;
                text-decoration:none;
                text-transform:capitalize;
                cursor: no-drop;
            }
        </style>
    </head>    
    <body style="background: #3F738D;">
        <div id="result">
            <table class="indicadores">
                <tr class="indicadores">
                    <th colspan="8" class="indicadores">Prescrining</th>
                </tr>
                <tr class="indicadores" style="background: #006666;">
                    <td>Solicitud</td>                    
                    <td>Estatus</td>  
                    <td>Folio Luci</td>
                </tr>
                <tr class="indicadores">
                    <td class="indicadores">&nbsp</td>
                    <td class="indicadores">&nbsp</td>
                    <td class="indicadores">&nbsp</td>                    
                </tr>
            </table>
        </div>
        <div align="center">
            <input type="button" value="Actualizar" class="menulink" id="b_actualizar" onclick="Actualizar(this);"/>
        </div>
        <?php //}  ?>
    </body>
</html>