<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <title></title>
    <meta name="generator" content="LibreOffice 4.2.8.2 (Linux)">
    <meta name="author" content="Christoper Gaytan Chavez">
    <meta name="created" content="20170123;185200000000000">
    <meta name="changed" content="20170923;104405909155963">
    <meta name="AppVersion" content="16.0000">
    <meta name="Company" content="Microsoft">
    <meta name="DocSecurity" content="0">
    <meta name="HyperlinksChanged" content="false">
    <meta name="LinksUpToDate" content="false">
    <meta name="ScaleCrop" content="false">
    <meta name="ShareDoc" content="false">
    <style type="text/css">
    <!--
        @page { margin: 1.27cm }
        p { margin-bottom: 0cm; direction: ltr; line-height: 100%; text-align: justify; widows: 2; orphans: 2 }
        p.western { font-family: "Times New Roman", serif; font-size: 10pt; so-language: es-ES }
        p.cjk { font-family: "Times New Roman"; font-size: 10pt; so-language: es-ES }
        p.ctl { font-family: "Times New Roman"; font-size: 10pt }
        a:link { color: #0000ff; so-language: zxx }
    -->
    </style>
</head>
<body lang="en-US" link="#0000ff" dir="ltr">
<div title="header">
    <center>
        <table width="709" cellpadding="5" cellspacing="0">
            <col width="225">
            <col width="226">
            <col width="225">
            <tr>
                <td width="225" height="6" valign="top" bgcolor="#ffffff" style="border-top: 1px solid #1f497d; border-bottom: none; border-left: 1px solid #1f497d; border-right: none; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0.13cm; padding-right: 0cm">
                    <p lang="es-MX" class="western" align="left"><font color="#1f3864">&nbsp;</font><img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wgARCAE6A4QDASIAAhEBAxEB/8QAGwABAAMBAQEBAAAAAAAAAAAAAAUGBwQDAQL/xAAZAQEAAwEBAAAAAAAAAAAAAAAAAgMEAQX/2gAMAwEAAhADEAAAAb+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4e/kZQ4nqY+10yNcoyXg+DrXuvN9Iw6ODPb9lOiqYQ85fX5/e2Dj2y3THLfVP8Rdho1kbNoWL6fVOaGW75V7Tl9tfzQcw12yP6zm8ZITH7hGurVpPPtB8/QFcwGfaDld9f7TkzbCl9tmiuJacxrR65TwotAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeXr5GNj1sV8ttTtnm6uLI9JzbTVM6hWLPnsjMp1bKdFbTMz0zvJ2DnKjkvolnrOm7KO3JNoyyqcVbqj36KtaHm6+fH9DzvZntOgV+wZ7ahRZvi2U+8Vo2c9576/jOlVTnxjvA+ZZqeWaarjY65Y6ZhCVB/L97aL6RuK6Rj8z6dNV566PE9a8zfR6LPvB3Y5KOyfmmViTSfGi+c46l65FqlU+kj6pd8fnfnpqv3dQIzrX1Bv2ex84s6lzQuag9t0NB6sgsUe31+f1nt4+jOfe+vQo3OvSUb5KZT6dat+KpT65aR9ofHbDXPuc6NntFYisMbnEporvEjl3mau4e7Nbx9Gefu+vQI7N+mXNM6IuUzWg6AAAA8vXyMbHrYr7Z6xbPN1ZHzabmOynTJrGdLzWdGU6tlN0GmZnpneSOT7JXKLaJpmUe+mrYqZYvuK7Jh6eXWJGn23zNefV79zO7Pon46Kzg0Z9aqnpm2iXx7Z8zpnBWese+qrYn4/fmawPmWanlmmqemaJ0zjcYeF4u8/Gm5/oMJSQy3cnWOPD3O47pue3rZRO43smNw7OXv8SFUwrnlNwrdg2UWjKb7nke2q5/P1nsfj9oy5elGd5QJ2p6/qp/YyX+GZ6lBW1xdyyTWus25+iwaK5qQMN/nkOxZHpqlL9HTdc3F2/iqWM7LjWya6Y/NLJ+i1SBkuUm7cU+ULSca2S2vOouUmrYzUmYrwdAAAAAeXr5GNj1sV9tlTtnm6maaXm041+XiPbbRqGU6tlNFjTMz0zvJ0YdOTR8lG+pjsuh5XquPRlMZdaVqombrmVornVr/Qdd46850LIKp/nWciaathqtIQkGirSbBnmh+bqCufzLNTyzTVcbHXLHTN8+oSpdZ1LHtlG0eHjSs9n7gpe/315T91zzj3HtIoV9s5O43smN191SQj5DPYHJZrYK/YNdCu2aqdaiMd4Cu2KAnGmajlOrWw+jPa4+yO7zJ9nxzZNNWbWCv2DvLUMl7I9cyPTToM3CTdFj8/r8xljGyY3smujO4SdmLOU1sCmWPtgGL7J6K5ZzNwk3fC2DHeAAAAAA8vXyMbHrYr7bMq6sd97yv553QSsbpZ0ZTq2Uw60zM5myOoQ1LhaLPnx77KJ3RY2S83VG5RtGUXQjvvxsol9Splz8/TBZnbKppqs0lZurLbT1wc7kvBc6Zuz+2v41o9NliGO/5lmp5ZpquNipExX2wK/wxlMZb1z+um75jqtBonO2HMrxzsr8iajHsVfcz0zTVO43smN1y1SQj5DPYHJZrYK/YNlE5lGy0OErh15Td4dsCLh65Wzmo+gdY3qtcrWmrWFf7ctslT/1TL65XTYiXqnmtgr9g0V2oY72R65kemnQZuEm6LH5/X5jLGNkxvZNdFUg9Ey01pn9nosmURDc7cGdaJxnM3CTeqq2DHeAAAAAA8/QZe09oqzBp/0zKQvqPYyTKZ8Gf6esjl7T1kcx/emOKPa+1XMISVO2Oxy9p6+EdJGezPP3oC6AU2ARdE09ZDMJ64pcCmxQL+lHL2nroZl1aI52sWb6pm8vVztGhtSXV5jY7W4o9hl0ZfM00wcXaQ6DtHmLAnB8+oTq1c0xbDLZDQkuRMsUTVqyus159SX159bpNXIK50eYsCcAhP5nWjJxipUh1+f0dy/S/VOLl6kO0aI1BdDL5O+/CPkSmdJlLEsiFcwAAAAAABEOS6odM42Z4+0JgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAV+t9di0VfjhtCqdBvxwV6vS5oSgXDne8hodmWffboaAqE1CUqot54+nDHvcqcxLkop8dPmgfa90w7MM+/NkdDQU7VMrddnHRmeXDnZMQkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABDUjUOS2uCnq7Xp802GiOSPebQKR3S5PUGwVKUdQzyy+cZWX0/bPbndk4O/TVTdRy7UePsZJxlFlVsVdsV9dF0mqXbjhoNh9+pz9+zPZm1y8oTTXD6bmcv3lw84udz2/oR6AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPh9Uu1yj0/PvBHueSsbb9lPhI1e+UTi0rFwlG/icod0NKfjxz2VmQp1w01U3Ucy0TneqM7aZVLzsVdsVsYO70i7wlUeuRpE46S/H3PbDwPJZtFU1E+8jTOjrNTr69EGa4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACDq2ifbIZv6aJ8lyNkymdUgtHWxziatv0+QHbWeOb1sPlZGCn6fopGVLSkJZ7P2NxVJeUR7WLOc6r1hGcNGWwrNi9VU6Lx6N8thnl170JBCQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACMk/jlY/VmTjzdJCQOgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf//EAC4QAAEEAQIGAgEEAwADAAAAAAQBAgMFABA0ERITFBU1IDNgIzAxMiEiJHCQoP/aAAgBAQABBQL/ANVcv1d4TneE53hOd4TjLEyNIbyZqwTxkx4Y90YflDc8obnlDc8obiWpqYPePRY5Gyx2BhYxnlDcFuJ2y/C3MkGzyhuBrIomFWhPdeUNxtsY1QSkMH+R1gVEb5Q3PKG55U3I7shuCWcBS/gsn16CV8pjPBFYSHMKuU86xm4fsNB6qcmHwZOTjyDvyjnXqXsPGPSrm6wGtrL1TxouuThk3QE1pJuQn5WXsawAYgTxIWeICwijbwc10T6stShvwST69KHb4VE2cbKpiuscsNhpUety1hbKDlGxVMLh64ulFNwk0mkSKFVVy0cPMTl7NwhwwXtm5BKsM7VRzfjZexpdhrexo0iieqF6fxjzhWZ5YLGGDSLr3Y/Nirwx9gIzG2gTlY9kjfg84WPPLBZGVBN8XnCx4lqEqxzxTfB5MEbmuR7ceeLHjbMNytcjkxzkaj7INmMsRJPi+RkbXWgbVZYCSYi8dZCYInNc17XOaxFsREyOWOVv7cn16UO3y1M7cfKcTow4fsNKj1uXRfLHlaJ2ouWMPQOwKXoGaXU3IHlPD0gctZuqeHF1zLmLqBaVE3VB+Nl7Gl9freSo4mijVSMNlkgFmJnIWOtLlxaYvhMLMPgFk8d+kv2uuUjFlIIKc2sMekoBULRiZBZYJWzw4UVGJEUfOUsQRM6LUGIko8w61ZxKz4STGLEVYTlrCCTOi05iJJDMM8G3cxyKiplz7EKyQQKcsgtza0x6TBEjtDNeHKXctZjpJy5EqzVyYWYfKs58E2ljaIPn65cracxyS1pcKCmzCOGJYVDl1vw7JBAZZ5i5GVpb8AF7QX9uT69KHbvdyMKneQQx3K8OxiLTD9hpUetIl6MEkjpZB5uhOKZEWzL2H/XQGbrh5dTc5jGLJIxiRsmkSKFVVzqKLjNLGksTmqx+Uk3IV8bL2NYeOMJ5cLFuA0wi84oyOUqYIRBB9GjwsfpJG2WOaPpT10nUr8l+0KqkJSAaEZulhCkB1I7mBVeCGlKWRV1zeXRzUckcEUOlgV3RVVXI5ukkTJWWAfZz0pfMmXPsQgJDHDCQitxzUc2ZnTIArHFJDBHAzCYknGxi8WHk9qLHG8mcUWMWLS5CRqVBHRMy634oshcooUIjf3ZPr0odvhoEZcbmqx7XKx1cb3cB+w0qPW5Y1zSI8ilfBIGU0scyHuBNKKbjGq8Enk609PD1DsupuQPKmHpAZbQ9I/IZFhma5HN+Fl7GEEkhniTc8Ubkos8OCHyB4IZEZH8rD2FR63JftB2Otz7Gi2lrJ068aLrkonBPhYS9EGCPrToiNbrbQ9UEOTpGZc+xotpqZvan1mjv65H9d7LxmoouMmpUfUFa5WPReKXW/odv+9J9elDt9LhnJYZWzLCcfsNKj1uhzOmdlLNyGZYQ9A7KuXpH2kvRAyjh5RcupuoaxvPI2WBrevFl305IdKibqg/Cy9jS7DW1rmJGGSopOSyshjJupXqpJEi8pPBCSY1e90j6j1uS/aDsdbn2NFtL3aU6cbH43Xr6v2XwKbzCYn8XPsaLaamb2p9Zov8AXI/rufYNkezOvNnXmzrzZ15tI/rut/Q7f96T69KHb6XL+awyL7j9hpUet0Pcjz8rvYZew/4xFVq2xXXZ/KjxdAdzka2WTqzfKlm5C/hZexpfX6zIjoMEXmDuiFeTWV6FLHFHEmK1rsOajDaj1uS/aDsdbn2NFtLtvEGrdyWPxuG81dXu5LD4HO5AWN535c+xotpqZvan1mi/1yP67pOB9C79D5XW/odv+9J9elDt8KKjFikkdLLlbD1jj9hpUetw81okP8rlLDzmYdD1w9OPHKyHrH5bTdIDAapChvAszwLM8CzCx+1JyKRYpWOR7NbL2NLsNbCdBw0RVWJnThsePkKZUWv1Ncjzaj1uS/aDsdbn2NFtC4e4ERXRvGnaTB8JoutAqOikEIQobW7JRGVMHWOy59jRbTUze1PrNF/rkf13sPGOqJQcv5XW/odv+9J9egx8wjHXBjkfI+V2MY5764FA4T9hpBZkDRPtjH45yudkML55QxWiD6Hw9A3Sih/1y9m5p0RVWCLowa30OtPN1QtbL2NbYDjCeZDzzAeS3sSIQTKVJUgq+TLsZWz1x/ZvZYiPSSyEjQ22eQmVHrcl+0HY63PsaLaZbAK14Zsgb4rcWRFsBEQi7iag9uSpOW9erlEMkDkhtxZcU8VEJu42p+oTMAIgY+XPsaLaamb2p9Zov9cj+uWNs0RYrxJg7h0LWWgb8dZhsye8YmD2hjicut/Q7f8AeenFnijc8Ubnijc8UbiVBq5FRSqowUIiYWx0oniTc8Ubnijc8SbjacxchonZANEM3W2BlJf4o3PFG4FD24eFAGzlBVZDS/gfApIfiTc8UblUKULPqdXFym+KNzxRuJUGrjKQlcHpoYl/jR7GyMIo3cVrDExlSY/BaWONT6qaQmuhfAFj6sxZBWLGLrZAEzmVI8ow+hNNFKr6cxmeMNXIqSd2CgQial1EM6yU5bM8YbkVJO7BQoRG6WQBM5lSPKMPqRWGPJronwA6L/HiTcYnBmTQRzsnonYtUa3EqjVyKilXBg4RG5ZgkkF1I0o0P/nIixHGVb6PI7sZyxyslZ+WWpajD19Z3TUqw0Salge0IM4cz8svv71qtdX/AAMtIxV8sdLkd3OxwxUZUeGWEQaLcFyu8uZEr7tnbAEPKFOsyYDNC5HRC1R0xUp8zxwg7fjDLdESOq5S5Wl2EIeOuinuS5LYodnCVodaMFd5OwlxtwXE4QyMxn4fYh92OOWRXSRXY7sinimTLIntRKsFCntajUJFjKjDkeDZTypBAHA6xNjiZExzUclsFGM6n9daey0P2FDuLb1gITjJoBoh2lzoMMEM6wKihjhY+NkjbILspQSu5Dr40KsEThkkUcrYYIh2fiEw8RDZaOF2T1xImVdm6V1879UO1hGF89DnnocMnaQVcSL46iana6X31U/rrT2Wh+wotxbesoP7Zeu4D0rOUHS2Zz11C7/JI81cVFfLkVuLKqKip+JysQe1vW/9AIYkwXjQ88aHnjQ8u2/8FEv/ACaX31U/rrT2Wh+wotxbesoP7ZfJ+hSv5gNLR3LXULf91RHJJVhyYXSoyOkJd1Pw/wA2rSYp4524SVGLGI1xtnbDKQJUHthz+dFsBUlLh7gWuK7Iprkcks0cDLA5TJKf11s3lsYJmzwvkZG2wtmyx0O4tvWUH9sOH7kStL7Mhrkcirwy2OQh1cP2gUJw07sMIYONSRq438PMrYS8fUGRO7e1yOnKlcIHGGzDKdszuysoM7GymwSlbG7DauMpUqj4sZSkSutRohR6f11hXoY3xthErKcuVW1MMY9WDMLMfC8gKqCmEXQ2rYUvYWI+dlZT4FUsHc9jZGEUb0XtbVuNqTJ3CixiRfjJss0Iw94qY22DdklyI1ssk9oXBEkEH5ZMAMQq0Y2NpBmrDBHA3/5N/wD/xAApEQACAQMEAQQCAgMAAAAAAAAAAQIDEBESEyExMiJBUFEwYSAzQnCA/9oACAEDAQE/Af8AV2WYkapIi8oqsTkz1IhP2ZNtMpy9rVHhFPJUkamQllXqdCjL7MTRCeeH8LDoq9lNYRV7KXZLoprkqr3IvDtVfJBYRPmROOGUn7Xq9Eerf523Po1yXaIyyTlgdRGuX0Rnm259GuS7QnklNI1y+hVPu2vnBufRufY6iRrl9EZZG8GtvpG592184Nx+wvwQ6JppkJ5KvZS7JxyQnglyrReUeUh8Iprkqoi8O9XoUpDnIp4/hT8iqRilaPmVH7EVi3RBZeXaccopvKMZnaqQikrUiXqli0llFJ8GMz/FDoq9Eeyr2Uu7S7KfRNYZGXpZSXJVfBCekdTKtB5VqvRHq1Th5HLCyJOXJt/sp+RVF1ZeZLzvLopdWZSF52qkerUjGZG3+zb/AGQhpI/2fijUSROeSEcsq9kHhkqn0dkI4RVXvamuCo+RQRoRNYZSftar0RksGtD9bKi4ISWBzSKfkVRdWXmVF7kZpmpCakL0M1InP2RBYQvO1Uj1akTWHkU0zUhSyR/s/DtI2kbatKCZtI2kKKVmsm0rbazm7gmKmlZrJtI20JYttoVNIUUnkcc30c5s6aZtqzWTaQoJW0c5s45vGOLbaNtW085/FrXzHcjShLA5pCknbcQpJiebZ4ya0Z4ybiE8jmkKSfxLj7ozJdjl6coi4pEmu0PmWLLzIdsfRHwKa4yPmWLdSIvTwxYfxKknZLKZHDRwPiWbJ5mQ7ZJpIj4FPxHxK3cjhmMS4+JcEzbVnBCgiTXTMRIcvI4JigkY4wJYGsm2hLBtoUUvj9C/5N//xAAvEQACAgECBQQBBAAHAAAAAAABAgADEQQSEBMhMTIUIkFRMyAwQlAjQ1JhcICB/9oACAECAQE/Af8Ai0TYv1C1YOJy0YSxNjYmnUEdYwrXvF5TdpdSMbllIVk7TUVgdRwoXc3WajA6CadAepnLT6lqbWxx04BbrDZUDjE30n4l1O3qP6McLvMzTA4l7bmml7TU+MrBLjEvbC4mmbrtloymOGmXpmXNlpWNlcpfcs1S/wAuOm8pZ5Hh/k9YOsFAHkZyaz2MesocGVV74tDHvOTX9y2rZAMwaf8A1Gcms9jHQocSuovOTWO5jUfK8OQdu4QUAeZjUDHsMWgnvOTWfmWIUOIqljgTkIPIw0A+Bnacn25EFAHkYcZ6fqHC3zMqcOuJdTt6iaXtNT4SmwKestq39Yh2PwsXDYnhXEG5sTUHamJpm64li7lxx03lGrrz1MWqqajd/wCfov61gzTdzLLGY8LOtM069N8dyxzwHUy5tg2jhS+1peu1oWK1ZEJzNMeplrsTiDvNV8Sv2V7oTmVttaaleuZu205EJz+scLvMzTeccZWaXtNT4cE8RNSPfKW3JLEzYDNS3TE0y5bMtq3xNPtOc8Ll2vw03lLPI8KDvXaYle5sRnSvoBPUf7S/8Ymm+Y3fg/4ZX+I8a/ITU+XAd5qviP8Ah4aXyMfyPDU9hN22oGeoH1PUD6llu+N+H9gcLKGLZlVWyXWbRiaXtLkLjAiaY/ymQBLX3NmaZv48L2y804wmYbnz0nOf7lTblzNSvTPDTeUsRtx6TlP9RRyU6zTt75bWwaJUzS8YSab5jd+D/hmnfHtMspZT0grY/EZCh6xhzkyJsb6lNJzuaXPvaP8Ah4aXyMfyPDU9hKWDLsMap1i1ufiPWU7xvw/s+peepeHUPCcxLWTtPUvPUvGsZu/BWKnInqXhOZz2244payDAjXswweCOUORPUvPUPGYt34DUOI17mGwkYMSwp24mwldvBb3WHUvCSe8VivaepeNazd+BsJXbwSwp1EJyc8HsL9+A1DiHUPCcw2Ert/ZAJ7TlP9f3GdlWROY33Hfd1i1Mesatl7wAntOQ0NbAZMZCvXgUIbbOS+cTYc4nIaFSveLSx6xq2Xv/AFKWYG09psrbxMWv/E2mWLYxlSt1VonsQtwYk0jMu8Vi94/5pqGO7ET217uB99eT8S1C/VYwYdD/AFLIy94OsYgOuZZvVoCxie6sjg67ahmXeKytCx6R/wA0v/JF91WOHhVg/MyywEtWd39StrLOe0JzFuYdI1zGIr+Szfb9S3ogU94tzKMQ2sYXJbdGbccmKxHUTnmFixyZz2+Y1jN/XAkTmv8Af/U3/8QAPxAAAQMBAwgHBwMDAwUAAAAAAQACAxEQEiEgIjEzQVFhcRMyQlJygbEEI2KCkaGiMGCSNHPBFNHhQ2NwkKD/2gAIAQEABj8C/wDVW/lsX9RL/Mr+ol/mV/US/wAyv6iX+ZVBO75sV75geOGBXSRmosle00cG4LXn6Ba8/QLXn6Ba8/QLXfiFSdgI3tQew1adqcxstG6W4Ba8/QICc32bcNGTG2J11xxK15+gUbpXVe4VNkgilowGgFAtefoFrb3Nq6TQdBGXKxktGg6KBa8/QLXn6Ba78Qs9rHhXepJ3T+xncrS6NzAAaZy68X1P+y963DYRYI+zJZP4TaJWOjuneV14vqf9ldlbQ2PgOil4KOYdnA2s3tzTkP3NzVHH3jZJJuGGQ6I9sYZc3NX5Y6uvbytT+RWq/IqsDzXuuV01a4LO1jMD+xXcrZfFY+N20WRU2Y2T+G2Pz9bHk6WZwsc7Y1qkj3jC2SHeKi18h7IqiTpKdLsYMOdkcPeNTZAe+zHnYyQdk1QI0HKm5r5jkRyd4eie3YWVyM6dn1Wu/EqjJ2E7q5F3p46+K3GdnliqdOPMEK8xwcN4OTnTs+q134le7mY47q5OdOz6rXfiV7uRruRyLr5mNO4lXmkEHaLM6dnkaqgnHmKKrTUcLKuIA4rGdvlis2dvnhk1e9rRxKp048gSs2dnngsLbr5WNO4lXmkEHaFVxAHFU6divRuDhw/Udytl8VhYNY/AcLOmeM9/pZP4bY/P1s/0zes7rcrM7WOxdZI3Yc4WRv4423NrzYHbXmtj9zc1RR7CceSvbWGtrRtZm5U3NfMchkY7Ax81JJsDaWOkibecF7yQu4KrYSB8WC0M/kvexlvFBkjr0WjHs2v5lRtjF+W6Kk6KrPe553KogPmaK8+E04Yq/GeY3psjdDhWy+/yG9ZzqM7oVY4XEb9C1YPzL3kbmpsB9407+zZfk8hvWJus7oVY4jTecF1AfmWexzDsQj9pN5vf3KosdyCLKXn3s0Kj3E/AFUQHzNFekiIG9Ag5naarvs2ce8dCzi+R25aj7he9jLa7U2F5rE7Dlb0cNDJt+FdqR5XVa3m5VMVR8OKzHZvdOhCRnmN1nyhOZS9JezQs9xcdgWEDvPBCM9bSf1HcrZfEi41w3J0j8Du3Jri28Aa0KoM2Ta02T+G2Pz9U6S6XU2BOe/rFNluB93YVVhx2t3WRzbs02xP20x52CMaGD7prBpcaJrBoaKJ8h7Iqi46TipJe6KJzDocKItOkYGwxHQ8ffKm5q5K+jr25a38StYT8pRHs7CPicqNBe9yDNJ0uNt5sTA7eG2ljxVpT4+64hQu4U+lj+ZQkkzI/uVSJgHG2RjerpCI7ryFU6EX9nshD2iYVri1v+baOAI3FHo42trpoLCew3BqHtEwr3W2lj2hzTvVOw7qo+zOOjFtjuQXdjGlypGzHftsIIqCpIxoa4hCV5uxequxMDRZJGdosB4Jz+1obzQYMXvKuMHM77f8AUxinf/3QYTmyYednyhXGeZ3LMbnbXHT+s7lbL4rDsk2ORa7SMEHNNCNBWdrG9ZT+G2Pz9bDJGKTD8rBJGaOCEg06CNxUke0jDnbJDuNQqlPkPaNUHbGCtgZtebGna/Oscdj86xkg0tNUHDQcmbmr8Ud5uitQtR+QWo/IL3kTgN9FRoaW7RT/ACrzNI0tOzLn8Sj8/Wx/MqDwDIdyCk8akppdmqOPeceWVK7bSiZH3nAIAaBkOO1mcon/ABWO5BSePIn/ALjvVRefrabG8lHFuFVJLuFBkSs3tKDhpGKqvlCl8X67uVsvitce8K2R7nZpU/htj8/W2Zo0XrOj2SD72SN2E1Fke52apN7s0WOlOl5+1lzYwfdNZWl40QaJGUHxLWs/kmSMe0lppgbQ3azNyZua+Y5B9ohbSnWATZBo7XKwvkNGhUgFxu/asZZDwqtEtPNa6QfMi9xq4qPz9bH8yoPAMh3IKTxqPx/4KZwByvmCh8/TJmbvYbXcgpPHkT/3Heqi8/W02N5I+ELMe5vIrWv/AJLWv/kta/8Akta/+VjeS+UKXxfru5Wy+K0jutAsZ4gp/DbH5+tsxHepZDTvWRTDwmwEaQvZwNBbfKoEyPuhFx0BPkPaNcsx7JB98mbmvmORI06C02Qk6bgXQ9lnqjJJqxhTeqRsa0cBZnAHmpmtAADtAUfn62P5lQeAZDuQUnjQO56i44ZT+BBUJ+KmTOfgITWd40sdyCk8eRP/AHHeqi8/W02N5Lm0FSs2h1cv5QpfF+u7lbL4rC955DenSO0uNbIxsbnHyU/htj8/Ww4+8PVFvSbIx97JGbaYZEY2NzjY4bX5tgldIW1OFAte76LXu+i17vonRVrTQbGyDS01QcNBFcibmvmOQ81xIoEANKYzutAU1e8hTYTXImc01F5R+frY/mVB4BkO5BSeNSR7xggdDmlNlbtyXxntCiIODmlNkHnzyB7O3ScXJp7LM6x3IKTx5E/9x3qovP1tNjeSjmHZwKzjmPwy/lCl8X67uVpbHdoTXELBwbyar0ji48bA1oJcVjjI7rFT+G0RMu3RvC64byCvOJJ3mwRxtqShGNOlx3m2VmytRytkm35osZCOyKlUGlMj7opkRTfKbQ06Y83Im5ro5HEOrXQuu7+K6zv4r3UbnHjgr8h5Dch7RIMwdXibB7QBmuwPNEOFY3aeCqJ2jngtcD4cV0cQuR/c2R+frY/mVB4BkO5BSeOw+0xDNPWG7iqtxadLVnO6M7nKvTsVIG33bzoQD89rj1Q2w+0xDxhVZiDpas5xjO5y/qGfVU9nF53eOhbXyPKu9s4uNjuQUnjyJ/7jvVRefrabG8k6N/Vcrj9HZO9COcF7RoO1a4DmtePLFUgYSd7tCb/1K9ilnyhS+L9dw4LU/kFqfyC1P5Ban8gtWBzcF72RrR8OK923O7x02SsYKuc3Ban8gtT+QWp/ILU/kFjGG83L30oHBiuxMpkMkhZeOg4rU/kFqfyCjjPWpjzskl6HAnDOGhRumjoxprpGS+MdbS3mtT+QWp/IJ3SR0Y4bxkSSMiq0nA3gtT+QWp/ILVAfMFnOY0c1ekPSnjotLHirTsVfZ34d1y1B+oWru8SVenPSHdsTpYQCHbEyOQUcK2OIhwr3gomOFHNaAcgyRR3m0GNQntlbdJdXTbehPRu3bFgwP8LlqD9QveOawfVZgq/vHTbfj92/hoWDWv5Fag/UL3jmsH1WYM7vHTaZIo7zaDGoT2ytukurpyJXtiqHPJGcFHHIKOFfXI1P5BNHCy5I28FWCTyctT9wtT9wveyNaPhxXu247XHTZfijvNu0rUJ7ZmXSXV0/+c7rn1d3WrCF31WcHs5hXmODhw/doDDnv0LppSQyuHFU6H7le6rG76hUAut7R2Efu2HkVDd3ZNxufJu3L3bB8rFSWNp+xV+M8xusoc5+xoVImNHACpQ6WMU4torzGe97pQlfSpOxSRsIujhwtlkb1mtqntlIoBuT5Y+sKeqkd7SRm6KbVSFoYOVSnu9p0dmraKjs5/dCpGxg8qrPa08xRXepJ3TZ0bBfk9FVmA+FipM0O5ihVWaRpadn7Qo3rtxaiwtw2scveNdGfqqxyNdyNhLeu7BqM0uLAfqVQAAcFdkbyO5XHaL1xyfKdDRVOdIcNL1djaGjgqOAI4pskeAf2U3mVN5els/hUvhU3l6q7WjG9Yq7EwBPl3aE50hN3S8q7GwNHBXXtDhuKa+Ktw6OBQkPWGDuaHS46XGu2y7I0OHFXYmBo/aNJYw5Vie5h44rpBiB2mbEIJzV3ZcombhVMi6N5IWqetU9OlYCK00pvxuCkdtL6Ww803mVN5els/hUvhU3l6qfy/zZG3e5Xu862ThiFMzZgV0jK3a1Y5e9h82lULiw/EFUftSjNDZBRRP3toonmFpJGJWoatQ1ahqbTsvCkHx/4th5pvMqby9LZ/CVL4VN5eqn8v8ANkTviVO64i2XjgpnclQioWpA8OCc+B5NMbrk72cnNpUcP2gWvhpGMPiV6N4cLC57uQ3oPPevuVWjOZiuglNGnFpt6PpheUkW8YJzZcGnB3BVaajer8jw0cVhhG3qpvMqTjQ/ZNkYagq89waOKdDCKg4FxUvhU3l6qfy/zY+Pbs5pzJcGOwPAqrTUb7BFEasbt3lZ+DjnO4K7HKCd2ix7nEVpgN5Rfsa39oXupJ3gqxkO4tNFT338/wDlVlIZvqalXWDE6XHbYZICGO7p0KjL4HwPVH36fG9B/tBDz3RosvtNyTfvXu34fC+irPKB9yoY4xTE+aZzKBabsjdBVGNPNr1WZwbzNSntbjI5tLzk90oFCKYFPij6xp6qXpQBepTG2+3Mk371SO9T/tvVJL9PjfghJKb8n2CLHirTpVYHgjc7SqDpRyk/5VZjd4udUq4zzO/9tF0LL7/RU9oZX4mrW05tKzXOedwahdbyHdTIhoaKfu2r4hXeMFg+QeaxMjuBKuxMDRw/+Tj/xAAsEAABAgQEBwEBAQEAAwAAAAABABEQITFBUWGh8CBxgZGxwdHh8WAwcJCg/9oACAEBAAE/If8A1Vg8wieZMeF55550P0eaERiVQZdvcQdRESwW4vS3F6W4vS3F6RS/n8EE8uYjogbxXAI2krCsdluL0gqSliYD2IEEOOAJP2RgZLcXpG1PMQ1YAFGUoW4vSdhAMBIJAMnJHjIFl2QW4vS3F6QBftyRbsBigicnV5H/AA2vxdmCOPyAwDDJFpoGD2JTEZ24dAcnWBn8IjFRBz21gYDkp+QKZ1Mukd6xfpL6Z+NwSebPp+uskUHldAMGFFMtj31uB9Un+Yfj8e7yVZyB2vBW/wDdEgkQ5fZFGO6U9UShJzFwVNUEnNwP+F1+O1ygMUMRjgcYMIk8+TQ1WOs80AGSncIXHl+qle5760XGMu1V9RoMFQ5bkclOcKPmfjwYgl+lDekDsDMny+RComNCpuBweLd5cPBBVs7c19BoCPsSQDksERYMiwemd3whogUkngB2JlmZAAOSwxKcabF6JlAHaOFzUauCiIECEVAcdEClt3ojjYATduB2RhhCLBx0TAA9Qek/S+z/AAZazYKHqFiOCiQA5T8HAqPQTeA53kEDinoScQY5VyZVHdfgjzOOfzQIIccGfsmk5hNpIJomjYvZABycGNwNswUMUbEcFFIquTBGndIup6PZzf8A6a/Ha5QAcyTkLmBTsAyGEOux1nmgF9u5EAcsKpqAaNlBsAx+gYYLhvIZGLWNn0E/kHGDFdNoSoXluldXToz9kKlsSfRSLuGe/wBacW7y4aNi+qT9hKfyAJdibDFel17ISCJf6INwNkENif0KndHvF/QEC4cRVlLGxmqZZJQadlKT5Xkmeo1JBnZAjXshmrI8ZQOSzoOpIryqn+rDMJSHunYMgATQwkkS7p4S+rDF4HZpUBUkcjDDy64oPNnSU1TkGWAIEa9VOxTsBkLubFARAQZgiGxYJ3x+bIDBTOcyo9lLS5XkskPmI0RoxM5B/UOaHTn1ZUWE+wQ1wXUXtNbfRZ3RQJDHviROMxp9FE+zxT6OUUcnjuSBhIb6xGwyuFhHnkHrtAGCfhuZNuQTGwfdNOFBIkox/wCmvx2uSCDEBcgHKE6SFgdmCAMABUiqVAfixhrsdd5kxRYSG7lGKcrlCPODql5DUrA8OKvj7jMVybyJGD2KPqn8VI8j1UikQFRYKhwXI4p3RJnzP8VQckhDseA7Sy5Nni3eSdleFnlZjdkgUskEPKh6PRPGE5+lCyXeYMX99YAxHvFYgr+VSUYxXzm9RUZAlp6Fnitx6xEIzmOc0cjYND7QDEYJkol3ZLACOGymQk2JNAnNVQOF05JOrI4s2vLFTZqtTmY1uQAEVm5nEfCM/TejcQ2LBHRBcN6gmQhccy6wBmAYg3Q6Ub0KnsiTVXl6C8BQggrZGyoiHqkCmdrlJjXCdSg6awZlFi2ZgF0LfC+G84sNhYCvQUAh7mT/ALa/Ha5QcQAQ/uh7MdwRKJTgshUglhjmtdjrPNAGkBwQG5DHshocIiU9TyJiLxH3SCcjAByi1MdHtE110EGtNH0E/kHqEx3rRoNEJID3rCiU0I64XB4d3kq5pQvJW190R7PlTMOuk7o85Zm1IYFbOnG1Fa/zRVteHBsWC1nwEd8Zjuro6w/GPIgAADAcJg+DyeXuAcDTYDAcA2a296I+HADyMjDYsFrPgcGyYlu88dFDR0YFQ59f4nfFLrV8Dg5WbmyrDrEIIXDwbY5f99fjtcohDW/X1A7PP7612Ou80Q0EMjrOBTGcJkn9gzYbpMwn43fX9ZOoFtU/HgxSz5P14MAmj6p/FLoxcbIDuAASL+KQO4+ADIxfoz3crcO7y4OIBDFARHNTEYok1TBjcgXDiiEtrCiwS2Yc03y5sNVXPMkklixJOCw5OK1/mira8ODYsFrPgQ0CWbgduImIYoB+Z5OHIg6QJxOS2LBaz4HBsmJbPPHTQ0dE+WBA2AHIX9sv7Zf2yc+6Gjw7a5f99fjtcogAGoefcHya+xa7HXeaNMZ3ZKD4Y8CpP1HuBy2I4KHZZszsoAgA5NEAHZHVEYYDlEqA/Gf0+i2eHd5cNDQcAe0D1cf7IPEy5jElXDeZWS4moDWC5HRKDGAwC1/mira8ODYsFrPgI4u0T2I9p9ksCPcOJwf2EM3TyS4RlS0h1kjjKgQSC2LBaz4HBsmJbPPHTQ0dT/aN6QTZDuH5/wAO2uX/AH1+O1ygBs9mpIytYgUbU6Sa7HXeaDUARfqiS4S5MCvxWdUvsGfDk7mE4kmOXaicATO1+tBqjMZ70eDoZmOSX8yv5lfzKO8AYSXEKXrQu7jAcuDd5KnwRzs67KA05FgF/OxCavkFdQXNF2QcBTYi61vmira8ODYsFrPgLGPvrIZahOxCLDIJjA4cIqUKj9XbyFXjMhwu4DvT+ULbyRTYuvWsNiwWs+BwbJiWzzx00NHRRKrpmm80MhoLzgbf8O2uX/fV419STE0M2AjE23N4ETowAuiJ4m8DJa7GsbWQEYcpomJdSOTAmLRKcDESQHlU4tHCZew+oOEl1o71QABykEIfZ4EwI3OPcX1Tuy28uDd5KelMjl/QL+0RgMUSlPDahTkTeyaJ7kJKLdwQpmpgqWK5DEfsnYct8EZlGqTsENb5oq2vDg2LBaz4EHlE8VyF+KoyKHnC2PafDpF0VEYE30qUuVA5NBxAWk+VnyVQoMMgntOw9F6MTDWGBftAShg2MlXMNiwWs+BwbJiWzzx00NHQ4HAxRYJy5IKUBANH1AZZESEImXlPghh5NXYhQ5E2ICO0e2uX/cgSpILf+63/ALrf+63/ALoxNUOjDExX6KzCg+UAA7Otv7rf+63/ALrb+60Mj0iyCIwH1Kb4G5ueZ4GTSG2CVq9Vv/db/wB03Bgdzqw/PxlfBTOsS9SlDjwjFfSFt/db/wB1fv8AL0xS/PgmKuYLc1v/AHW/90YnmD9EXHcwoeKDYG7UAAYBgID0iMSQhiHrByKLMeiT2izEQwaEhQ2jcqdK6diCnKecHBvCbhGR/dNWhGBbge8opLyVJLqDDJhhAhwxR44sD/lGGDYg9oGbDuj46+chz4pvNEoI9Msm6ItKMfugYtsOaOg5amVVZVmFF7yikvJUkuoMMmGHA85SVATzVWPwd7oi5jJbf3RDlQAgbhlxsgCQSOv3Ri7MfZEROOf2Rl8NTEyJ7EFCmaJF5KleABhtl/5zPmXYcpzMjMEzs8cGiAj7cn/1rXAzFgLlYUyCqlzJepP2R4TtJ+RCk1zC/uf60S/b4q2QNPO/CfCxwLDmKeGRwIUzG3ABV1eSsEyJQ/tYIpwISoPA4DGVRk9rIzzQjRMEskI/OGfKiRliARPZ2GZdHEAlnD2BNFy2XN7ybosCCJOMUiYHFCHCWnuwWQAgESGxlxSRET4hXkYNo3Q8udEFs8z8uhYWuFx6cjMn+QUuBnD4VYwWGgcoMTKT2IFJm6EcU6LRioHHVADInEds1AIlhsRivPyCLiNd6QsKbAyJzVUA4U1VEHAVu2K13gQhrq2Oa2OVGQVTAWZwm56oiZkZMTZF5gzpyQEI7AjMu2HRToD3zVXw+AYFT7LO6gAwDAWCK8DQV8Ryv/kWJPMTHVPuBkhZ/wDemjhQ6uRTr6q3mfxFS8XIaZWzC2YQnjS5EBlk9n9IT8IAfY66t2xWu8CENdW5zWxyrRQj2d09B+oeKMT4iGgdveRHVnkUsoWmnJAAB7ekhwnZWqAiAg0I/wAmQCGKMK5CLTdk3/Aj+rqpmi2RW6K3RTrOXYMQhYkP0fI6yt2xWs8HBrc5rY5Vo4RTaAxp+IARMyHn3EbywAOqNJSAB+6OQiVBRByTmKMJK70FOREpu7/HmiL4kcLFyq0aQBGEs3kQZK8oHf8AFOGO0Yi6cH6c0BwQIBwXCJAQbOi0qd6LFjvLJrR6/hA4p6Aao+zRVQCAsFzmVu2KOUaCBAYA+ybbtzZMRv8ACWxzWxyrRwmJtflKfDpGQOKegGqADkgAXKc+NyCGstrPayIgTdMe8HsQQUNCnnOZ2f8AIfoA5rJWXLWE03wqXFrrMkBwImaj4hKfSPlXLLk+UCCLGxhnOYCXMiJABiQaOLzUJ24xJqgNneZCyckEYFPM0sADqgPGxXTtsC0WtghaLFMuhiAyzlrCjE0JDsYvbxwEuZPjzZkFE+dPaDoaQVANpQ3ILAUc8s4OqE7A6KDIuJCbPmWpf5qcnObMWut9jkmITjgPSc2KEPKA2QOgYlY+IY/60w6rmiOL5Ez4n4NwAGgXI5Sv/wAnH//aAAwDAQACAAMAAAAQ888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888886ALiqJJblph83HRQJ88CGbv8888888888888888888888888888888888qDhFjpXQHsX8zDiik88op8YFL2KbYyMjt6zbAN0aX4GpK7vbLlzj88888qDSOzpX1AXDkf1TTS08oaJis34FC6s9Ues4qcLu5TxgXBrnAzSn888888qDBXHpX8DQh4XeRBCi8op8Kd7lcCv83N88Fe8EC/8BBqB0PfPB8888888qDE64pRcFpuCqP76LM8o/OYXgB1C/8AFQGAhMhf63fAQ6geSSDgfPPPPPPLPOMo4fE0PA/JwfPA0fL/ADCLyLNLi/wPzJANqEHwPyAfzJmJYeHzzzzzzzyOvTzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz4AMk4cUA2d8CMUg87zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzxNhzx/wzT5aqeTMShDzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzwkZLvMAM/puqpDRR2/zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzyuac7qduZHLMJD7JWLzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzw90Xzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz/xAAmEQEAAgMAAgIBAwUAAAAAAAABABEQITFBYVBRMCBxwXCAkaGx/9oACAEDAQE/EP6XP3QUslmrm+iCUxChY9m46wQlx3bHBl1qxignvmyy00iy/wDqdgxV5PheMZQibZywsHcVv9TURUuLASpi1E1BNzlxnPHrFouWXSO5ADZErAc3HtBSoFsWtG8QM2YGzZALQrFRqKeYIaMYo3EtsAbIAtxgQ0agiWSo1LHSWTf4OMtTOd7OWFjqJr4gHrFCx/yxWMsvNAygc8YEAJV5U897xVY0ROCEWY0QRlDBNGGhcusRWeZpHxAIMANE5IASO55zR8IAFEBCWIlWGABR+HjhVBnLL0jubElQSy0opNjUvCsVOOM54FQxDbGX8QKQzgnLHeajPedMcM8p3xwTjGecbJdS8XjY3On4gAxP2x7PE5Q7mDVQEaKcsKP3yysGbJ65Yk3OHGAG4j5iaSX6+IgFwjsVpnBOWO8dKeIZvsS6wzUWl5BOMCoaad8cE5xnnGMwLsT6wjZOn4fbPfA4AFERtnvw8AwQpnvgUV+gGbYxZgzTPfCYCjC+CpCF3AorADIQcACiAKYx5OAGAu4FFYHmdi8DgAUQJ+EUC2e35hBx8RfVQzREKmsIoFuFSiCkPEWi4Fg13A7NYQFkQqOUfE3tlM8dcFUOimsm5rLkqAFX1jdp/JD9kNa4SiBrOMO2hi2HxPAigWzQpUNRD2aq4y4SJ9Tmm0T+ScIt7xwO84Sg+4gfiSFz7FgAURTfIJt3gnv/ANzZHIxeGCQAUQBTPYwRRHwam9PjkHs9M5/aZ//EACoRAQACAgAGAAYCAwEAAAAAAAEAESExEEFRYXGBUJGhsdHwIDBwgPHB/9oACAECAQE/EP8AFu0KIvyo2wE7Yj+twSyHqWKBAvBUBKPlBQq4D0RC4IRlC52HylmNcXALxHS17EMVp6/EA8v4HtDXBAa6YOHlibfM0+fzwgG/MzM9pfcFT65Z/KEC+YtzuWhxb/E+u4P0v/cQKAgl1Qwc/rhINotVMpgQ1b+SI+pEVEILqhi5/UuCZcwTSy+o4X2cFDlWCaIq1kPvAhiGfklocUBxLsiKpl05lg2qEI0/ltDXDVwVXKdiTb5mjz+ZVhvnBNNxAvlNks4PlkpOqYRzlT65Y8W/xHtyeSXMN+5hquBV3BrMyDt9uEZC44Khe0ASlicAkc2VfDcDkw7TnDeyiIrY1UVpwMSWJp7Sj87+kRWxSSAHrly2RFb/AD2hrgrfJBYZt8zR5/PC+TpBLHMlAz9y1Kj1yw6Jg5qpRnThad88N/ifXcFXLGnXzmUdyxQ7fabxt4afUyq78fqpq8cNVRfdNPriPrmG595DHL1P2/8AJ+3/AJMfFVNfr+jaGovGmCb2wl5mbfM7xJYtYjYMuxqZn24YrpPLI5WxwVepeOnhv8RbC3BGrQkd4BlzjFrDEtUSvO59pvG3hp9QU8yYQsjdEFoANhE2lQGgEyJomn1xH1zDc+8iOTGritEMBGv1/T2j99ztH77i9YiK1hqAnaP33HoE3Ljo7R++4iVnLTp/DC0Azxw9o/fcW6Ra3c1CKcwmteIf1EuuqLbfAY9cCKu/MZqiIWopaqAciY9Y4DHrg0xRFz4U3TBRsgFOY7VERWy2df0q0LiRcJW/i4g2vOAtiiOxB+Q7wyxiO0Mzx/OVIqAC5wLaJcG4Mqajg8vaeOMUKhPId4Zenwk6m46Me8cEXLWOUGAwzBNuJbdxg6vzPpPxNfmavJFO+CK8bcS27i65FFnILkPhIgiBVEFFmsy4LammWCt2ZgK0RBbX+Zk3b8QLSavJN3r7TKOxlRHmCljmR25dfCTqGzvHlARFbBLZO8Aox4lSN+DLxEuOqVJk7zn9S5NxUgjZObRcvhmAFUfMNp18OQsa4BVbf9TP/8QALBABAAECBAYDAAMBAQEBAQAAAREAITFBUWEQcYGRofAgscEwYNHxQOGQoP/aAAgBAQABPxD/APKsBapBWbiXHcr0j9r0j9r0n9r039pmIWcT3K5YVmpKEG+jyg50Pu0TBcxMmsqaeVoMjO/xDVixYKyE3EjRCSYTgaqYekVkwGInuVFX+QoRhfIidOAYCcoEtSBMb0TQRJEz+Dx2DIjYLjir24BgJMALMEARAhwdC0DEWTKLeJ68Ox0kbxL2B80c1U7YdNkR6/M+0Amgg4pPGtGwfrJ90H68Jd8Y8UTnDFPyPKzt/RvW6PGB1GErE2hUgY9K50oujfxh4T7yMsAVc7J14ey04Wpg2AGIUZhGWtLEUZF6ku7um46iWeDOWPrgIIcxO1Y6Fc5g9EeLEBF7o8uKKF4Mand5UQMUhGUruhNRwACAMqCEKzddvJPhaJiC79urs+TXjPpQXU70IiwFaiqxrdf0qjta4g7QCTrNR27pYVIQxPmf1JOY/wBF9bo8fC/XhL4UmUSdDwbpkboF+odeHq9Pi6DtuyjE6knAYFqW6APD2ooQrdpv5BSIwkJwmWiFlKjuHs4313ZrBMUlRxmKt1qD9kiYWZOju4QZEwdEerPA+piS3JSOhwJZrQMwbnUk60LwY2Ykj8dK8Z9KwfXD4D+DzDFRfsDpUy75HIPC4uBBdVgKQMqECOhNKETbRqW8loE5DC1jxHpqC/nCMceCcwXUgKgUzETjyrlBCO4FGFLAA7lLHFQSsFWwlCFzJUABlYuRQKwYD/24jtSBLYpFjOKXMlR45cILuwq/mxARzMT4PwUFChws0E8pIBqJSJAC6uVL4EZIOkSrdRgfcCi7TIick4JMYBAdWrNcos+m0fLTAXD0lGkESRGz8FRjlj5qeI2juhSwBgLb0hQMgJEZHjZepYU5w0CgpIBslYxciB1auMt0dymR5KUDjDvc7/yet0ePhfrwsU0hvg/ibu1RaoQJTF8Y749uHu9Pi6LSAGHCZDmp250wAqYAxaWIVNWy3SeVqcK/RgV8MnThObB0mP8A5CvTjIqzZMOMe4OvCZJRno8CevCDEEjfS6gkINGo/AalZ1sma77HpxvTL5BfyB0+JlXjPpWB64fAXidi4IMdgetQNsZbk/T71lQTelljMgYxjHOp3PtpQXYW8Vn8SjxQ+KXIdNL3AoAIUAFOgJJ607qxCl3GhmdqA0EbiZ04V6LVqELHNIWd1PI3oC4cddsbeKKkokk+yGnF/giNWTBzpWVxM8sPYpGrIHHUO4ydOEuxShyx+uVBKs3KE31bvijjhk+QUD0qeW3fylGVq5kdhZ6NK1NSigx2DR2CODpSXYAUwt8WIfZz7FZI3gxqKJOVMkpq73SgF8ujdsWejTzHCP8AkeedG/cQkRzHgKcu30Fn3F0mbHioWC1UnkAx6y0dLZJJ9kNa4YYXNSHWioav2dQy0P5TJjLg9MxXjnRKSXCs5GHQoOeOvdkNJFAhoU6QknaaEzsnM1hNCcTeax4WUvmuh4Ms9KuhwgvF+HgohP8AIT4mjTRKSPQv4qc0rxQztk7lW2zccwuHrc6LyCTJ1xdJmxjtjRSLgqmwMKLROZEOchpsPeNXpyAOn8nrdHj4X60gHLRIJgDFrSssCw6PuawMGwozDs0SnmEX5rJ524e70+BpXM6ysjDKcWmpvq61aMURBcmdTExpS8OV/wBjc4Lj0MGTfok7uMkQF/QuPC8ANGlx48K86GCA+6I2AegEFAvfZrBMUvpxWasrUs0ZcpJex5UF88skipURhojDwOHLPzU8fT4mVeM+lHbQtbMRcOFpyobt5CoZigincGfL0qaqr4qrdci+NE1XBMXTYwOKx7S98A4+uEDZ70jasApdEB60xKhJWW5U4V6bVq6RdRb1DgbvZoRY8QTzld4IJDcqbjEmAAgbCp0r6xYJ9io6wVGAFPaGn5eHVxaxXLqGQM1yOvIAAEBlwAocAIbjSKXjI1DCYpQk2KeWuyLQx5lvyjSjrC8+DSz2OukYcADBEoc9nepIjuPRmtyTuU1NTbjd4JE5ulZ8DibyyuzjBm+KOoRHfv8ABbggQg0gcRpkFRHRD8pYaoF8TDGhIkulBsb2N1quK86MKHGJImxKNxhoVCKJcTKscRnNKOHt1ZrB6EvSnNb003bp5WiU2E/Nl/MuIywR0Em3NNnWTeoBcZuGrzm1Na97nWLdRuYd9DPvRpEIAPVyNj+b1ujx8L9eGFjSLjkainjvqyRho5zkYUZlOsAB7CaP2Ne70+DpwpvKsBHk0fzgxF8iYOzqOlBJgm4GJyzNmjECwX0JDjiJETpY+Q70WxZHIKl4sVyFsdC1SELzSVjzPThamGib4zzDrwsEO5bbwUcatYREQS28C9eEgMBBxhudcKjbLrhJPgZV4z6Vi+LMBjYGt1TIlXRqCIslY9q3mnkpQQ9C/eTalARDEX6aPGampqeIBThXptWvTafkcrVLBOSoTqTfiNXgNBmBAGAfBxqUkUkxTJ9LulKcpIpiCgvQowhhsACA4xQPKg+gW8j2KJrB7oMF+ByPDg8FWB4nyf1w95oUi7GWSqDseVFi9N1u8O5xwoHwYEspEe8UuAHk1GSsFQh1r3udAmi8b9P8/rdHj4X68RhQTN4l+uFlIIaig7MPSvd6fI1BpARkYHSeF6JTkEPaHXhpABWxLclTpwnwE8vZ4UjAEXonNwIILFdE8uG4OZnUeEdK5QQaTEveianZYAgzr3j9pdrEJFjA5Id+N5pfkeDHT4GVeM+lYPrhxQAI2RzpTLwcaAZJnFJyiC5+D9NwoiYUSJnQxRlPo1XSpLWgLvLHZ503s3kp2AaQlCE4Goy9XJ7i0/KaeK14CnCvTatem0/K5WmKbJaA4vzZM/fjlShOGfL+UIEkm7fEBhi6xMS70KMjCUzWKH43S3D4qqfN/XD3uhTBWwW1p/aeJKUcL0a9/wD2vf8A9r3/APaSIqNkbnnh73Qr1udeF+v8/rdHj4X68ZvTtZvwEGngIxmFe70+RpiZumuJ5OG7vpDPieAXVTAyfTz4IUEJklxpNoBoBgOZHdTsFADFaiuZ91hd6s1IKN9AJamymosxLMfO18wDqnj6fAyrxn0rA9cPhCCEaiuDWKsnNjemdhnKFM7wId9aLdY4qMMxOQSUFCMh9Kito2gPNDTCKBoBhwFOFem1a9NprP43K/q48/YFXQEd5QO8fJxRWxcp+04cIz5H9fHExMnMQ8pSGwFtN1j9oAAQFj43S3D4qqfN/XD3uhSq8CPNEnLlNoP3UVFRUVBjFYV63OvC/X+f1ujx8L9ayq2AUZtgPtyqcIznLhyoJodFCuiD5YOte70+JqXW5PLOo0POFIHKlVlXgmujLZQdpdOF5Ve3O6R14lBAIkzBoVc46YvPo61FWCCctv4OCBDESQYmV1HtXq37Xu37Xu37TnDCImJmO504SrxEmJhmOuFA+KLNEnEyrxn0r1O1fXGfCxmKUSciXpToggYq4FAbgR0D8ohubhygjxFK8WNdU/ScMqQJbFNWUwQnE4Ksq9Nq16bTWfxulxiCy7TfyCpnxzCFE4cygcc1Zy5NHL4NFEv0Us9GgQWCZo/0pJyKG4WD/Nk4lBZRCZOB5t//AKqQrf0tJg52PR+V0tw+Kqnzf1w97oUhJkiMLi7iUJpM7CSU9bdfn63OvC/X+f3ujx1AwJMRrW8rynmax6DMXLltwi3GeVVYKgGGg7Hlr3enG/Tldt1W86tRnrjGe7LS41lZG648HGNgYDNXINaXYdsMTF5ZGxxU2M1q2AjlMdOIWuDpkZm89lTWIQQHldgor5IRmuFXBR91Qu9WfhAfvL8DFqeYEqcXEuzHFpXjPpQmyGUQxFzil1ktqpzLKviruUQKC0HrU1NwGFhymusacEkIjGAQTzA7NJZQcAMn6ctKPS7VzpCpIvKRtLNyWW9GMGx3y4qnCvTatem0/M5XPxUdzeRz0edRw/cZNHejHHhKDySRzil6QbrsXpSmLKPpi5W51FoAzQO1K7M1iUlcrTdjKcseU60sYsn2fx3oicYpjskjnFSaSJsLsXoi6QK3IN15xQWpz8r6PAbUpi2RaBsYd3P5XS3D4qqfN/XD3uhRDWT/AE3MaXRKROaN9TLtQ2CE5LRnB2edAFzNadyKlm1o+DWG2YcG4GXrFM295gdQWjVtrRcwivW514X6/wA5IyINVK39Pf09/T39NmGaqPC0Wk+4LdwDzSInCPPGRsQcLcGFSO7at3T39Pf093TTjcH/AGazWtYnoEdmprlvPuXfhOIWUYMq4nHwrf09/TcOggZhJE5wsdKyoUTWuKy3YFXruu4EiEcnxMmwAoSkhLYm51rd09/TRHjbcabBOY6/CF2dwiBghrf09/TgQsZN4VIWdFRdAjzV62VgPfPVjajoAQAQBwhYCWyVNu0jxsYD1jnUmJ2TxQjoux2FfFXXpEQO838DaoTFWMVCXghjXOpvvbYlpcUwaSp5iliC0uVl8YAJJasuMaEnEgvYGpMWXphTKcx4CgCJCOdTjRLeORj022rkESO0HxTgAhi5fdFrMIQ+hbzU/jEQXkMhy6zxR2jEF1cjy7Uov7BniFKRIakd6Z/Oi8JbzTwcUdOJyNjjGhJxIL2BqTFl6YUynMeKSVZdo/IowywayEG6EoXFME4oMSqCt3TIGFBohRVxvQYlqOI8qQh8DgdBfsU4JkzcftRABczhzoVlW5KnNgPNR2BR3JfwgrKp+tVATNgagEddEgZn/wAE71O9Tv8AwTvU71eo+c71O/8A4Z3qd+PX5HHL5tRxj+C/yaj/AMb/AOKNv7isLFQvnkdWjsy6ie165A3PNXxWBGYw5c/7bKG42JYG9w60jJqF3xuy4E21b4UdICEj3wdKPSsK3dy7s96aWUThNpu0zJyvxmojjbj0+L8S9Pxmf6nMUzI5zL8pzjZRkVPKa5fB75egx2PFSKAcg85WoPPEAPs8UfUxYUNon7hwJLIgvGqyexRwBuGDfXtU/Mx5AGfymNim/ZhmRECIyblPSZCEBgxWg7yE1JTHm0M8BJIFJBNqHpkiugZUxgZ4l0W5LSJZTQ5S1mbe9P3uxJPe3ihaikA+8oAthlRMhS28arJ6DS4Yn2im/ahvWKkHR/KZkstKNetys7cFAwS0dKzF281fqGJHlIoSkXdc2SA7VHkkJccOZZv/AFBJjAqC5p0fsKWYYFQnU0dyzvWdgi+SX8U3OsQl5jE68Darn1Megl5xRJwsac9l0JJ1nnQdjgQBsFPcKwCfUfzBqBNYDcMHQw/9oxbuGrI6sHWhThisLew0nDYKNL0HmNXeh6HAicxo5XGAAvI6Xw49GsBWde70rw304Y2cAHiHADVh5eE+CiyTvuJowSFbNsO72mmYjdXFsNJh5Byo8UZCd1xXdrFSIMeakPIckd4nyONnSoVQxGITMbkPWrQGc4EOt2U2oOYUAQBTJVlWOWlSnhkSVaq3ev8AUYygIPaBc6VLAsID+ny1MpmzB1Sycy29QUmzWY+TRzpcHXZsTFBxCnQRVz3r/q/7r/q/7qTb6ckQGXKiI3FlLruKEwXB2Ufbj6fQ49GsBWde70rxX04Y+n1oEUFlFRZyUbTFu2IB4e/FNSWxyQj4U60+UXCcBse9u1BhdASBzbwwjjRFWF4M9X+0kgICJ2SHVKNC0okTUf6mgARsjnQPRYAhADlMVb7GnzmsZ7DTKFHPUr/u/wCq/wCj/qv+r/qlQA47fpJSiN+jZE+3H1+hx6VGFYV7rSvFfThj7PXgOWOebI+1TRBjSY4zlBZoiVP5L0pmiHZqvygGRAZE3KR66eAGPFTPhCFQuwRfZL61M801MCSGyMxtv/T1CQWDAzqTnrllGFbx080TdcW9sTEefB+QJBv6D9wM6bhcYwKx9DnTGZwiWCw6Q9KHJmSusU5DjOs60YEhIjI0AqgGK0u3wgpdEkO9G7BdnIs+QU1olkupheSo86DhMhINkoyWMbmwMV2KXm9FzMdx0y4dF/dfUgfY0E0LZxZjojTbGoUealBuOgmgx6vavDfThj7PXgs8nLcrh3w61HpqNGVQKdx/+UHCZCQbJScxSpAFaHbWw7agLfOXagYyKOARYXKATvNM26IHkAE9K5UbUkm7EAH3oUQVswMAdvD+oKrGCxzgtDPw70ihTgecoeFrXxnCcfiiglz1YgWeqU1KE3DH0GRWVNONEv6iXXc5U8lrZiW8A8lMclroI5inxV9AxaXdb8kBzoAILFJpQRKchrv90lYMyw9LUdtdIbml7HdpaAhJjC69eRNThLNO8/KByCKT/qMHK9AUxQ+GB7lS8QhIzpI96M4L3M0BGSeu9HpOoSbqYwMcSyL8hohMWFKLsOZxbhUxDltd/ulvF38QSPir2GlvDPM8FXQckvak4t2OVNkRhSUiqMj8gYHrFDQ7YB+lJ+7a3GwLPJSgalXugf8AP6gRxj4Ns6KaeWALG4zOQ1ouxzYAQ3TD0TlQ0jLRHWzzSTLpE9SFOtN4k3T7eRoU5MjsRLN6svWgioP4YqPg45cMv61lShyZZXd2E9ZpWGcih3p72ggHzUtFulxarivP+3PP/wDjK//Z" name="Picture 1" align="left" hspace="12" width="174" height="42" border="0"></p>
                </td>
                <td width="226" bgcolor="#ffffff" style="border-top: 1px solid #1f497d; border-bottom: none; border-left: none; border-right: none; padding: 0cm">
                    <p lang="es-MX" class="western" align="left"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#1f3864"><font size="2" style="font-size: 10pt"><b>Nombre
                    de Documento:</b></font></font></font></font></p>
                </td>
                <td width="225" bgcolor="#ffffff" style="border-top: 1px solid #1f497d; border-bottom: none; border-left: none; border-right: 1px solid #1f497d; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0cm; padding-right: 0.12cm">
                    <p lang="es-MX" class="western" align="left"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#1f3864"><font size="2" style="font-size: 10pt"><b>Emisi&oacute;n</b></font></font></font></font></p>
                </td>
            </tr>
            <tr>
                <td width="225" height="7" valign="top" bgcolor="#ffffff" style="border-top: none; border-bottom: none; border-left: 1px solid #1f497d; border-right: none; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0.13cm; padding-right: 0cm">
                    <p lang="es-MX" class="western" align="left"><font color="#1f3864">&nbsp;</font></p>
                </td>
                <td width="226" bgcolor="#ffffff" style="border: none; padding: 0cm">
                    <p lang="es-MX" class="western" align="left"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#1f3864"><font size="2" style="font-size: 10pt">Script
                    Comercial de Venta</font></font></font></font></p>
                </td>
                <td width="225" bgcolor="#ffffff" style="border-top: none; border-bottom: none; border-left: none; border-right: 1px solid #1f497d; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0cm; padding-right: 0.12cm">
                    <p lang="es-MX" class="western" align="center"><br>
                    </p>
                </td>
            </tr>
            <tr>
                <td width="225" height="7" valign="top" bgcolor="#ffffff" style="border-top: none; border-bottom: none; border-left: 1px solid #1f497d; border-right: none; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0.13cm; padding-right: 0cm">
                    <p lang="es-MX" class="western" align="left"><font color="#1f3864">&nbsp;</font></p>
                </td>
                <td width="226" bgcolor="#ffffff" style="border: none; padding: 0cm">
                    <p lang="es-MX" class="western" align="left"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#1f3864"><font size="2" style="font-size: 10pt"><b>Producto:</b></font></font></font></font></p>
                </td>
                <td width="225" bgcolor="#ffffff" style="border-top: none; border-bottom: none; border-left: none; border-right: 1px solid #1f497d; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0cm; padding-right: 0.12cm">
                    <p lang="es-MX" class="western" align="left"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#1f3864"><font size="2" style="font-size: 10pt"><b>&Uacute;ltima
                    Actualizaci&oacute;n</b></font></font></font></font></p>
                </td>
            </tr>
            <tr>
                <td width="225" height="7" valign="top" bgcolor="#ffffff" style="border-top: none; border-bottom: none; border-left: 1px solid #1f497d; border-right: none; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0.13cm; padding-right: 0cm">
                    <p lang="es-MX" class="western" align="left"><font color="#1f3864">&nbsp;</font></p>
                </td>
                <td width="226" bgcolor="#ffffff" style="border: none; padding: 0cm">
                    <p lang="es-MX" class="western" align="left"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#1f3864"><font size="2" style="font-size: 10pt"><span lang="en-US">Script
                    Base Outbound Sanas Practicas TS</span></font></font></font></font></p>
                </td>
                <td width="225" bgcolor="#ffffff" style="border-top: none; border-bottom: none; border-left: none; border-right: 1px solid #1f497d; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0cm; padding-right: 0.12cm">
                    <p class="western" align="center"><br>
                    </p>
                </td>
            </tr>
            <tr>
                <td width="225" height="7" bgcolor="#ffffff" style="border-top: none; border-bottom: none; border-left: 1px solid #1f497d; border-right: none; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0.13cm; padding-right: 0cm">
                    <p lang="es-MX" class="western" align="left"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#1f3864"><font size="2" style="font-size: 10pt"><b>Canal
                    de Venta:</b></font></font></font></font></p>
                </td>
                <td width="226" bgcolor="#ffffff" style="border: none; padding: 0cm">
                    <p lang="es-MX" class="western" align="left"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#1f3864"><font size="2" style="font-size: 10pt"><b>Proveedor:</b></font></font></font></font></p>
                </td>
                <td width="225" bgcolor="#ffffff" style="border-top: none; border-bottom: none; border-left: none; border-right: 1px solid #1f497d; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0cm; padding-right: 0.12cm">
                    <p lang="es-MX" class="western" align="left"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#1f3864"><font size="2" style="font-size: 10pt"><b>P&aacute;gina:</b></font></font></font></font></p>
                </td>
            </tr>
            <tr>
                <td width="225" height="7" bgcolor="#ffffff" style="border-top: none; border-bottom: 1px solid #1f497d; border-left: 1px solid #1f497d; border-right: none; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0.13cm; padding-right: 0cm">
                    <p lang="es-MX" class="western" align="left"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#1f3864"><font size="2" style="font-size: 10pt">Telemarketing</font></font></font></font></p>
                </td>
                <td width="226" bgcolor="#ffffff" style="border-top: none; border-bottom: 1px solid #1f497d; border-left: none; border-right: none; padding: 0cm">
                    <p lang="es-MX" class="western" align="left"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#1f3864"><font size="2" style="font-size: 10pt">BBDD
                    Propias</font></font></font></font></p>
                </td>
                <td width="225" bgcolor="#ffffff" style="border-top: none; border-bottom: 1px solid #1f497d; border-left: none; border-right: 1px solid #1f497d; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0cm; padding-right: 0.12cm">
                    <p lang="es-MX" class="western" align="center"><font color="#1f3864">&nbsp;<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="2" style="font-size: 10pt">~
                    <sdfield type=PAGE subtype=RANDOM format=PAGE>6</sdfield> ~</font></font></font></font></p>
                </td>
            </tr>
        </table>
    </center>
    <p lang="es-MX" align="left"><br>
    </p>
    <p lang="es-MX" align="left"><br>
    </p>
</div>
<p lang="es-MX" class="western" align="justify" style="line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#1f3864"><font size="4" style="font-size: 14pt"><b>Script
de Venta – Base Outbound BBDD Propias Sanas Pr&aacute;cticas</b></font></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="4" style="font-size: 14pt"><b>-----Presentaci&oacute;n-----</b></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#7030a0"><font size="3" style="font-size: 12pt"><i>Identificarse
como Seguros BBVA Bancomer y asegurar la identificaci&oacute;n del
prospecto de venta. </i></font></font></font></font>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-left: 1.61cm; text-indent: -1.61cm; margin-bottom: 0.21cm">
<br><br>
</p>
<p lang="es-ES" class="western" align="justify"><font face="Calibri, serif"><font size="3" style="font-size: 12pt">Buenos
</font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><u>d&iacute;as
/ tardes / noches</u></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt">.
</font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>Mi
nombre es</b></font></font><font color="#1f497d"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>
</b></font></font></font><font color="#4472c4"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>{nombre
y apellidos}</b></font></font></font><font color="#0000ff"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>
</b></font></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt">de</font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>
Seguros BBVA Bancomer.</b></font></font></p>
<p lang="es-ES" class="western" align="justify"><font face="Calibri, serif"><font size="3" style="font-size: 12pt">&iquest;Ser&iacute;a
tan amable en comunicarme por favor con</font></font><font color="#1f497d"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>
</b></font></font></font><font color="#4472c4"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>{nombre
completo del prospecto}</b></font></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt">?</font></font></p>
<ol type="A">
    <li><p lang="es-ES" class="western" align="justify"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>Si</b></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt">
    se encuentra: </font></font><font color="#7030a0"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><i>Pedir
    por el prospecto en caso de que no sea el que contest&oacute;.</i></font></font></font></p>
    <li><p lang="es-ES" class="western" align="justify"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>No
    </b></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt">se
    encuentra: </font></font><font color="#7030a0"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><i>Preguntar
    a qu&eacute; hora le pueden volver a llamar y reprogramar.</i></font></font></font></p>
</ol>
<p lang="es-ES" class="western" align="justify" style="margin-bottom: 0.21cm">
<br><br>
</p>
<p lang="es-ES" class="western" align="justify" style="margin-bottom: 0.21cm">
<font face="Calibri, serif"><font size="4" style="font-size: 14pt"><b>-----Introducci&oacute;n-----</b></font></font></p>
<p lang="es-ES" class="western" align="justify" style="margin-left: 2.49cm; text-indent: -2.49cm">
<font color="#7030a0"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><i>Aclarar
y dar seguridad al cliente sobre el motivo de la llamada.</i></font></font></font></p>
<p lang="es-ES" class="western" align="justify" style="margin-left: 2.49cm; text-indent: -2.49cm">
<br>
</p>
<p lang="es-ES" class="western" align="justify" style="text-indent: 0.01cm">
<font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX">&iquest;Tengo
el gusto con el </span></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><u>Sr.
/ Sra. / Srta.:</u></span></font></font><font color="#1f497d"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>
</b></font></font></font><font color="#4472c4"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>{nombre
y apellidos del prospecto},</b></font></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX">
titular de la tarjeta con terminaci&oacute;n </span></font></font><font color="#4472c4"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>{XXXX}</b></font></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX">?</span></font></font></p>
<p lang="es-ES" class="western" align="justify" style="margin-left: 2.49cm; text-indent: -2.49cm">
<font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-MX"><i>{Se
debe asegurar la confirmaci&oacute;n de la terminaci&oacute;n de la
tarjeta/cuenta con el cliente}</i></span></font></font></p>
<p lang="es-ES" class="western" align="justify" style="margin-left: 2.49cm; text-indent: -2.49cm; margin-bottom: 0.21cm">
<br><br>
</p>
<p lang="es-ES" class="western" align="justify" style="text-indent: 0.01cm; margin-bottom: 0.21cm">
<font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><u>Sr.
/ Sra. / Srta.:</u></span></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX">
</span></font></font><font color="#4472c4"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>{apellido
del prospecto},</b></font></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX">
mi nombre es </span></font></font><font color="#4472c4"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>{nombre
y apellidos}</b></font></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX">
le hablo de </span></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><b>Seguros
BBVA Bancomer</b></span></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX">,
y aprovecho esta llamada para comentarle los beneficios de nuestro
plan de protecci&oacute;n </span></font></font><font color="#4472c4"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>{nombre
del producto}.</b></font></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX">
</span></font></font>
</p>
<p lang="es-MX" class="western" align="justify" style="line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt">Me
tomar&aacute; un minuto explicarle </font><font size="3" style="font-size: 12pt"><b>como
proteger </b></font><font size="3" style="font-size: 12pt"><i>su
patrimonio en caso de robo ya que cada vez es m&aacute;s com&uacute;n este tipo
de il&iacute;citos. </i></font><font size="3" style="font-size: 12pt"><b>&iquest;De
acuerdo?</b></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="line-height: 100%">
<br>
</p>
<ol type="A">
    <li><p lang="es-ES" class="western" align="justify" style="margin-bottom: 0.21cm">
    <font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>Si</b></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt">
    est&aacute; de acuerdo: </font></font><font color="#7030a0"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><i>Continuamos
    con la oferta (proceso de venta) y se procede a indicarle los
    t&eacute;rminos y condiciones para su contrataci&oacute;n, as&iacute; como los
    requisitos y modalidades que apliquen, as&iacute; como, el medio a trav&eacute;s
    del cual podr&aacute; consultarlos.</i></font></font></font></p>
    <li><p lang="es-ES" class="western" align="justify" style="margin-bottom: 0.21cm">
    <font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>No
    </b></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt">est&aacute;
    de acuerdo: Entiendo que en este momento no pueda recibir la oferta,
    le marco en otra ocasi&oacute;n, &iquest;Le parece?</font></font><font color="#4472c4"><font face="Calibri, serif"><font size="3" style="font-size: 12pt">
    </font></font></font><font color="#4472c4"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>{Esperar
    respuesta}</b></font></font></font><font color="#4472c4"><font face="Calibri, serif"><font size="3" style="font-size: 12pt">
    </font></font></font>
    </p>
</ol>
<ol>
    <li><p lang="es-ES" class="western" align="justify" style="margin-bottom: 0.21cm">
    <font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><b>Respuesta
    Negativa</b></span></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX">:
    </span></font></font><font color="#7030a0"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><i>Se
    tipifica como </i></span></font></font></font><font color="#7030a0"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><i><b>“BLOQUEAR
    SANAS PRACTICAS”</b></i></span></font></font></font><font color="#7030a0"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><i>,
    en consecuencia, Inteligencia Comercial lo congelar&aacute; los siguientes
    </i></span></font></font></font><font color="#7030a0"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><i><b>doce
    meses</b></i></span></font></font></font><font color="#7030a0"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><i>
    posteriores a la comunicaci&oacute;n telef&oacute;nica, por lo que el </i></span></font></font></font><font color="#7030a0"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><i><b>centro
    bloquear&aacute; la referencia y todos sus tel&eacute;fonos</b></i></span></font></font></font><font color="#7030a0"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><i>
    para la </i></span></font></font></font><font color="#7030a0"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><i><b>campa&ntilde;a
    en curso</b></i></span></font></font></font><font color="#7030a0"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><i>.</i></span></font></font></font><font color="#4472c4"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><i>
     </i></span></font></font></font>
    </p>
    <li><p lang="es-ES" class="western" align="justify" style="margin-bottom: 0.21cm">
    <font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><b>Respuesta
    Afirmativa:</b></span></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX">
    </span></font></font><font color="#7030a0"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><i>Se
    tipifica como </i></span></font></font></font><font color="#7030a0"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><i><b>“Re
    marcaje General”</b></i></span></font></font></font><font color="#7030a0"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><i>.</i></span></font></font></font><font color="#7030a0"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX">
    </span></font></font></font>
    </p>
</ol>
<p lang="es-MX" class="western" align="justify" style="line-height: 100%">
<br>
</p>
<p lang="es-MX" class="western" align="justify" style="line-height: 115%">
<br>
</p>
<p lang="es-MX" class="western" align="justify" style="line-height: 115%">
<br>
</p>
<p lang="es-ES" class="western" align="justify" style="margin-bottom: 0.21cm">
<font face="Calibri, serif"><font size="4" style="font-size: 14pt"><b>-----Proceso
de Venta-----</b></font></font></p>
<p lang="es-MX" class="western" align="justify" style="line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt"><span lang="es-ES">Le
menciono que esta llamada puede hacer la diferencia  poniendo a su
disposici&oacute;n el</span></font><font face="Arial, serif"><font size="3" style="font-size: 12pt">
</font></font><font face="Arial, serif"><font size="3" style="font-size: 12pt"><b>Plan
Transacci&oacute;n Segura Bancomer</b></font></font><font face="Arial, serif"><font size="3" style="font-size: 12pt">
</font></font><font size="3" style="font-size: 12pt"><span lang="es-ES">para
que usted no forme parte del porcentaje de clientes que se ven
afectados por la delincuencia que est&aacute; abarcando a nuestro pa&iacute;s,
por ejemplo: si, desafortunadamente, al retirar del cajero autom&aacute;tico
sufriera un asalto, le estar&iacute;amos  respald&aacute;ndolo hasta</span></font><font face="Arial, serif"><font size="3" style="font-size: 12pt">
</font></font><font face="Arial, serif"><font size="3" style="font-size: 12pt"><b>$10,000
pesos por a&ntilde;o,</b></font></font><font face="Arial, serif"><font size="3" style="font-size: 12pt">
</font></font><font size="3" style="font-size: 12pt"><span lang="es-ES">dentro
de las 24 horas posteriores al retiro.</span></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="line-height: 100%">
<br>
</p>
<p lang="es-ES" class="western" align="justify"><font face="Arial, serif"><font size="3" style="font-size: 12pt"><u>Sr.
/ Sra. / Srta.</u></font></font><font face="Arial, serif"><font size="3" style="font-size: 12pt">:
</font></font><font color="#1f497d"><font face="Arial, serif"><font size="3" style="font-size: 12pt"><b>{apellido
del prospecto},</b></font></font></font></p>
<p lang="es-ES" class="western" align="justify"><br>
</p>
<p lang="es-MX" class="western" align="justify" style="line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font face="Arial, serif"><font size="3" style="font-size: 12pt"><b>(PREGUNTA).</b></font></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="line-height: 100%">
<br>
</p>
<p lang="es-MX" class="western" align="justify" style="line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt">1.    &iquest;Le
gustar&iacute;a que le devolvieran su dinero?</font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt">2.    &iquest;Desear&iacute;a
proteger su dinero despu&eacute;s de ser retirado del cajero?</font></font></font></p>
<p lang="es-ES" class="western" align="justify"><br>
</p>
<p lang="es-ES" class="western" align="justify"><font face="Arial, serif"><font size="3" style="font-size: 12pt"><b>SI
</b></font></font><font color="#1f497d"><font face="Arial, serif"><font size="3" style="font-size: 12pt"><b>{Continuar
con el script}</b></font></font></font></p>
<p lang="es-ES" class="western" align="justify"><font face="Arial, serif"><font size="3" style="font-size: 12pt"><b>NO
</b></font></font><font color="#1f497d"><font face="Arial, serif"><font size="3" style="font-size: 12pt"><b>{Sondear
el motivo / usar escenarios reales}</b></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.35cm; line-height: 115%">
<br><br>
</p>
<p lang="es-ES" class="western" align="justify"><font face="Arial, serif"><font size="3" style="font-size: 12pt"><b>PERFECTO
</b></font></font><font face="Arial, serif"><font size="3" style="font-size: 12pt"><u>Sr.
/ Sra. / Srta.</u></font></font><font face="Arial, serif"><font size="3" style="font-size: 12pt">:
</font></font><font color="#1f497d"><font face="Arial, serif"><font size="3" style="font-size: 12pt"><b>{apellido
del prospecto}</b></font></font></font></p>
<p lang="es-ES" class="western" align="justify"><br>
</p>
<p lang="es-MX" class="western" align="justify" style="line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt">Otra
ventaja de contar con esta Protecci&oacute;n es que si una persona se
encuentra o le roba su tarjeta y realiza compras, </font><font face="Arial, serif"><font size="3" style="font-size: 12pt"><b>Transacci&oacute;n
Segura Bancomer</b></font></font><font face="Arial, serif"><font size="3" style="font-size: 12pt">
</font></font><font size="3" style="font-size: 12pt">le cubrir&aacute; los
consumos realizados</font><font face="Arial, serif"><font size="3" style="font-size: 12pt">
</font></font><font face="Arial, serif"><font size="3" style="font-size: 12pt"><b>hasta
$10,000 pesos</b></font></font><font face="Arial, serif"><font size="3" style="font-size: 12pt">
</font></font><font size="3" style="font-size: 12pt">cubri&eacute;ndole
hasta 2 eventos por a&ntilde;o, 72 horas previas al reporte.</font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="line-height: 100%">
<br>
</p>
<p lang="es-MX" class="western" align="justify" style="line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt">Imagine
si su tarjeta de n&oacute;mina se le extrav&iacute;a y alguna otra persona al
encontrarla  llegara a realizar alguna compra.</font></font></font></p>
<p lang="es-ES" class="western" align="justify" style="margin-left: 0.01cm; text-indent: -0.01cm">
<br>
</p>
<p lang="es-MX" class="western" align="justify" style="line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font face="Arial, serif"><font size="3" style="font-size: 12pt"><b>(PREGUNTA).</b></font></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font face="Arial, serif"><font size="3" style="font-size: 12pt">1.  </font></font><font size="3" style="font-size: 12pt">&iquest;Qu&eacute;
problema le ocasionar&iacute;a esta situaci&oacute;n?</font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt">2.    &iquest;C&oacute;mo
podr&iacute;a solventarla?</font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="line-height: 100%">
<br>
</p>
<p lang="es-ES" class="western" align="justify"><font color="#1f497d"><font face="Arial, serif"><font size="3" style="font-size: 12pt"><b>{Usar
escenarios reales}</b></font></font></font></p>
<p lang="es-ES" class="western" align="justify" style="margin-left: 2.49cm; text-indent: -2.49cm">
<br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.35cm; line-height: 115%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt">Pues
bien Sr. / Sra. / Srta.:</font><font face="Arial, serif"><font size="3" style="font-size: 12pt">
</font></font><font color="#1f497d"><font face="Arial, serif"><font size="3" style="font-size: 12pt"><b>{apellido
del prospecto}</b></font></font></font><font face="Arial, serif"><font size="3" style="font-size: 12pt">
</font></font><font size="3" style="font-size: 12pt">no solo eso,
tambi&eacute;n le estaremos protegiendo con las Transferencias Electr&oacute;nicas
en Internet no autorizadas, con dos eventos por a&ntilde;o y un respaldo de
hasta 72 hrs previas al reporte. Protegi&eacute;ndolo hasta</font><font face="Arial, serif"><font size="3" style="font-size: 12pt">
</font></font><font face="Arial, serif"><font size="3" style="font-size: 12pt"><b>con
$10,000 pesos por evento</b></font></font><font face="Arial, serif"><font size="3" style="font-size: 12pt">,
</font></font><font size="3" style="font-size: 12pt">tan solo por una
inversi&oacute;n en su seguridad y tranquilidad</font><font face="Arial, serif"><font size="3" style="font-size: 12pt">
</font></font><font face="Arial, serif"><font size="3" style="font-size: 12pt"><b>de
$119 pesos mensuales</b></font></font></font></font></p>
<p lang="es-ES" class="western" align="justify"><br>
</p>
<p lang="es-ES" class="western" align="justify"><font face="Arial, serif"><font size="3" style="font-size: 12pt"><b>EXCELENTE
</b></font></font><font face="Arial, serif"><font size="3" style="font-size: 12pt"><u>Sr.
/ Sra. / Srta.</u></font></font><font face="Arial, serif"><font size="3" style="font-size: 12pt">:
</font></font><font color="#1f497d"><font face="Arial, serif"><font size="3" style="font-size: 12pt"><b>{apellido
del prospecto}</b></font></font></font></p>
<p lang="es-ES" class="western" align="justify"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX">Todos
estos beneficios se reflejan en una protecci&oacute;n de hasta</span></font></font><font face="Arial, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX">
</span></font></font><font face="Arial, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><b>$70,000
pesos al a&ntilde;o.</b></span></font></font></p>
<p lang="es-ES" class="western" align="justify" style="line-height: 115%">
<br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#7030a0"><font size="4" style="font-size: 14pt"><b>pre-cierre:</b></font></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt">Sr.
/ Sra. / Srta.: </font><font color="#4472c4"><font size="3" style="font-size: 12pt"><b>{apellido
del prospecto}</b></font></font><font size="3" style="font-size: 12pt">,
con su aprobaci&oacute;n en este momento usted quedar&aacute; Protegido, </font><font size="3" style="font-size: 12pt"><b>&iquest;Est&aacute;
usted de acuerdo?</b></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#7030a0"><font size="3" style="font-size: 12pt"><i>{Dependiendo
de la respuesta del cliente, en caso de tener que manejar objeciones,
reforzar con beneficios, en caso de ser afirmativa proceder a la
confirmaci&oacute;n de la compra}</i></font></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#7030a0"><font size="3" style="font-size: 12pt"><i>{De
acuerdo al producto,</i></font></font><font color="#7030a0"><i>
i</i></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><i>ntegrar
ejemplos para el manejo de objeciones, costos hospitalarios, &iacute;ndices
de robo, delincuencia, accidentes, hospitalizaci&oacute;n, etc.}</i></font></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="4" style="font-size: 14pt"><b>----Confirmaci&oacute;n
de la Compra---- </b></font></font></font>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#4472c4"><font size="3" style="font-size: 12pt"><i>Asegurar
la conciencia y aceptaci&oacute;n del cargo por parte del cliente.</i></font></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt"><u>Sr.
/ Sra. / Srta.</u></font><font size="3" style="font-size: 12pt">:</font><font color="#1f497d"><font size="3" style="font-size: 12pt"><b>
</b></font></font><font color="#4472c4"><font size="3" style="font-size: 12pt"><b>{apellido
del prospecto},</b></font></font><font size="3" style="font-size: 12pt">
en este momento est&aacute; </font><font size="3" style="font-size: 12pt"><b>CONTRATANDO</b></font><font size="3" style="font-size: 12pt">
el Plan de Protecci&oacute;n </font><font color="#1f497d"><font size="3" style="font-size: 12pt"><b>{</b></font></font><font color="#4472c4"><font size="3" style="font-size: 12pt"><b>Transacci&oacute;n
Segura Bancomer}</b></font></font><font size="3" style="font-size: 12pt">
con cargo a su </font><font size="3" style="font-size: 12pt"><u>Tarjeta/Cuenta</u></font><font size="3" style="font-size: 12pt">,
por una </font><font size="3" style="font-size: 12pt"><b>PRIMA
MENSUAL</b></font><font size="3" style="font-size: 12pt"> de </font><font color="#4472c4"><font size="3" style="font-size: 12pt"><b>$XXX.XX</b></font></font><font color="#1f497d"><font size="3" style="font-size: 12pt"><b>
</b></font></font><font size="3" style="font-size: 12pt">pesos,</font><font size="3" style="font-size: 12pt"><b>
&iquest;De acuerdo?</b></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#7030a0"><font size="3" style="font-size: 12pt"><i><b>{S&iacute;,
est&aacute; bien, muy bien, de acuerdo, ok, por supuesto, perfecto,
adelante, claro}</b></i></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt">
</font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><i>Si
no es una aceptaci&oacute;n v&aacute;lida, se deber&aacute; reformular con:</i></font></font><font size="3" style="font-size: 12pt"><b>
&iquest;Puedo tomar su respuesta como un s&iacute;?</b></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<ol type="A">
    <li><p lang="es-ES" class="western" align="justify" style="margin-bottom: 0.21cm">
    <font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>Si
    acepta:</b></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt">
    </font></font><font color="#7030a0"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><i>Asegura
    el cierre de llamada con la </i></span></font></font></font><font color="#7030a0"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><i><b>marcaci&oacute;n
    del c&oacute;digo de aceptaci&oacute;n</b></i></span></font></font></font><font color="#7030a0"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><i>.</i></span></font></font></font></p>
    <li><p lang="es-ES" class="western" align="justify" style="margin-bottom: 0.21cm">
    <font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>No
    acepta:</b></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt">
    </font></font><font color="#7030a0"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><i>Sondeo
    del motivo, realiza vencimiento de objeci&oacute;n mediante labor de venta
    con escenarios reales y utiliza alguno de estos cierres:</i></span></font></font></font></p>
</ol>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<ul>
    <li><p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; line-height: 100%">
    <font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt">&iquest;Est&aacute;
    de acuerdo en la </font><font size="3" style="font-size: 12pt"><b>contrataci&oacute;n</b></font><font size="3" style="font-size: 12pt">
    del plan </font><font color="#4472c4"><font size="3" style="font-size: 12pt"><b>{Transacci&oacute;n
    Segura}</b></font></font><font size="3" style="font-size: 12pt"> con
    cargo a su tarjeta?</font></font></font></p>
    <li><p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; line-height: 100%">
    <font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt">&iquest;Podemos
    iniciar con la </font><font size="3" style="font-size: 12pt"><b>contrataci&oacute;n</b></font><font size="3" style="font-size: 12pt">
    del plan </font><font color="#4472c4"><font size="3" style="font-size: 12pt"><b>{Transacci&oacute;n
    Segura}</b></font></font><font size="3" style="font-size: 12pt"> con
    cargo a su tarjeta?</font></font></font></p>
    <li><p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; line-height: 100%">
    <font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt">&iquest;Desea
    que iniciemos con la </font><font size="3" style="font-size: 12pt"><b>contrataci&oacute;n</b></font><font size="3" style="font-size: 12pt">
    del plan </font><font color="#4472c4"><font size="3" style="font-size: 12pt"><b>{Transacci&oacute;n
    Segura}</b></font></font><font size="3" style="font-size: 12pt"> con
    cargo a su tarjeta?</font></font></font></p>
    <li><p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; line-height: 100%">
    <font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt">&iquest;Autoriza
    que iniciemos con la </font><font size="3" style="font-size: 12pt"><b>contrataci&oacute;n</b></font><font size="3" style="font-size: 12pt">
    del plan </font><font color="#4472c4"><font size="3" style="font-size: 12pt"><b>{Transacci&oacute;n
    Segura}</b></font></font><font size="3" style="font-size: 12pt"> con
    cargo a su tarjeta?</font></font></font></p>
</ul>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="4" style="font-size: 14pt"><b>-----Marcaci&oacute;n
de C&oacute;digo de Aceptaci&oacute;n-----</b></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#4472c4"><font size="3" style="font-size: 12pt"><i>Cumplimiento
a normativa asegurando la confirmaci&oacute;n de la compra.</i></font></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt"><u>Sr.
/ Sra. / Srita:</u></font><font size="3" style="font-size: 12pt">
</font><font color="#4472c4"><font size="3" style="font-size: 12pt"><b>{apellido
del prospecto}</b></font></font><font size="3" style="font-size: 12pt">,
con la finalidad de </font><font size="3" style="font-size: 12pt"><b>confirmar
su respuesta positiva</b></font><font size="3" style="font-size: 12pt">,
por favor necesitamos que cuando yo le indique, teclee su </font><font size="3" style="font-size: 12pt"><b>clave
de confirmaci&oacute;n de venta</b></font><font size="3" style="font-size: 12pt">
en el teclado num&eacute;rico de su aparato telef&oacute;nico, la cual es: </font><font color="#1f497d"><font size="3" style="font-size: 12pt"><b>{</b></font></font><font color="#4472c4"><font size="3" style="font-size: 12pt"><b>Se
proceder&aacute; a generar el folio de 4 d&iacute;gitos y se indicara al
cliente},</b></font></font><font color="#1f497d"><font size="3" style="font-size: 12pt"><b>
</b></font></font><font size="3" style="font-size: 12pt">por favor
h&aacute;galo ahora.</font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#7030a0"><font size="3" style="font-size: 12pt"><i>{Esperar
a que el cliente digite el folio </i></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><i><b>identificando
los sonidos</b></i></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><i>
de cada n&uacute;mero de marcaci&oacute;n.}</i></font></font></font></font></p>
<p lang="es-ES" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<ol type="A">
    <li><p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
    <font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt"><b>Si
    digita teclas (folio):</b></font><font size="3" style="font-size: 12pt"><b>
    </b></font><font size="3" style="font-size: 12pt"><u>Sr. / Sra. /
    Srita</u></font><font size="3" style="font-size: 12pt">: </font><font color="#4472c4"><font size="3" style="font-size: 12pt"><b>{apellido
    del prospecto}</b></font></font><font color="#1f497d"><font size="3" style="font-size: 12pt"><b>
    </b></font></font><font size="3" style="font-size: 12pt">gracias por
    su confirmaci&oacute;n, en un momento m&aacute;s le estaremos enviando un correo
    electr&oacute;nico o </font><font size="3" style="font-size: 12pt"><span lang="es-ES">mensaje
    de texto</span></font><font size="3" style="font-size: 12pt">, con
    las clausulas, exclusiones y caracter&iacute;sticas de su producto.
    </font><font color="#7030a0"><font size="3" style="font-size: 12pt"><i>Continuamos
    las frases obligatorias.</i></font></font></font></font></p>
    <li><p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
    <font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt"><b>No
    digita teclas (folio): </b></font><font size="3" style="font-size: 12pt"><u>Sr.
    / Sra. / Srita</u></font><font size="3" style="font-size: 12pt">:
    </font><font color="#4472c4"><font size="3" style="font-size: 12pt"><b>{apellido
    del prospecto}</b></font></font><font color="#1f497d"><font size="3" style="font-size: 12pt"><b>
    </b></font></font><font size="3" style="font-size: 12pt">es
    necesario que </font><font size="3" style="font-size: 12pt"><u>teclee/digite</u></font><font size="3" style="font-size: 12pt">
    estos n&uacute;meros para confirmar su aprobaci&oacute;n.</font><font color="#7030a0"><font size="3" style="font-size: 12pt"><i>
    En caso de que el cliente </i></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><i><b>no
    digite el folio</b></i></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><i>
    de confirmaci&oacute;n no se puede continuar con el proceso, </i></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><i><b>en
    caso de vencimiento</b></i></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><i>
    de objeciones y que el cliente </i></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><i><b>acepte
    digitar el folio</b></i></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><i>
    se cierra con la frase de la </i></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><i><b>opci&oacute;n
    A).</b></i></font></font></font></font></p>
</ol>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="4" style="font-size: 14pt"><b>-----Frases
Obligatorias-----</b></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#7030a0"><font size="3" style="font-size: 12pt"><i>Dar
cumplimiento a las frases obligatorias establecidas por las
autoridades y Seguros Bancomer.</i></font></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt"><b>Aceptaci&oacute;n
del envi&oacute; de informaci&oacute;n contractual</b></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt"><span lang="es-ES"><u>Sr.
/ Sra. / Srita:</u></span></font><font size="3" style="font-size: 12pt"><span lang="es-ES">
</span></font><font color="#4472c4"><font size="3" style="font-size: 12pt"><b>{apellido
del prospecto}, </b></font></font><font size="3" style="font-size: 12pt"><span lang="es-ES">le
</span></font><font size="3" style="font-size: 12pt">menciono que la
renovaci&oacute;n es autom&aacute;tica y anual, y transcurridas 48 hr</font><font size="3" style="font-size: 12pt"><span lang="es-ES">s.
posteriores a la confirmaci&oacute;n, le haremos llegar un correo
electr&oacute;nico o un mensaje de texto inform&aacute;ndole que su p&oacute;liza ha
quedado activada, su p&oacute;liza y documentaci&oacute;n le ser&aacute; entregada en
un lapso no mayor a 30 d&iacute;as naturales por el medio que nos indique, </span></font></font></font>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt"><span lang="es-ES">&iquest;Me
puede proporcionar un numero celular y/o cuenta de correo
electr&oacute;nico?</span></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><i>
</i></font></font></font></font>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#7030a0"><font size="3" style="font-size: 12pt"><i>{En
caso de contar con la informaci&oacute;n el ejecutivo deber&aacute; corroborarla}</i></font></font><font size="3" style="font-size: 12pt"><span lang="es-ES">
</span></font><font color="#4472c4"><font size="3" style="font-size: 12pt"><b>____________________</b></font></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#7030a0"><font size="3" style="font-size: 12pt"><i>{Deletrear
las palabras at&iacute;picas o alfanum&eacute;ricas de las que frecuentemente
est&aacute;n compuestos los correos electr&oacute;nicos}</i></font></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<ol type="A">
    <li><p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
    <font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt"><b>Proporciona
    el correo: </b></font><font size="3" style="font-size: 12pt"><u>Sr.
    / Sra. / Srita</u></font><font size="3" style="font-size: 12pt">:
    </font><font color="#4472c4"><font size="3" style="font-size: 12pt"><b>{apellido
    del prospecto}</b></font></font><font size="3" style="font-size: 12pt">,
    su informaci&oacute;n contractual, p&oacute;liza y condiciones generales le ser&aacute;
    enviada por correo electr&oacute;nico, &iquest;Est&aacute; de acuerdo? </font><font color="#4472c4"><font size="3" style="font-size: 12pt"><span lang="es-ES"><b>{Esperar
    respuesta o afirmaci&oacute;n del cliente}</b></span></font></font></font></font></p>
</ol>
<p lang="es-MX" class="western" align="justify" style="margin-left: 1.25cm; margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#7030a0"><font size="3" style="font-size: 12pt"><i><b>{S&iacute;,
est&aacute; bien, muy bien, de acuerdo, ok, por supuesto, perfecto,
adelante, claro, en caso de que el cliente desee el env&iacute;o a otro
mail el ejecutivo deber&aacute; capturarlo en el sistema</b></i></font></font></font></font></p>
<ol type="A" start="2">
    <li><p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
    <font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt"><b>No
    proporciona correo y solo celular</b></font><font size="3" style="font-size: 12pt">:
    </font><font size="3" style="font-size: 12pt"><u>Sr. / Sra. / Srita</u></font><font size="3" style="font-size: 12pt">:
    </font><font color="#4472c4"><font size="3" style="font-size: 12pt"><b>{apellido
    del prospecto}. </b></font></font><font size="3" style="font-size: 12pt">En
    ese caso, en un plazo no mayor a 30 naturales d&iacute;as le ser&aacute;
    entregada su documentaci&oacute;n contractual en el domicilio que tenemos
    registrado en nuestro sistema. &iquest;Correcto? </font><font color="#4472c4"><font size="3" style="font-size: 12pt"><span lang="es-ES"><b>{Esperar
    respuesta o afirmaci&oacute;n del cliente}</b></span></font></font></font></font></p>
    <li><p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
    <font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt"><u>Sr.
    / Sra. / Srita,</u></font><font color="#000000"><font size="3" style="font-size: 12pt"><b>
    </b></font></font><font color="#000000"><font size="3" style="font-size: 12pt">su
    informaci&oacute;n contractual y p&oacute;liza puede solicitarla en el SAC
    11020000 o Interior de la Rep&uacute;blica 55 11020000, &iquest;Est&aacute; de acuerdo
    con solicitarla por este medio?</font></font><font color="#000000"><font size="3" style="font-size: 12pt"><b>
    </b></font></font><font color="#4472c4"><font size="3" style="font-size: 12pt"><span lang="es-ES"><b>{Esperar
    respuesta o afirmaci&oacute;n del cliente}</b></span></font></font></font></font></p>
</ol>
<p lang="es-MX" class="western" align="justify" style="margin-left: 0.64cm; margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#7030a0"><font size="3" style="font-size: 12pt"><i><b>{En
caso de que el cliente desee el env&iacute;o a otro Domicilio de Entrega el
ejecutivo deber&aacute; capturarlo en el sistema}</b></i></font></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#7030a0"><font size="3" style="font-size: 12pt"><i><b>{En
cualquier caso es necesario validar el domicilio para la entrega de
Documentaci&oacute;n Contractual}</b></i></font></font></font></font></p>
<p lang="es-ES" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt">Mientras
tanto su clave de confirmaci&oacute;n ser&aacute; su identificador provisional,
</font><font size="3" style="font-size: 12pt"><b>aplican
restricciones</b></font><font size="3" style="font-size: 12pt"><span lang="es-ES"><b>
y exclusiones.</b></span></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt"><span lang="es-ES">Para
dudas o aclaraciones </span></font><font size="3" style="font-size: 12pt"><span lang="es-ES"><b>consulte
en <a href="http://www.segurosbancomer.com.mx">www.segurosbancomer.com.mx</a>
</b></span></font><font size="3" style="font-size: 12pt"><span lang="es-ES">o
</span></font><font size="3" style="font-size: 12pt"><span lang="es-ES"><b>llame
al SAC 11020000.</b></span></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt"><span lang="es-ES">Para
efectos de la </span></font><font size="3" style="font-size: 12pt"><span lang="es-ES"><b>cancelaci&oacute;n
de su p&oacute;liza</b></span></font><font size="3" style="font-size: 12pt"><span lang="es-ES">,
podr&aacute; generarlos por </span></font><font size="3" style="font-size: 12pt"><span lang="es-ES"><b>este
mismo medio</b></span></font><font size="3" style="font-size: 12pt"><span lang="es-ES">
o por los medios y el proceso que al efecto se determinan en las
condiciones generales de su producto.</span></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt"><span lang="es-ES">As&iacute;
mismo, en caso que necesite </span></font><font size="3" style="font-size: 12pt"><span lang="es-ES"><b>reportar
alg&uacute;n siniestro</b></span></font><font size="3" style="font-size: 12pt"><span lang="es-ES">
lo puede hacer al </span></font><font size="3" style="font-size: 12pt"><span lang="es-ES"><b>01
800 874 36 83 (01 800 URGENTE).</b></span></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.21cm; line-height: 100%"><a name="_GoBack"></a>
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font face="Arial, serif"><font size="2" style="font-size: 9pt">Seguros
BBVA Bancomer, S.A. de C.V., Grupo Financiero BBVA Bancomer, </font></font><font face="Arial, serif"><font size="2" style="font-size: 9pt"><b>Avenida
Paseo de la Reforma No.510, Colonia Ju&aacute;rez, Delegaci&oacute;n Cuauht&eacute;moc,
C.P. 06600, Ciudad de M&eacute;xico</b></font></font><font face="Arial, serif"><font size="2" style="font-size: 9pt">,
recaba sus datos para verificar su identidad. El Aviso de Privacidad
Integral actualizado est&aacute; en cualquiera de nuestras Oficinas y
en&nbsp;<a href="http://www.segurosbancomer.com.mx/">www.segurosbancomer.com.mx</a></font></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="4" style="font-size: 14pt"><b>-----Cierre
de Llamada-----</b></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i>Agradecer
al cliente su preferencia y confianza y mencionar las consecuencias
de omitir el pago.</i></span></font></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt">Le
reitero la importancia de contar con saldo disponible en su cuenta de
manera mensual, para el cobro de su cobertura y que usted cuente con
una protecci&oacute;n continua.</font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt">Muchas
gracias por su tiempo. Le atendi&oacute;: </font><font color="#1f497d"><font size="3" style="font-size: 12pt"><b>{nombre
y apellido}</b></font></font><font size="3" style="font-size: 12pt">.</font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt">Para
Bancomer usted es lo m&aacute;s importante y le desea un excelente d&iacute;a.</font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#0000ff"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i><b>INFORMATIVO:</b></i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i>
Las instituciones de seguros </i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i><b>deber&aacute;n
abstenerse</b></i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i>
de </i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i><b>realizar</b></i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i>
cualquier tipo de </i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i><b>comunicaci&oacute;n</b></i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i>
de car&aacute;cter </i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i><b>promocional</b></i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i>
a los </i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i><b>Usuarios</b></i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i>
que se encuentren </i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i><b>inscritos</b></i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i>
en el Registro de Usuarios que no deseen que su informaci&oacute;n sea
utilizada para fines mercadot&eacute;cnicos o publicitarios </i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i><b>(REUS)</b></i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i>,
as&iacute; como de aquellos que </i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i><b>en
sus</b></i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i>
respectivos </i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i><b>contratos
</b></i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i>hayan
</i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i><b>manifestado</b></i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i>
su </i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i><b>negativa</b></i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i>
a recibir informaci&oacute;n o propaganda diversa.</i></span></font></font></font></font></p>
</body>
</html>