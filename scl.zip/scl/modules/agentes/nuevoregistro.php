<?php
require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("agente", "Solicitud");

$id_solicitud = get_session_varname('id_solicitud');

$isPredictivo2 = get_session_varname("s_usr_marcacion");
$aviso = "";
$tipo = "Tu Base";
$error = "0";
if (isset($_REQUEST['tipo'])) {
    switch ($_REQUEST['tipo']) {
        case '1':
            $tipo = "Contacto distinto";
            break;
        case '2':
            $tipo = "Recomendado";
            break;
        case '3':
            $tipo = "Tu Base";
            break;
    }
}
if (!empty($_REQUEST['calificacion'])) {
    $referente = $_REQUEST['referente'];
    $calificacion = $_REQUEST['calificacion'];
    $u_registro = get_session_varname('id_registro');
    $datos_persona = get_session_varname('datos_persona');
    $u_user = get_session_varname('s_usr_id');
    $u_telefono = "";
    
    $error = isset($_REQUEST['error']) ? $_REQUEST['error'] : '';
    
    foreach ($datos_persona as $index => $data) {
        if ($data['CLAVELADA'] . $data['TELEFONO'] == $_REQUEST['telefono']) {
            $u_telefono = $data['U_TELEFONO'];
            break;
        }
    }
    set_califica_telefono($u_telefono, $calificacion, 0, $db);
    set_estatus_registro($u_registro, $u_user, $u_telefono, $calificacion, 1, '', 1, 0, 'O', $db);
    $aviso = "avisoPrivacidadImpulse()";
}

if ($error == 0) {
    layout_menu($db, "ShowScript_GeneralIN();");
}else{
    layout_menu($db, "avisoClienteMolesto();");
}
?>
<p class="textbold">Agentes &gt; Nuevo Registro</p>
<form method="post" action="#" name="frm1">
    <table border="0">
        <tr>
            <td colspan="2"><?= form_oblmsg() ?></td>
        </tr>
        <tr>
            <td colspan="2" class="label_aviso" bgcolor="red" style="font-size: 18px">Verifica que hayas concluido tu llamada anterior de lo contrario se va a cortar tu l�nea.</td>
        </tr>
        <tr>
            <th colspan="2" class="label_td" bgcolor="grey" style="font-size: 14px"><?= $tipo ?></th>
        </tr>
        <tr>
            <td colspan="2" class="label_td" bgcolor="grey" style="font-size: 14px">Datos del Cliente</td>
        </tr>
        <tr>
            <td colspan="2">&nbsp;</td>
        </tr>
        <tr>
            <td class="textleft"><b>* Nombre(s):&nbsp;</b></td>
            <td class="label"><input type="text" name="nombre" id="nombre" size="25"></td>
        </tr>
        <tr>
            <td class="textleft"><b>* Paterno:&nbsp;</b></td>
            <td class="label"><input type="text" name="paterno" id="paterno" size="25"></td>
        </tr>
        <tr>
            <td class="textleft"><b>&nbsp;&nbsp;Materno:&nbsp;</b></td>
            <td class="label"><input type="text" name="materno" id="materno" size="25"></td>
        </tr>
        <?php 
            if($_REQUEST['tipo'] == 1){
                ?>
                <tr>
                    <td class="textleft"><b>* Lada:&nbsp;</b></td>
                    <td class="label"><input type="text" readonly size="15" name="lada" id="lada" maxlength="3" value="<?php echo $data['CLAVELADA'] ?>"></td>
                </tr>
                <tr>
                    <td class="textleft"><b>* Telefono :&nbsp;</b></td>
                    <td class="label"><input type="text" readonly size="15" name="telefono" id="telefono" maxlength="8" value="<?php echo $data['TELEFONO'] ?>"></td>
                </tr>
                <?php
            }else{
                ?>
                <tr>
                    <td class="textleft"><b>* Lada:&nbsp;</b></td>
                    <td class="label"><input type="text" size="15" name="lada" id="lada" maxlength="3" value="<?php echo $data['CLAVELADA'] ?>"></td>
                </tr>
                <tr>
                    <td class="textleft"><b>* Telefono :&nbsp;</b></td>
                    <td class="label"><input type="text" size="15" name="telefono" id="telefono" maxlength="8" value="<?php echo $data['TELEFONO'] ?>"></td>
                </tr>
                <?php
            }
        ?>        
        <tr>
            <td colspan="2">&nbsp;</td>
        </tr>
        <tr>
            <td colspan="2">
                <!--?php if ($isPredictivo2 == 1) { ?>
                    <input type="button" value="Cancelar" title="espred" id="obRegistroPredCancelarRefe" onclick="this.disabled = true;
                            marcarpredictivo(<?php echo "'" . encripta('27') . "'"; ?>);"/>&nbsp;&nbsp;
                       < ?php } else { ? -->
                    <input type="button" value="Cancelar" onclick="this.disabled = true;
                            Atras(); "/>&nbsp;&nbsp;<!--onclick="this.disabled=true;window.location='index2.php'"-->
                       <!--?php } ?-->
                <input type="button" value="Procesar" onclick="this.disabled = true;
                        nuevo_registro(2,this)"/>&nbsp;&nbsp;
            </td>
        </tr>
    </table>
    <input type="hidden" name="tipo" value="<?php echo $_REQUEST['tipo'] ?>" />
    <input type="hidden" name="referente" value="<?php echo $_REQUEST['referente'] ?>" />
    <input type="hidden" name="calificacion" value="<?php echo $_REQUEST['calificacion'] ?>" />
</form>
<?
layout_footer();
?>
