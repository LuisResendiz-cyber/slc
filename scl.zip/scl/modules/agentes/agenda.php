<?php
# @uthor Mark 
# Agenda File 

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("agente", "Agendar Registro");

set_session_varname("url_contacto", "agenda");

$id_solicitud = get_session_varname("id_solicitud");
$id_usr = get_session_varname("s_usr_id");
$datos_cliente = get_session_varname("datos_persona");
$isPredictivo2 = get_session_varname("s_usr_marcacion");



/* var_dump($datos_cliente);
die();  */


/*
 * Obtener el u_telefono de acuerdo al registro y al tel?fono contactado
 */
$telefono = get_session_varname("s_telefono");
$id_telefono = get_id_telefono($id_solicitud, $telefono, $db); 
set_session_varname('s_u_telefono', $id_telefono);

if(isset($_SESSION['log_registro'])){
    switch (get_session_varname('log_registro')){
        case 1:
            update_evento_registro2(get_session_varname("s_usr_id"),get_session_varname("id_solicitud"),'ENTRO A SOLCITUD', $db);
            set_evento_registro(get_session_varname("s_usr_id"),get_session_varname("id_solicitud"),'AGENDA REGISTRO',$db);
            break;
        default :
            break;
    }
}

layout_menu($db, "verAgenda('cmdAgenda', '" . date('d/m/Y') . "', 'agenda',0);");
?>

<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="#">Home</a></li>
    <li class="breadcrumb-item active" aria-current="page">Agendar Registro</li>
  </ol>
</nav>



<form method="post" action="modules.php?mod=agentes" name="frm1">
    <table class="text" border="2">
        <tr>
            <td colspan="2">Capture la siguiente informaci&oacute;n para el registro seleccionado.</td>
            <td rowspan="9">
                <div align="center">
                    <label for="fecha_agenda">Fecha:</label>
                    <input type="text" name="fecha_agenda" id="fecha_agenda" size="10" maxlength="10" class="tcal" value="<?php echo date('d/m/Y'); ?>" />
                    <input type="button" value="Actualiza Dia" name="cmdAgenda" id="cmdAgenda" onclick="this.disabled = true;
                        verAgenda(this, frm1.fecha_agenda.value, 'agenda',0);" />
                    <input type="button" value="Ver agenda" name="cmdAgenda" id="cmdAgenda" onclick="this.disabled = true;
                                                    verAgenda(this, document.getElementById('fecha_agenda').value, 'agenda2', 1);" />
                </div>
                <div id="agenda" align="center" class="script2"></div>
            </td>
        </tr>
        <tr>
            <td class="textleft"><b>Nombre cliente:&nbsp;</b></td>
            <td class="label"><?= $datos_cliente[0]['NOMBRE'] . '&nbsp;' . $datos_cliente[0]['APATERNO'] . '&nbsp;' . $datos_cliente[0]['AMATERNO'] ?></td>
        </tr>
        <tr>
            <td class="textleft"><b># Solicitud:&nbsp;</b></td>
            <td class="label"><?= $id_solicitud ?></td>
        </tr>
        <tr>
            <td class="textleft" colspan="2"><b>Comentarios:&nbsp;</b></td>
        </tr>
        <tr>
            <td colspan="2">
                <textarea name="comentarios" rows="5" cols="70" onKeyDown="limita_texto(this.form.comentarios, this.form.contador_car, 500);" onKeyUp="limita_texto(this.form.comentarios, this.form.contador_car, 500);"><?= isset($registro->fields["COMENTARIOS"]) ? $registro->fields["COMENTARIOS"] : ''; ?></textarea>
                <br />
                M�ximo <input readonly type="text" name="contador_car" value="500" class="leftchar"> caracteres.
            </td>
        <tr>
            <td colspan="2">
                <input type="button" value="Cancelar" onclick="this.disabled = true;
                        Atras()"/>&nbsp;&nbsp;
                <!--input type="button" value="Agendar" onclick="this.disabled = true;
                        Agenda_registro(this, '<?= encripta(6) ?>')"/-->
            </td>
        </tr>
    </table>
    <input type="hidden" name="hora" id="hora">
</form>
<?php
//}
layout_footer();
