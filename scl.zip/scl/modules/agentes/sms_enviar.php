<?php
// ini_set('memory_limit', '-1');
// ini_set('display_errors', true);
// ob_start();


if(isset($_REQUEST['action']) && $_REQUEST['action'] =='vf')verifcar_numero();
if(isset($_REQUEST['action']) && $_REQUEST['action'] =='es')envia_sms();




function verifcar_numero ()
    {
        $v_numero = $_REQUEST['tel']/5;
        // echo $v_numero;
        include_once '../includes/openConnection_ajax.php';
        try {
            $query = "BEGIN sps_verifcar_numero(:v_numero,:resultado); END;";
            $stmt = $db->PrepareSP($query);
            $db->InParameter($stmt, $v_numero, 'v_numero');
            $db->OutParameter($stmt, $resultado, 'resultado');
            $db->Execute($stmt);
            echo $resultado;
        } catch (Exception $e) {
            pa($e->getTraceAsString());
            die();
            exit();
        }
    }

function envia_sms ()
    {

        $v_numero = $_REQUEST['tel']/5;
        //$v_numero = "4424437840";
        $producto = $_REQUEST['producto'];
        $sol = $_REQUEST['sol'];
        $r_ivr = $_REQUEST['r_ivr'];
        // echo json_encode(array('SMS ENVIADO!!!', $r_ivr));
        // /*
        include_once '../includes/openConnection_ajax.php';
        if($r_ivr==0){
            try {
                $query = "BEGIN sps_registrar_ivr(:solicitud, :producto, :resultado); END;";
                $stmt = $db->PrepareSP($query);
                $db->InParameter($stmt, $sol, 'solicitud');    
                $db->InParameter($stmt, $producto, 'producto');        
                $db->OutParameter($stmt, $resultado_ivr_sms, 'resultado');
                $db->Execute($stmt);
            } catch (Exception $e) {
                pa($e->getTraceAsString());
                die();
                exit();
            }
        }else{
            $resultado_ivr_sms=$r_ivr;
        }
        $url_envio_sms = "http://172.20.1.95/sms_bancomer_prueba/index.php?codigo=".$resultado_ivr_sms."&numero=" . $v_numero;
    
        $handler_envio = curl_init();
        curl_setopt($handler_envio, CURLOPT_URL, $url_envio_sms);
        curl_setopt($handler_envio, CURLOPT_RETURNTRANSFER, 1);

        $uid = curl_exec($handler_envio);

        // set_UID_sms_ivr($id_solicitud,$id_producto,$uid,$codigo_ivr_sms,$db);
        try {
            $query = "BEGIN sps_actualizar_ivr(:solicitud, :producto, :uid, :codigo_ivr_sms); END;";
            $stmt = $db->PrepareSP($query);
            $db->InParameter($stmt, $sol, 'solicitud');    
            $db->InParameter($stmt, $producto, 'producto');        
            $db->InParameter($stmt, $uid, 'uid');
            $db->InParameter($stmt, $resultado_ivr_sms, 'codigo_ivr_sms');
            $db->Execute($stmt);
        } catch (Exception $e) {
            pa($e->getTraceAsString());
            die();
            exit();
        }


    
        $url_status_sms = "http://172.20.1.95/sms_bancomer_prueba/status.php?uid=" . $uid;

        usleep(500000);
        $handler_status_sms = curl_init();
        curl_setopt($handler_status_sms, CURLOPT_URL, $url_status_sms);
        curl_setopt($handler_status_sms, CURLOPT_RETURNTRANSFER, 1);

        $status_sms = curl_exec($handler_status_sms);

        $resp_status_sms = json_decode($status_sms);
        if ($resp_status_sms->resp == "200") {
            $status_sms = $resp_status_sms->status;
            
            if($status_sms != ''){
                echo json_encode(array($status_sms, $resultado_ivr_sms));
            }else{
                echo json_encode(array('SMS ENVIADO!!!', $resultado_ivr_sms));
            }
            
        } elseif ($resp_status_sms->resp == "400") {
            echo json_encode(array($resp_status_sms->description, $resultado_ivr_sms));
        } else {
            echo "<pre>";
            print_r($resp_status_sms);
            echo "</pre>";
        }
        // */
        die();
        exit();
    }
// $header = "http://172.20.1.72/websicall/bancomerseg/main.php";

// $content = ob_get_contents();
// ob_end_clean();
?>