<?php
# @uthor Mark
# Cuestionario File

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("supervisor", "Solicitud");

$id_solicitud = get_session_varname('id_solicitud');

layout_menu($db, "");
?>
<p class="textbold">Funci&oacute;n desactivada.</p><!--20130730 a petición de Ponch-->

<p class="textbold">Agentes &gt; Datos de Solicitud</p>
<p>&nbsp;</p>
<form method="post" action="#" name="frm1">
    <table border="0">
        <tr>
            <td colspan="2" class="label_td" bgcolor="grey">Solicitud</td>
        </tr>
        <tr>
            <td colspan="2">&nbsp;</td>
        </tr>
        <tr>
            <td class="textleft"><b>Solicitud:&nbsp;</b></td>
            <td class="label"><input type="text" name="txt_solicitud" size="10" id="txt_solicitud" maxlength="10"></td>
        </tr>
        <tr>
            <td class="textleft"><b>Producto:&nbsp;</b></td>
            <td class="label"><input type="text" size="3" name="txt_producto" id="txt_producto" maxlength="3"></td>
        </tr>
        <tr>
            <td colspan="2">&nbsp;</td>
        </tr>
        <tr>
            <td colspan="2">
                <input type="button" value="Cancelar" onclick="window.location='index2.php'"/>&nbsp;&nbsp;
                <input type="button" value="Buscar" onclick="datos_solicitud();"/>&nbsp;&nbsp;
            </td>
        </tr>
    </table>
</form>
<?
layout_footer();
?>