<?php
# @uthor Mark
# Script OUT File

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("agente","Nuevo registro");

$id_solicitud = $_REQUEST['sol'];
$agente = get_session_varname('s_usr_nombre');
$registro = get_detalle_solicitud($id_solicitud, $db);
$nombre_completo = $registro->fields["MAIN_NOMBRE_COMPLETO"];
?>
<html>
    <head>
        <title>GUI&oacute;N TELEMARKETING</title>
    </head>
<body>

<p><b><span style='font-size:14.0pt;color:red'>Script Upgrade Clásicas a Oro.</span></b></p>

<table border="1"  style="border-style:solid;border-width:1px;border-color:black;">
	<tr>
		<td>
			<p><b><span >&nbsp;</span></b></p>
			<p><b><span >Conversaci&oacute;n 1:</span></b></p>
		</td>
		<td colspan="2">
			<p><span>&nbsp;</span></p>
			<p>
                <span>Buenos (as) días/tardes/noches, sería tan amable en comunicarme con <?=$nombre_completo ?>. Habla </span>
				<span style='color:red'><?=$agente ?></span>
				<span>del Grupo Financiero Santander.</span>
			</p>
			<p><span>&nbsp;</span></p>			
		</td>
	</tr><tr>
		<td>
			<p><b><span >&nbsp;</span></b></p>
			<p><b><span >Respuesta</span></b></p>
		</td>
		<td colspan="2">
			<p><span>&nbsp;</span></p>
			<p><span>   a) Si se encuentra  -- Pasar a conversación.</span></p>
            <br><br>
			<p><span>   b) No se encuentra  -- Pasar a despedida 2.</span></p>
		</td>
	</tr><tr>
		<td>
			<p><b><span >&nbsp;</span></b></p>
			<p><b><span >Conversacion:</span></b></p>
            <p><b><span >Operador:</span></b></p>
		</td>
		<td colspan="2">
			<p><span>&nbsp;</span></p>
			<p><span>Santander lo reconoce como uno de nuestros mejores clientes, es por eso que usted está  preaprobado para recibir un ascenso de producto.</span></p><br>
			<p><span>Ahora usted puede disfrutar del beneficio de cambiar su tarjeta Clásica terminación XXXX  por una Santander Oro MasterCard, la tarjeta de crédito que posee el prestigio y exclusividad acorde a su estilo de vida.</span></p><br>
			<p><span>Con la Tarjeta Santander Oro MasterCard usted obtendrá los mejores servicios:</span></p><br>

           <UL type = square>
                <LI> Programa de Recompensas Totalmente Gratis. ¡Nuevo!
                <LI> Seguro contra accidentes en viajes por 250 mil USD al comprar su boleto de viaje con la tarjeta de crédito Oro. ¡Mejor que con la clásica! (Clásica otorga 75 mil USD)
                <LI> Seguro de renta de autos USA y CANADÁ con una cobertura de hasta $50 mil USD al pagar con su tarjeta Oro. ¡Nuevo!
                <LI> Seguro contra robo o extravío y de cancelación de deuda en caso de fallecimiento del titular.
                <LI> Servicio de Asistencia de Viajes. Asistencia personal las 24 horas a través de: Referencias Médicas, Legales, Viajes, etc.
            </UL>
    	</td>
	</tr><tr>
		<td>
			<p><b><span >&nbsp;</span></b></p>
			<p><b><span >Operador:</span></b></p>
			<p><b><span >&nbsp;</span></b></p>			
		</td>
		<td colspan="2">
			<p><span>&nbsp;</span></p>
			<p><span>Adquiera todos los beneficios Oro,  por tan sólo por 4 pagos de $162.5 pesos más IVA. </span></p><br>
			<p><span>Además al realizar su cambio de producto antes del 05 de septiembre del 2009, el cliente con mayor número de compras, con un monto mínimo de $800 pesos MN. cada una del 10 de agosto al 5 de septiembre del 2009 podrá ganar uno de los 5 viajes dobles para asistir a la Serie Mundial de Béisbol cortesía de MasterCard® y Santander.</span></p><br>
			<p><span>Sr.(ita.) (Apellido del cliente), Nos gustaría darle la bienvenida a la tarjeta de crédito Santander Oro, con la cual usted formará parte de nuestro selecto grupo de clientes Gold, y podrá acceder a los mejores beneficios.</span></p><br>
			<p><span>&nbsp;</span></p>
		</td>
    </tr><tr>
		<td>
			<p><b><span >&nbsp;</span></b></p>
			<p><b><span >Operador:</span></b></p>
			<p><b><span >&nbsp;</span></b></p>
		</td>
		<td colspan="2">
			<p><span>&nbsp;</span></p>
			<p><span>Tiene alguna duda sobre este beneficio que le otorga Santander Sr.(ita.) (Apellido del cliente)?</span></p><br>
			<p><span>Sr.(ita.) (Apellido del cliente), si está usted de acuerdo, lo registraremos para el cambio de producto.</span></p><br>
			<p><span>&nbsp;</span></p>
		</td>
	</tr><tr>
		<td>&nbsp;</td>
        <td>
			<p><span >C)Si </span></p>
            <p><span >D)No ¿Por qué?</span></p>
            <UL type = square>
                <LI>No quiero gastar más. (anualidad)
                <LI>No me convencen los beneficios.
                <LI>Estoy contento con la Clásica.
                <LI>No quiero volver a tramitar mis pagos domiciliados.
                <LI>Proceso complicado.
                <LI>Como se que no es un fraude.
                <LI>No la uso.
                <LI>La voy a cancelar.
                <LI>No quiero/interesa.
                <LI>Otros.
            </UL>
		</td>
		<td>
            <p><span >Pasar a Conversación</span></p>
            <p><span >&nbsp;</span></p>
            <UL type = square>
                <LI>Pasar a Argumento para Objetar 1.
                <LI>Pasar a Argumento para Objetar 2.
                <LI>Pasar a Argumento para Objetar 4.
                <LI>Pasar a Argumento para Objetar 5.
                <LI>Pasar a Argumento para Objetar 3.
                <LI>Pasar a Argumento para Objetar 1.
                <LI>Pasar a Argumento para Objetar 1.
                <LI>Pasar a Argumento para Objetar 1.
                <LI>Pasar a Argumento para Objetar 1.
            </UL>
        </td>
	</tr><tr>
        <td>
			<p><b><span >&nbsp;</span></b></p>
			<p><b><span >Operador:</span></b></p>
			<p><b><span >&nbsp;</span></b></p>
		</td>
		<td colspan="2">
			<p><span>&nbsp;</span></p>
			<p><span>Sr.(ita.) (Apellido del cliente), Tiene cargos recurrentes como son,  domiciliación (Telmex, Cablevisión/ Sky, Telcel, etc.) o programas de Santander (Asistencia Santander)  inscritos en su TdC? Cuales son?</span></p>
			<p><span>&nbsp;</span></p>
		</td>
	</tr><tr>
        <td>Respuesta Cliente:</td>
        <td>
			<p><span >E)Si </span></p>
            <UL type = square>
                <LI>Tiene TELMEX
                <LI>Tiene TELMEX + Otros
                <LI>Tiene Otros
            </UL>
            <p><span >F)No</span></p>
        </td>
		<td>
            <p><span >&nbsp;</span></p>
            <UL type = square>
                <LI>Marcar en base 1
                <LI>Marcar en base 2
                <LI>Marcar en base 3
            <p><span >&nbsp;</span></p>
                <LI>Marcar en base 0
            </UL>
        </td>
	</tr><tr>
        <td>
			<p><b><span >&nbsp;</span></b></p>
			<p><b><span >Operador:</span></b></p>
			<p><b><span >&nbsp;</span></b></p>
		</td>
		<td colspan="2">
			<p><span>&nbsp;</span></p>
			<p><span>Sr.(ita.) (Apellido del cliente), al momento de recibir su nueva tarjeta de crédito Oro Santander, deberá de actualizar su número de tarjeta de crédito para los cargos automáticos que tenga domiciliados, ya que su número de cuenta cambiará, el pago de su recibo Telmex podrá solicitarlo o actualizarlo al momento que realice la activación en SuperLínea. </span></p><br>
			<p><span>Le recuerdo que a partir del momento en que reciba su tarjeta de crédito Oro, estará generando puntos Recompensas por todas sus compras y cargos recurrentes sin costo.</span></p><br>
			<p><span>Sr.(ita.) (Apellido del cliente), con fines de calidad lo voy a transferir al área de validación para que realicen un pequeña grabación de voz, le pido no me cuelgue por favor.</span></p><br>
			<p><span>INICIA SCRIPT DE VALIDACIÓN</span></p>
			<p><span>&nbsp;</span></p>
		</td>
	</tr><tr>
        <td>
			<p><b><span >&nbsp;</span></b></p>
			<p><b><span >Despedida:</span></b></p>
			<p><b><span >&nbsp;</span></b></p>
		</td>
		<td colspan="2">
			<p><span>&nbsp;</span></p>
			<p><span>Sr.(ita.) (Apellido del cliente), le recordamos que cualquier duda puede comunicarse a SuperLínea al 51 69 43 00 o para el interior de la República  al 01 800 50 100 00 y con gusto lo atenderemos. </span></p><br>
			<p><span>A nombre de Banco Santander le agradezco su llamada. Que tenga buenos (as) días/tardes/noches.</span></p><br>
			<p><span>Fin de llamada</span></p><br>
			<p><span>&nbsp;</span></p>
		</td>
	</tr><tr>
        <td>
			<p><b><span >&nbsp;</span></b></p>
			<p><b><span >Despedida 2:</span></b></p>
			<p><b><span >&nbsp;</span></b></p>
		</td>
		<td colspan="2">
            <p><span>&nbsp;</span></p>
			<p><span>Sr.(ita.) (Apellido del cliente), En ese caso nos comunicaremos posteriormente para informarle a detalle del motivo de nuestra llamada.</span></p><br>
			<p><span>Le agradezco mucho su atención que pase buen día / tarde / noche</span></p><br>
			<p><span>Fin de llamada</span></p><br>
			<p><span>&nbsp;</span></p>
		</td>
	</tr><tr>
      <td>
			<p><b><span >&nbsp;</span></b></p>
			<p><b><span >Argumento para Objetar:</span></b></p>
			<p><b><span >&nbsp;</span></b></p>
		</td>
		<td colspan="2">
            <p><span>&nbsp;</span></p>
			<p><span>Sr.(ita.) (Apellido del cliente), usted tiene una oportunidad que no debe dejar pasar ya que Santander Oro, es un producto más completo que le da mayores beneficios a un costo más bajo. El ser un usuario Oro le permite</span></p><br>
			<p><span>El programa de Recompensas tiene un costo anual de $345 pesos. Este es un beneficio que Oro le otorga sin costo, generando puntos por cada $10 pesos de compra.</span></p><br>
			<p><span>Más seguros sin costo que la clásica, con mayores coberturas.</span></p><br>
			<p><span>Exclusivos servicios de asistencia personalizada las 24 hrs.</span></p><br>
 			<p><span>Estos son servicios que sólo obtienen nuestros clientes Oro con el fin de brindarles el mayor confort y seguridad con el prestigio Gold por un costo más bajo.</span></p><br>
 			<p><span>Además de que Oro y Clásica manejan la misma tasa de Interés mensual del 54.91% (verificar dato actualizado)</span></p><br>
 			<p><span>MATERIAL DE APOYO: Tabla de comparación de productos</span></p><br>
 			<p><span>Sr.(ita.) (Apellido del cliente), si esta usted de acuerdo, lo registraremos para el cambio de producto.</span></p><br>
            <p><span>&nbsp;</span></p>
		</td>
	</tr><tr>
        <td>&nbsp;</td>
        <td>
			<p><span >G)Si </span></p>
            <p><span >&nbsp;</span></p>
            <p><span >H)No, Porque?</span></p>
        </td>
		<td>
            <p><span >Pasar a Conversación </span></p>
            <p><span >&nbsp;</span></p>
            <p><span >Indicar motivo del rechazo por parte del cliente.</span></p>
        </td>
	</tr><tr>
        <td>
			<p><b><span >&nbsp;</span></b></p>
			<p><b><span >Argumento para Objetar 2:</span></b></p>
			<p><b><span >&nbsp;</span></b></p>
		</td>
		<td colspan="2">
            <p><span>&nbsp;</span></p>
			<p><span>Sr.(ita.) (Apellido del cliente), definitivamente Santander Clásica es un producto muy completo.</span></p><br>
			<p><span>Santander Oro es un producto objetivo es brindar a nuestros clientes importantes mayor confort y seguridad.</span></p><br>
			<p><span>¿A que nos referimos cuando decimos que Oro tiene un costo con más bajo?    Oro le brinda</span></p><br>
            <UL type = square>
                <LI>El programa de Recompensas con un costo anual de $345 pesos. Este es un beneficio que Oro le otorga sin costo, generando puntos por cada $10 pesos de compra.
                <LI>Más seguros sin costo que la clásica, con mayores coberturas.
                <LI>Exclusivos servicios de asistencia personalizada las 24 hrs.
            </UL>
			<p><span>Además, Oro y Clásica manejan la misma tasa de Interés mensual del XX.XX% (verificar dato actualizado).</span></p><br>
			<p><span>MATERIAL DE APOYO: Tabla de comparación de productos</span></p><br>
			<p><span>Sr.(ita.) (Apellido del cliente), si está usted de acuerdo, lo registraremos para el cambio de producto.</span></p><br>
            <p><span>&nbsp;</span></p>
		</td>
	</tr><tr>
        <td>&nbsp;</td>
        <td>
			<p><span >I)Si </span></p>
            <p><span >&nbsp;</span></p>
            <p><span >J)No, Porque?</span></p>
        </td>
		<td>
            <p><span >Pasar a Conversación </span></p>
            <p><span >&nbsp;</span></p>
            <p><span >Indicar motivo del rechazo por parte del cliente.</span></p>
        </td>
	</tr><tr>
        <td>
			<p><b><span >&nbsp;</span></b></p>
			<p><b><span >Argumento para Objetar 3:</span></b></p>
			<p><b><span >&nbsp;</span></b></p>
		</td>
		<td colspan="2">
            <p><span>&nbsp;</span></p>
			<p><span>Sr.(ita.) (Apellido del cliente), le enviamos una carta vía correo en donde le informamos que usted es uno de los clientes preaprobado para una Tarjeta de Crédito Santander Oro. En caso de que no la haya recibido. Lo invito a que se comunique a Superlínea a los teléfonos indicados en la parte de atrás de su tarjeta o si desea le indico los números: XXXXXX, XXXXXX</span></p><br>
			<p><span>En donde podrá corroborar que esto no es un fraude. </span></p><br>
			<p><span>Si nos permite, nos comunicaremos con usted más tarde o si lo desea, puede comunicar con nosotros al siguiente número sin costo: 01-800-800-3344</span></p><br>
            <p><span>&nbsp;</span></p>
		</td>
	</tr><tr>
    <td>&nbsp;</td>
        <td>
			<p><span >K)Si </span></p>
            <p><span >&nbsp;</span></p>
            <p><span >L)No, Porque?</span></p>
        </td>
		<td>
            <p><span >Pasar a Conversación </span></p>
            <p><span >&nbsp;</span></p>
            <p><span >Indicar motivo del rechazo por parte del cliente.</span></p>
        </td>
	</tr><tr>
        <td>
			<p><b><span >&nbsp;</span></b></p>
			<p><b><span >Argumento para Objetar 4:</span></b></p>
			<p><b><span >&nbsp;</span></b></p>
		</td>
		<td colspan="2">
            <p><span>&nbsp;</span></p>
			<p><span>Sr.(ita.) (Apellido del cliente), en el caso de el pago del recibo TELMEX, lo podrá dar de alta de nuevo automáticamente en el momento que reciba su tarjeta Oro y llame a Superlínea para activarla, para otros cargos domiciliados sólo tiene que llamar a la compañía en donde le ofrecen el servicio y hacer el cambio del número de tarjeta. Con la ventaja ahora de que este producto le generará puntos Recompensas por todos estos cargos.</span></p><br>
 			<p><span>Sr.(ita.) (Apellido del cliente), si está usted de acuerdo, lo registraremos para el cambio de producto</span></p><br>
            <p><span>&nbsp;</span></p>
		</td>
	</tr><tr>
    <td>&nbsp;</td>
        <td>
			<p><span >M)Si </span></p>
            <p><span >&nbsp;</span></p>
            <p><span >N)No, Porque?</span></p>
        </td>
		<td>
            <p><span >Pasar a Conversación </span></p>
            <p><span >&nbsp;</span></p>
            <p><span >Indicar motivo del rechazo por parte del cliente.</span></p>
        </td>
	</tr><tr>
        <td>
			<p><b><span >&nbsp;</span></b></p>
			<p><b><span >Argumento para Objetar 5:</span></b></p>
			<p><b><span >&nbsp;</span></b></p>
		</td>
		<td colspan="2">
            <p><span>&nbsp;</span></p>
			<p><span>Sr.(ita.) (Apellido del cliente), no se preocupe por el proceso, si usted acepta este beneficio Santander se encargará de todo el proceso de cambio de producto. Seguirá teniendo el servicio de Clásica hasta el momento en que reciba la Oro en su domicilio.</span></p><br>
			<p><span>Sr.(ita.) (Apellido del cliente), si está usted de acuerdo, lo registraremos para el cambio de producto.</span></p><br>
            <p><span>&nbsp;</span></p>
		</td>
	</tr><tr>
    <td>&nbsp;</td>
        <td>
			<p><span >Ñ)Si </span></p>
            <p><span >&nbsp;</span></p>
            <p><span >O)No, Porque?</span></p>
        </td>
		<td>
            <p><span >Pasar a Conversación </span></p>
            <p><span >&nbsp;</span></p>
            <p><span >Indicar motivo del rechazo por parte del cliente.</span></p>
        </td>
	</tr>
</table>
</body>
</html>