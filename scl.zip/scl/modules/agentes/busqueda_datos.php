<?php

# @uthor Mark
# Index File on agente module

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("agente,supervisor", "Busqueda de Clientes");
layout_menu($db);
?>	
<p class="textbold">Agentes &gt; Busqueda de Datos</p>
<p>&nbsp;</p>
<form method="post" action="modules.php?mod=agentes&op=resultado_busq_datos" name="frm1">
    <table class="text" border="0">
        <tr>
            <td width="60%">
                <table border="0">
                    <tr>
                        <td colspan="3">&nbsp;</td>
                    </tr><tr>
                        <td colspan="2">Introduzca alguno de los campos para realizar la b&uacute;squeda.</td>
                    </tr><tr>
                        <td colspan="3">
                            <table border="0">
                                <tr valign="top">
                                    <td><input type="radio" name="tipo" id="tipo1" value="1" checked onclick="habilitar(this.value);"></td>
                                    <th align="left">
                                        <label for="tipo1">Nombre:</label>
                                    </th>
                                    <td><input type="text" size="20" name="nombre" id="nombre" maxlength="20" ></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <th align="left">Apellido Paterno:</th>
                                    <td><input type="text" size="20" name="paterno" id="paterno" maxlength="20" ></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td class="textleft"><b>Apellido Materno:</b>
                                    <td><input type="text" size="20" name="materno" id="materno" maxlength="20" ></td>
                                </tr>
                                <tr>
                                    <td><input type="radio" name="tipo" id="tipo2" value="2" onclick="habilitar(this.value);"></td>
                                    <th align="left">
                                        <label for="tipo2">Solicitud:</label>
                                    </th>
                                    <td><input type="text" size="10" name="solicitud" id="solicitud" maxlength="10" disabled></td>
                                </tr>
                                <tr>
                                    <td><input type="radio" name="tipo" id="tipo3" value="3" onclick="habilitar(this.value);"></td>
                                    <th align="left">
                                        <label for="tipo3">Folio LUCI:</label>
                                    </th>
                                    <td><input type="text" size="10" name="clave" id="clave" maxlength="10" disabled></td>
                                </tr>
                                <tr>
                                    <td><input type="radio" name="tipo" id="tipo4" value="4" onclick="habilitar(this.value);"></td>
                                    <th align="left">
                                        <label for="tipo4">Tel&eacute;fono:</label>
                                    </th>
                                    <td><input type="text" size="10" name="telefono" id="telefono" maxlength="10" disabled></td>
                                </tr>
                                <tr>
                                    <td><input type="radio" name="tipo" id="tipo5" value="5" onclick="habilitar(this.value);"></td>
                                    <th align="left">
                                        <label for="tipo5">RFC:</label>
                                    </th>
                                    <td><input type="text" size="13" name="rfc" id="rfc" maxlength="13" disabled></td>
                                </tr>
                                <tr>
                                    <th align="left" colspan="2">
                                        Buscar en:
                                    </th>
                                    <td>
                                        <input type="radio" name="busqueda" id="busqueda1" value="1" checked>
                                        <label for="busqueda1">Vivas</label>
                                        <input type="radio" name="busqueda" id="busqueda2" value="2">
                                        <label for="busqueda2">Canceladas</label>
                                        <input type="radio" name="busqueda" id="busqueda3" value="3">
                                        <label for="busqueda3">Eliminadas</label>
                                    </td>
                                </tr>
                            </table>
                            <br>
                        </td>
                    </tr><tr>
                        <td colspan="3">
                            <input type="button" value="Buscar" onclick="BuscarDatos()"/>&nbsp;&nbsp;
                            <!--input type="button" value="Buscar" onclick="alert('No habilitado por el momento')"/>&nbsp;&nbsp;-->
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</form>
<?

layout_footer();
?>