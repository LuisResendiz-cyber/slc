<?php

require_once("../../includes/includes.inc.php");
require_once("agentes.inc.php");

/*$act = desencripta($_POST["act"]);
$resp = array(
    'act' => $_POST["act"],
    'arr' => $act
);

echo json_encode($resp);

exit();*/


switch (desencripta($_POST["act"])) {
    case 77:
        $resp2 = ObtenerPlan($_POST["comb"], $db);
        foreach ($resp2 as $key => $value) {
            $resp[] = array(
                'plan' => utf8_encode($value["PLAN"]),
                'costo' => $value["COSTO_CBO"]
            );
        }
        echo json_encode($resp);
        break;
    
    default:
        # code...
        break;
}