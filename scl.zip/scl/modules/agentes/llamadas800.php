<?php
# @uthor Mark
# Cuestionario File
//libxml_use_internal_errors(true);
require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

//initialize("agente,supervisor", "Solicitud");
//layout_menu($db, "");
$nomina = base64_decode($_REQUEST['nomina']);
$u_user = base64_decode($_REQUEST['u_user']);
?>

<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <script>
            function loading_fun() {
                Html = '<div id="ajControl" width="100%">' +
                        '<table cellpadding="0" cellspacing="0" width="100%" height="100%" align="center">' +
                        '<tr id="ajControlBody">' +
                        '<td>Cargando...<br><br>Su peticion esta siendo procesada</td>' +
                        '</tr>' +
                        '</table>' +
                        '</div>';

                var div = document.createElement('div');
                div.id = 'div_padre';
                div.innerHTML = Html;

                document.body.appendChild(div);
            }

            function Actualizar(boton) {

                boton.disabled = true;

                var xmlhttp;
                if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
                    xmlhttp = new XMLHttpRequest();
                } else {// code for IE6, IE5
                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange = function() {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                        document.getElementById("result").innerHTML = xmlhttp.responseText;
                    }
                };

                xmlhttp.open("POST", "modules.php?mod=agentes&op=process_data&act=<?= encripta('40') ?>", true);
                xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                xmlhttp.send("nomina=<?= $nomina ?>&u_user=<?= $u_user ?>");
            }

        </script>
        <style>
            table.indicadores tr td {
                border: 2px solid #7BA1B1;    
                border-collapse: separate;
                border-radius: 2%;
                font-size: 10px;
                text-align: center;
                transition:width 1s, height 1s, transform 1s;
            }

            table.indicadores th {
                border: 2px solid #7BA1B1;
                border-collapse: collapse;
                border-radius: 2%;
                font-size: 12px;    
                background-color: #CCCCFF;
            }

            table.indicadores caption {
                font-size: 12px;
                font-weight: bold;
                color: red;
            }

            table.indicadores tr:hover td {
                border: 2px solid black;
            }
        </style>
    </head>    
    <body style="background: #3F738D;">
        <div id="result">
            <table class="indicadores">
                <tr class="indicadores">
                    <th colspan="8" class="indicadores">Llamadas 800</th>
                </tr>
                <tr class="indicadores" style="background: #006666;">
                    <td>Reporte</td>
                    <td>Registro</td>
                    <td>Cliente</td>
                    <td>Tel�fono</td>
                    <td>Comentario</td>
                    <td>Motivo Llamada</td>
                    <td>Fecha</td>
                    <td>Reportado a</td>
                </tr>
                <tr class="indicadores">
                    <td class="indicadores">&nbsp</td>
                    <td class="indicadores">&nbsp</td>
                    <td class="indicadores">&nbsp</td>
                    <td class="indicadores">&nbsp</td>
                    <td class="indicadores">&nbsp</td>
                    <td class="indicadores">&nbsp</td>
                    <td class="indicadores">&nbsp</td>
                    <td class="indicadores">&nbsp</td>
                </tr>
            </table>
        </div>
        <div align="center">
            <input type="button" value="Actualizar" id="b_actualizar" onclick="Actualizar(this);"/>
        </div>
        <?php //}  ?>
    </body>
</html>