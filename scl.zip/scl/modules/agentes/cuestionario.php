<?php
require_once("includes/includes.inc.php");
require_once("agentes.inc.php");
initialize("agente", "Solicitud");
set_session_varname("url_contacto", "cuestionario");
$RESP = array();
$sb = get_session_varname('sb');
$tkn = get_session_varname('tkn');
$valorcuestionario = isset($_POST['opcion']);
$id_solicitud = get_session_varname('id_solicitud');
$id_producto = get_session_varname('id_producto');
$id_registro = get_session_varname('id_registro');
$datos_cliente = get_session_varname("datos_persona");
$nomina = get_session_varname('s_usr_nomina');
$extenagente = get_session_varname('extension');
$isPredictivo2 = get_session_varname("s_usr_marcacion");
$razon_cancelacion = get_razon_cancelacion($db);
$id_razon = get_razoncancelacionid($id_solicitud, $id_producto, $db);
$datos_inicio = get_datos_inicio($id_solicitud,$id_producto,$db) ?? '';
$edad = get_datos_edad($id_solicitud,$id_producto,$db);
$datos_agentesuper = get_datos_agentesuper($id_solicitud,1,$db);

$telefono = get_session_varname("s_telefono");
$u_telefono = get_session_varname("s_tel_contacto");
$cc = get_session_varname("s_usr_cc");
$id_usr = get_session_varname("s_usr_id");
$inicio = '';
if (!isset($_REQUEST['inicio'])) {
    $inicio = 'y';
}

$count_agendados = get_conteo_agendas($id_usr, $db);

$nombre_cliente = trim($datos_cliente[0]['NOMBRE']) . ' ' . trim($datos_cliente[0]['APATERNO']) . ' ' . trim($datos_cliente[0]['AMATERNO']);

$tipo_zona = isset($datos_cliente[0]['TIPO_ZONA']) ? $datos_cliente[0]['TIPO_ZONA'] : '';



if($count_agendados >= 5){
    layout_menu($db, "ShowScript_GeneralIN();avisoPrivacidad('$nombre_cliente', '$inicio');NoAgendar()");
}else{
    layout_menu($db, "ShowScript_GeneralIN()");
}

echo '<input type="hidden" value="'.$id_producto.'" id="inputProducto">';
?>

<div class="modalDescripcionTarjeta" id="modalDescripcionTarjeta" display="none">
    <div class="modal-contenidoDescripcionTarjeta">
        <span class="cerrar-modalDescripcionTarjeta" id="cerrarModalDescripcionTarjeta">&times;</span>
        <div id="modal-contenidoTarjeta">
            <p> Contenido del modal... </p>
        </div>
    </div>
</div>

<script>
var survey_id = <?= $id_producto ?>;
var customer_id = <?= $id_solicitud ?>;
var conteo_agendas = '<?= $count_agendados ?>';
</script>
<script LANGUAGE="JavaScript" src="./includes/js/jsCode_cuestionario<?= $id_producto ?>.js"></script>


<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#">Agentes</a></li>
        <li class="breadcrumb-item active" aria-current="page"> Solicitud</li>
    </ol>
</nav>


<p>&nbsp;</p>
<form method="post" action="modules.php?mod=agentes&op=process_data&act=<?= encripta(14) ?>" name="SurveyResponse">
    <input type="hidden" name="inicio" id="inicio" value="<?php echo $inicio ?>">
    <input type="hidden" name="modo" id="modo" value="procesar">
    <table border="0" width="100%">
        <tr>
            <td colspan="2" class="label_td">Calificaciones del registro</td>
        </tr>
        <tr>
            <td colspan="2">Seleccione la razon por la cual no se logr&oacute; la venta:

                <?php if($id_producto == 1): ?>
                <select name="si_contacto" class="form-control mb-2" id="si_contacto"
                    onchange="revisa_calificacion(this, 2, <?php echo $id_solicitud ?>, '<?php echo $telefono ?>');">
                    <option value="0">Elige opci&oacute;n</option>
                    <?php
                    if($count_agendados >= 5){
                        $cal_SC = get_cal_SC(2, $db); //RAZONES NO VENTA
                    }else if($tipo_zona == "OB"){
                        $cal_SC = get_cal_SC(3, $db); //RAZONES NO VENTA
                    }else{
                        $cal_SC = get_cal_SC(1, $db); //RAZONES NO VENTA
                    }

                    for ($indice_cal = 0; $indice_cal < count($cal_SC->_array); $indice_cal++) {
                        echo '<option value="' . $cal_SC->_array[$indice_cal]['U_ESTATUSLLAMADA'] . '" >' . $cal_SC->_array[$indice_cal]['ESTATUS'] . '</option>';
                    }
                    ?>
                </select>
                <?php else: ?>
                <select name="razon_cancelacion" class="form-control" id="razon_cancelacion"
                    onchange="funcion_cancelacion(this)">
                    <option value="0"></option>
                    <?php
                    foreach ($razon_cancelacion as $r) {
                        $select = "";
                        if ($id_razon == $r['RAZONCANCELACIONID'])
                            $select = "selected";
                        else
                            $select = " ";
                        echo "<option {$select} value='" . $r['RAZONCANCELACIONID'] . "'>" . $r['DESCRIPCION'] . "</option>";
                    }
                    ?>
                </select>
                <?php endif; ?>

            </td>
        </tr>
        <tr>
            <td colspan="2">
                <input type="button" class="btn btn-danger" value="Regresar a no Contacto" onclick="this.disabled = true;
        regresar_no_contacto()" />&nbsp;&nbsp;

                <?php 
        if ($id_producto == 100):?>
                <!-- 
        <input class="btn btn-success" type="button" value="Validar Producto Uno" id="ObtAgenda" onclick="Mostrar_agendado10(0,<?= $id_registro ?>,<?= $id_solicitud ?>, '<?= encripta(3) ?>', 1)"/>&nbsp;&nbsp; -->
                <?php else: ?>
                <input type="button" class="btn btn-primary" value="Calificar"
                    onclick="calificar_si_contacto(this,<?= $id_solicitud ?>, '<?= encripta(7) ?>', <?= $isPredictivo2 ?>)" />&nbsp;&nbsp;
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <td colspan="2" class="label_td">Datos</td>
        </tr>
        <tr>

            <?php if ($id_producto  == 1) :?>
            <td colspan="2" class="label">

                <table class="label">


                    <?php

                    if($tipo_zona == "OB") {

                        $datos_ob = get_datos_ob($id_solicitud, $db);
                        set_session_varname("espejo", $datos_ob->fields['ESPEJO']);
                    ?>
                    <tr>
                        <td><b># Espejo:&nbsp;</b></td>
                        <td class="label"><?= $datos_ob->fields['ESPEJO'] ?></td>
                    </tr>
                    <tr>
                        <td><b>PCN:&nbsp;</b></td>
                        <td class="label"><?= $datos_ob->fields['PCN'] ?></td>
                    </tr>
                    <tr>
                        <td><b>Selecci&oacute;n 1:&nbsp;</b></td>
                        <td class="label"><?= $datos_ob->fields['PREGUNTA'] ?></td>
                    </tr>
                    <tr>
                        <td><b>Selecci&oacute;n 2:&nbsp;</b></td>
                        <td class="label"><?= $datos_ob->fields['RESPUESTA'] ?></td>
                    </tr>
                    <?php
                    }
                    ?>


                    <tr class="label" align="middle">
                        <td class="label">

                            <?php $contador = 1;?>
                            <input type="button" class="btn btn-primary btn-nuevo_diseno" id="btnMarcar<?= $contador ?>"
                                value="Marcar tel. <?php echo $contador; ?>"
                                onclick="AbreVentana(this, <?= $contador ?>, '<?php echo $nomina ?>','<?php echo  $telefono; ?>','<?php echo $id_solicitud; ?>',<?php echo $extenagente; ?>,'<?= $cc ?>','<?php echo $u_telefono; ?>', <?= isset($datos_cliente[0]['U_ZONA']) ? $datos_cliente[0]['U_ZONA'] : '';?>);" />
                            <br>
                        <td class="label">Solicitud:</td>
                        <td><input type="text" class="form-control form-control-sm" value="<?= $id_solicitud ?>"
                                readonly></td>


                        <?php
                            $canal= isset($_SESSION["CANAL"]) ? $_SESSION["CANAL"] : '';
                                         echo "<h5 style = 'color:#059500;font-weight: bold;'>". $canal ."</h5>";
                               ?>

                        <form id="formulario_contacto">
                            <input type="hidden" id="12" value="<?=$id_solicitud?>" />
                            <input type="hidden" id="34"
                                value="<?=isset($datos_cliente[0]['U_ZONA']) ? $datos_cliente[0]['U_ZONA'] : '';?>" />
                            <input type="hidden" id="valorcuestionario" value="" />
                        </form>
                        <input type="hidden" id="tel_0<?= $contador ?>" />
            </td>
        </tr>

        <?php if(isset($datos_cliente[0]['OFERTA']) && $datos_cliente[0]['OFERTA'] != ''){ ?>
        <tr>
            <td colspan="2" class="label">
                <font color="red" zice="20"><?=$datos_cliente[0]['OFERTA']?></font>
            </td>
        </tr>
        <?php } ?>
        <tr>
            <td colspan="1" class="label">
                <font color="red" zice="20">Medio:&nbsp;</font>
            </td>

            <td colspan="1" class="label">
                <font color="red" zice="20"><?= isset($_SESSION["MEDIO"]) ? $_SESSION["MEDIO"] : '';?>
                </font>
            </td>
        </tr>

    </table>
    </td>
    <?php endif; ?>




    </tr>
    <tr>
        <td>

            <?php if ($id_producto  == 1) :?>
            <div id="result">
                <table class="indicadores">
                    <tr class="indicadores">
                        <th colspan="8" class="indicadores">Prescreening</th>
                    </tr>
                    <tr class="indicadores" style="background: #006666;">
                        <td>
                            <font color='#FFFFFF'>Score</font>
                        </td>
                        <td>
                            <font color='#FFFFFF'>Permiso Operaci&oacute;n</font>
                        </td>
                    </tr>
                    <tr class="indicadores">
                        <td class="indicadores">&nbsp</td>
                        <td class="indicadores">&nbsp</td>
                    </tr>
                </table>
            </div>
            <?php endif; ?>




            <?php if ($id_producto  == 100) :?>
            <div class="table-container">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th scope="col">Campo</th>
                            <th scope="col">Informacion</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Solicitud</td>
                            <td><?php echo $datos_inicio->fields['SOLICITUD'] ?? ''; ?></td>
                        </tr>
                        <tr>
                            <td>Nombre de Titular</td>
                            <td><?php echo $datos_inicio->fields['NOMBRE_CLIENTE']?? ''; ?></td>
                        </tr>
                        <tr>
                            <td>URN</td>
                            <td><?php echo $datos_inicio->fields['URN'] ?? '';?></td>
                        </tr>
                        <tr>
                            <td>CANAL DE BASE</td>
                            <td><?php echo $datos_inicio->fields['CANAL']?? ''; ?></td>
                        </tr>
                        <tr>
                            <td>MEDIO</td>
                            <td><?php echo $datos_inicio->fields['MEDIO_'] ?? '';?></td>
                        </tr>

                        <tr>
                            <td>Autenticacion</td>
                            <td><?php echo $datos_inicio->fields['AUTENTICACION'] ??'';?></td>
                        </tr>

                        <tr>
                            <td>El seguro Apoyo Hospitalario</td>
                            <td><?php
                                        if($edad > 64)
                                        echo "NO APLICA";
                                    else
                                        echo "SI APLICA";
                            ?></td>
                        </tr>
                        <tr>
                            <td>El Amex Guard</td>
                            <td><?php 
                                        if($edad > 69)
                                        echo "NO APLICA";
                                    else
                                        echo "SI APLICA";
                            ?></td>
                        </tr>
                        <tr>
                            <td>Info</td>
                            <td><?php echo $datos_inicio->fields['OFERTA'] ?? ''; ?></td>
                        </tr>
                        <tr>
                            <td>Score buro</td>
                            <td><?php echo $datos_inicio->fields['SCORE_BURO'] ?? ''; ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <br>

            <table class="table table-bordered">
                <tbody>
                    <tr>
                        <td><strong>AGENTE:</strong> <?php echo $datos_agentesuper-> fields['AGENTE']?></td>
                        <td><strong>SUPERVISOR:</strong><?php echo $datos_agentesuper-> fields['SUPERVISOR']?></td>
                    </tr>
                </tbody>
            </table>

            <?php endif; ?>

            <div id="btnresult">
            </div>
        </td>
    </tr>
    <?php
if($tipo_zona == 'OB') {
?>
    <tr>
        <td>
            <input name="producto_ob" checked type="radio" value="<?=$id_producto?>"
                onchange="$('#cuestionario<?=$id_producto?>').show(); $('#cuestionario100').hide();" />Producto
            <?=$id_producto?><br>
            <input name="producto_ob" type="radio" value="100"
                onchange="$('#cuestionario<?=$id_producto?>').hide(); $('#cuestionario100').show();" />Producto
            100<br>
        </td>
    </tr>
    <?php
}
?>
    <tr>
        <td colspan="2">
            <table border="0" width="100%">
                <tr>
                    <td colspan="2">

                        <?php
        $array_ob = ($tipo_zona == 'OB') ? array($id_producto, 100) : array($id_producto);
        ?>
                        <?php
        foreach($array_ob as $name => $value){
        ?>
                        <div id="cuestionario<?=$value?>" style="display:none;">
                            <?php

                            $rs = es_grabada($id_solicitud, $db);


                            if ((!$rs->EOF || $tipo_zona == 'EV' || $tipo_zona == 'OB') && $id_producto == 1) {
                              if($tipo_zona == 'EV') {
                                  $datos_grabados = get_datos_long_app($id_solicitud, $db);
                              } else if($tipo_zona == 'OB') {
                                  $datos_grabados = get_datos_grabados(get_session_varname("espejo"), $value, $db); //PRODUCTOS
                              } else {
                                  $datos_grabados = get_datos_grabados($id_solicitud, $value, $db); //PRODUCTOS
                              }
                            
                              foreach ($datos_grabados as $key => $value) {
                                  $RESP[$value['QUESTIONID']][$value['CHOICEID']] = $value['TEXTANSWER'] == null ? '' : $value['TEXTANSWER'];
                              }
                            
                              $xslDoc = new DOMDocument();
                              $xslDoc->load("modules/agentes/catalogo.xsl");
                            
                              $xmlDoc = new DOMDocument();
                              $xmlDoc->load("modules/agentes/cuestionario_" . $id_producto . ".xml");
                            
                              $proc = new XSLTProcessor();
                              $proc->importStylesheet($xslDoc);
                            
                                foreach ($datos_grabados as $key => $value) {
                                  $proc->setParameter(
                                      '',
                                    'RESP_' . $value['QUESTIONID'] . '_' . $value['CHOICEID'],
                                    $RESP[$value['QUESTIONID']][$value['CHOICEID']]
                                  );
                              }
                              $proc->setParameter('', 'INICIO', $inicio);
                            
                              echo $proc->transformToXML($xmlDoc);          
                            } else {
                                $datos_complementarios = get_datos_complementarios($id_solicitud, $db); 

                                $NOMBRE_1 = $datos_cliente[0]['NOMBRE'];
                                $NOMBRE_2 = "";
                                $PATERNO = $datos_cliente[0]['APATERNO'];
                                $MATERNO = $datos_cliente[0]['AMATERNO'];
                                $LADA = $datos_cliente[0]['CLAVELADA'];
                                $TELEFONO = $datos_cliente[0]['TELEFONO'];

                                $DIRECCION = isset($datos_complementarios->fields['DIRECCION']) ? $datos_complementarios->fields['DIRECCION'] : '';
                                $CP = isset($datos_complementarios->fields['CP']) ? $datos_complementarios->fields['CP'] : '';
                                $COLONIA = isset($datos_complementarios->fields['COLONIA']) ? $datos_complementarios->fields['COLONIA'] : '';
                                
                                $xslDoc = new DOMDocument();
                                $xslDoc->load("modules/agentes/catalogo_bk.xsl");

                                $xmlDoc = new DOMDocument();
                                $xmlDoc->load("modules/agentes/cuestionario_" . $id_producto . ".xml");

                                $proc = new XSLTProcessor();
                                $proc->importStylesheet($xslDoc);
                                $proc->setParameter('', 'NOMBRE_1', $NOMBRE_1);
                                $proc->setParameter('', 'NOMBRE_2', $NOMBRE_2);
                                $proc->setParameter('', 'PATERNO', $PATERNO);
                                $proc->setParameter('', 'MATERNO', $MATERNO);
                                $proc->setParameter('', 'LADA', $LADA);
                                $proc->setParameter('', 'TELEFONO', $TELEFONO);
                                $proc->setParameter('', 'DIRECCION', $DIRECCION);
                                $proc->setParameter('', 'CP', $CP);
                                $proc->setParameter('', 'COLONIA', $COLONIA);
                                $proc->setParameter('', 'INICIO', $inicio);
                                
                                echo $proc->transformToXML($xmlDoc);
                            }
                            ?>
                        </div>

                        <?php
}
?>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">&nbsp;</td>
                </tr>
            </table>
        </td>
        <td colspan>
            <div id="script" align="center" class="script"></div>&nbsp;
        </td>
    </tr>
    <tr>
        <td colspan="2">&nbsp;</td>
    </tr>
    </table>

    <?php
    if ($id_producto == 100):?>
    <!--SELECT PARA OBTENER MENSAJERIA-->
    <select style="display: none;" name="txtQId1001CId4">
        <option value=""></option>
        <option value="S">SI</option>
        <option value="N">NO</option>
    </select>
    <?php endif; ?>

</form>
<div valign="bottom" id="dial-layer" style="display:none">
    <script>
    document.write(
        "<iframe src='modules.php?mod=agentes&op=marcacion' id='dial' name='dial' align='right' scrolling='no' frameborder='0' width='10%' height='10%'>"
    );
    document.write("</iframe>");

    function funcion_cancelacion(boton) {
        let valor = boton.value;
        if (valor == 0) {
            texto = "¿Estas Seguro de quitar la razon de cancelacion?";
        } else {
            texto = "¿Estas Seguro de Cancelar la Solicitud?";
        }
        swal({
                title: texto,
                text: `La solicitud en turno es: ${customer_id}`,
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "SI!",
                cancelButtonText: "NO!",
                closeOnConfirm: false,
                closeOnCancel: false
            },
            function(isConfirm) {
                if (isConfirm) {

                    if (valor == 0) {
                        swal("Exitoso", "Tu nota de validacion se ha quitado", "success");
                    } else {
                        swal({
                                title: "Agregar Nota de Cancelacion",
                                text: "<div class='swal-textarea-container'><textarea id='nota' class='swal-textarea'></textarea></div>",
                                html: true,
                                showCancelButton: true,
                                closeOnConfirm: false,
                                closeOnCancel: true
                            },
                            function(isConfirm) {
                                if (isConfirm) {
                                    var nota = document.getElementById('nota').value;

                                    $.post("modules.php?mod=agentes&op=process_data&act=OTc=", {
                                        customer_id,
                                        survey_id: 1,
                                        valor,
                                        nota
                                    }, function(data) {
                                        swal("Nota Registrada", "Tu nota: " + nota, "success");

                                        window.location.href = (
                                            "modules.php?mod=agentes&op=process_data&act=MTAw");

                                    });
                                }
                            });
                    }
                } else {
                    swal("Cancelado", "Operacion Cancelada", "error");
                }
            });
    }
    </script>
</div>

<div id="indicador" title="Indicadores">
    <iframe src="" width="100%" height="320" frameborder="0" id="iframeind">
        <p>El navegador no soporta IFrames.</p>
    </iframe>
</div>
<script>
$("#cuestionario<?=$id_producto?>").show();
<?php
    if($tipo_zona == 'OB') {
?>

$("input[name='btn_save'],input[name='btn_continue']").hide();

$("input[name='txtQId1001CId57']").each(function() {
    this.size = 50;
});
<?php
    }
?>

/* $('#btn_save').parent().prepend(
    '<span style="display: inline-block;float: left;background-color: #fb8c00;padding: 0.3rem 2rem;border-radius: 4px;">Score Buro Actual: ' +
    '<span id="spanSB" style="background-color: #000;color: #fff;display: inline-block;padding: 0 0.2rem;border-radius: 4px;"><? //echo $sb; ?></span> ' +
    '</span>'
); */

$('#btn_save').parent().prepend(
    '<span id="spanTK"><?php echo $tkn; ?></span>'
);
</script>

<style>
.swal-textarea-container {
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    width: 100%;
}

.swal-textarea {
    width: 100%;
    height: 100px;
    margin-top: 10px;
}


.table-container {
    max-height: 300px;
    overflow-y: auto;
    border: 1px solid #ccc;
    padding: 10px;
}
</style>
<?php
layout_footer();
?>