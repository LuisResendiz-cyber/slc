<?php


require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("agente,supervisor", "Resultado de la Busqueda");
layout_menu($db, "");

$tipo = $_POST['tipo'];
$solicitud = (!empty($_POST['solicitud']) ? $_POST['solicitud'] : null);
$nombre = (!empty($_POST['nombre']) ? $_POST['nombre'] : null);
$paterno = (!empty($_POST['paterno']) ? $_POST['paterno'] : null);
$materno = (!empty($_POST['materno']) ? $_POST['materno'] : null);
$clave = (!empty($_POST['clave']) ? $_POST['clave'] : null);
$rfc = (!empty($_POST['rfc']) ? $_POST['rfc'] : null);
$telefono = (!empty($_POST['telefono']) ? $_POST['telefono'] : null);
$busqueda = $_POST['busqueda'];
$agente = $_SESSION['s_usr_id'];

/*if ($tipo != 3) {
    $registros = set_busca_datos($solicitud, $nombre, $paterno, $materno, $clave, $rfc, $telefono, $tipo, $agente, $db);
} else {*/
    $registros = set_busca_datos2($db, $solicitud, $nombre, $paterno, $materno, $clave, $rfc, $telefono, $tipo, $agente, $busqueda);
//}
?>
<input type="button" value="Buscar otro cliente..." onclick="history.back();">
<br>
<div id="resp_act" style="display:none"><img src="<?= $linkpath ?>includes/imgs/loading.gif"></div>
<?php
if (!$registros->EOF) {
    echo "<table border=\"1\">\r\n";
    echo "<tr>\r\n";
    foreach ($registros->fields as $name => $value) {
  	   echo "<th>$name</th>\r\n";
    }
    echo "</tr>\r\n";
    $reg == 0;
    while (!$registros->EOF) {
        if (($reg++ % 2) == 0)
            $color = "White";
        else
            $color = "Silver";
        echo "<tr valign=\"middle\" bgcolor=\"$color\">\r\n";
        foreach ($registros->fields as $name => $value) {
            if ($name == "Status Registro" && $value == "RESERVADO") {
                echo "<td><input type=\"button\" value=\"Liberar\" onclick=\"liberar_registro({$registros->fields['Solicitud']});\"></td>\r\n";
            } else {
                echo "<td>$value</td>\r\n";
            }
        }
        echo "</tr>\r\n";
        $registros->MoveNext();
    }
    echo "</table>\r\n";
}

layout_footer();
?>
