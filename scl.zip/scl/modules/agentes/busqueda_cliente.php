<?php
# @uthor Mark
# Index File on agente module

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("agente","Busqueda de Clientes");

if(get_session_varname("log_registro") === 3){
    set_session_varname('log_registro',3);
}else{
    set_session_varname('log_registro',3);
    set_evento_registro(get_session_varname("s_usr_id"),-1,'CONSULTA BUSQUEDA',$db);
}
$estatus  = 0;

if (isset($_REQUEST["e"])) { 
    $tipo_standby = $_REQUEST["e"];
    $estatus = $_REQUEST["e"];
    
    set_session_varname("tipo_standby", 9);
    
    if($estatus == 9){
        $msg = 'Regreso de Busqueda';
    }         
}
    
set_session_varname("tipo_standby", 9);
    
    if($estatus == 9){
        $msg = 'Regreso de Busqueda';
    }     
    


layout_menu($db);
?>

<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#">Agentes</a></li>
        <li class="breadcrumb-item active" aria-current="page">Busqueda de Clientes</li>
    </ol>
</nav>


<form method="post" action="modules.php?mod=agentes&op=resultado_busq_cliente" name="frm1">
    <table class="text" border="0">









        <tr>


            <td width="60%">

                <table border="0">
                    <tr>
                        <td colspan="3">&nbsp;</td>
                    </tr>
                    <tr>
                        <td colspan="2">Introduzca alguno de los campos para realizar la b&uacute;squeda.</td>
                    </tr>
                    <tr>
                        <td colspan="3">
                            <table border="0">
                                <tr>
                                    <td class="textleft"><b>Solicitud: </b></td>
                                    <td><input type="text" class="form-control" size="20" name="solicitud" id="solicitud" maxlength="10">
                                    </td>
                                </tr>
                                <tr>
                                    <td class="textleft"><b>Nombre: </b></td>
                                    <td><input type="text" class="form-control" size="20" name="nombre" id="nombre" maxlength="20"></td>
                                </tr>
                                <tr>
                                    <td class="textleft"><b>Apellido Paterno:</b>
                                    <td><input type="text" class="form-control" size="20" name="paterno" id="paterno" maxlength="20"></td>
                                </tr>
                                <tr>
                                    <td class="textleft"><b>Apellido Materno:</b>
                                    <td><input type="text" class="form-control" size="20" name="materno" id="materno" maxlength="20"></td>
                                </tr>
                                <tr>
                                    <td class="textleft"><b>N&uacute;mero Telef&oacute;nico: </b>
                                    <td><input type="text" class="form-control" size="10" name="telefono" id="telefono" maxlength="10"></td>
                                </tr>
                            </table>
                            <br>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="3">
                            <input type="button" class="btn btn-success btn-nuevo_diseno" value="Buscar"
                                onclick="BuscarCliente(this)" />&nbsp;&nbsp;
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</form>
<?
layout_footer();
?>