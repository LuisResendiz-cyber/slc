<?php
# @uthor Mark  
# codigos_postales File

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("agente","Codigos Postales");

$p_cp = $_REQUEST["p_cp"]; 
$act = (isset($_REQUEST['act']) && $_REQUEST['act'] == 10?$_REQUEST['act']:1);

?>
	<form method="post" action="modules.php?mod=agentes&op=codigos_postales&act=10" name="frm1">
	<p class="textbold">Busqueda de Codigo Postal</p>
	<p>&nbsp;</p>
	<p>Ingresa el codigo postal y da click en el boton buscar.</p>
	<br>
	<table border="0">
		<tr>
			<td><b>Codigo Postal:&nbsp;</b></td>
			<td colspan="3"><input type="text" name="p_cp" value="<?=$p_cp?>" size="6" maxlength="5"></td>
		</tr><tr>
			<td colspan="2"><input type="button" value="Cancelar" onclick="cancela_cp()"/></td>
			<td colspan="2"><input type="button" value="Continuar" onclick="valida_cp()"/></td>
		</tr>
	</table>
	<hr>
	
	<?
	if($act == 10){		
		echo '<table border="0">
			<tr style="font-weight:bold">
				<td colspan="9">Resultados</td>
			</tr><tr style="font-weight:bold">
				<td>Codigo Postal</td>
				<td>&nbsp;</td>
				<td>Colonia</td>
				<td>&nbsp;</td>
				<td>Municipio</td>
				<td>&nbsp;</td>
				<td>Ciudad</td>
				<td>&nbsp;</td>
				<td>Estado</td>
				<td>&nbsp;</td>
				<td>Acci�n</td>
			</tr>';
		$registros_cp = get_datos_cp($p_cp, $db);
		$i = 1;
		while(!$registros_cp->EOF) {
			if ($i % 2 == 1) $color = "silver"; else $color = "white";
			echo '<tr bgcolor="'.$color.'">
					<td align="center">'.$registros_cp->fields["CP"].'</td>
					<td>&nbsp;</td>
					<td>'.$registros_cp->fields["COLONIA"].'</td>
					<td>&nbsp;</td>
					<td>'.$registros_cp->fields["MUNICIPIO"].'</td>
					<td>&nbsp;</td>
					<td>'.$registros_cp->fields["CIUDAD"].'</td>
					<td>&nbsp;</td>
					<td>'.$registros_cp->fields["ESTADO"].'</td>
					<td>&nbsp;</td>
					<td><a href="#" onclick="resultados_cp(\''.$registros_cp->fields["ID_CODIGO"].'\',\''.$registros_cp->fields["CP"].'\',\''.$registros_cp->fields["COLONIA"].'\',\''.$registros_cp->fields["MUNICIPIO"].'\',\''.$registros_cp->fields["ESTADO"].'\')"><img src="'.$linkpath.'includes/imgs/calcula.jpg" width="18px"></a></td>
				</tr>';
			$registros_cp->MoveNext();
			$i++;
		}
		echo '</table>';
	}
	?>
	</form>
	<br><br>
	<b>Impulse Telecom</b>