<?php
# @uthor Mark
# resultado_busq_cliente File

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("agente","Resultado de la Busqueda");
layout_menu($db,"");

$solicitud = ($_REQUEST['solicitud'] != null?$_REQUEST['solicitud']:0);
$nombre = $_REQUEST['nombre'];
$paterno = $_REQUEST['paterno'];
$materno = $_REQUEST['materno'];
$agente = $_SESSION['s_usr_id'];
$registros = set_busca_cliente($solicitud, $nombre, $paterno, $materno, $agente, $db);

if($registros->EOF){
    $encontro = 0;
}else{
    $encontro = 1;
}

?>
<p class="textbold">Agentes &gt; Resultado de la Busqueda</p>
<p>&nbsp;</p>
<form method="post" name="frm1" action="#">
<input type="hidden" name="u_persona" id="u_persona" readonly>
<input type="hidden" name="u_registro" id="u_registro" readonly>
<table class="text" border="0">
    <tr>
        <td><b>Detalles del Cliente</b></td>
    </tr><tr>
        <td>&nbsp;</td>
    </tr><tr>
        <td>
<?      if($encontro ==1){      ?>
            <table border="1">
                <tr style="font-weight:bold;" align="center" bgcolor="#99CCFF">
                    <td>SOLICITUD</td>
                    <td>NOMBRE</td>
                    <td>ESTADO</td>
                    <td>ACCI&Oacute;N</td>
                </tr>
                <?
                $s = 0;
                while(!$registros->EOF) {
                    echo '<tr bgcolor="'.$color = ($s%2 == 1 ?"#99CCFF":"#FFFFFF").'">
                            <td class="textleft">'.$registros->fields["U_PERSONA"].'</td>
                            <td class="textleft">'.$registros->fields["NOMBRE"].'</td>
                            <td class="textleft">'.$registros->fields["COMENTARIO"].'</td>
                            <td align="center">
                                <a href="#" onclick="mostrar_registro('.$registros->fields["BANDERA"].','.$registros->fields["U_PERSONA"].','.$registros->fields["REGISTRO"].',\''.encripta(3).'\')">
                                    <img src="'.$linkpath.'includes/imgs/'.($registros->fields["BANDERA"]==0?'Comenzar.gif':'Terminar.gif').'">
                                 </a>
                            </td>
                        </tr>';
                    $registros->MoveNext();
                    $s++;
                }
                ?>
            </table>
<?      }else{      ?>
            <table>
                <tr>
                    <td>La b&uacute;squeda que ingreso no genero ning&uacute;n resultado int&eacute;ntelo nuevamente.</td>
                </tr>
            </table>
<?      }       ?>
        </td>
    </tr><tr>
        <td>&nbsp;</td>
    </tr><tr>
	<td>
            <input type="button" value="Regresar" onclick="Atras()" />
            <!--input type="button" value="Nuevo" onclick="nuevo_registro(1)" /-->
        </td>
    </tr>
</table>
</form>
<?
layout_footer();
?>