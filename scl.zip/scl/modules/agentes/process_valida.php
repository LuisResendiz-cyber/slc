<?php
require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize_nolayout("agente","");

$action = desencripta($_REQUEST['act']);
$header = "index.php";
if(isset($action) && $action == 21){ ##### OBTIENE UN REGISTRO Y RECUPERA EL NUMERO DE SOLICITUD ##
    $id_registro = get_session_varname('id_registro');
    $count_valida = set_valida_solicitud_capturada($id_registro, $db);
    die($count_valida);
}
?>