<html>
<body>

<table border="1" width="400" height="250">
  <tr>
    <td width="100%">
    <applet 
        CODEBASE="Demonio.jar"
        CODE="Demonio.class"
        WIDTH="640"
        HEIGHT="480"
        HSPACE="0"
        VSPACE="0"
        ALIGN="middle"
        ALT="Lo siento no puede ver el applet">
    </applet>
    </td>
  </tr>
</table>

</body>
</html>
