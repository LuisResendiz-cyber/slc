<div id="test">
TEST OK...
<!--script>
	alert("TEST OK...");
</script-->
</div>