<?php
require_once('includes/includes.inc.php');
require_once('agentes.inc.php');

initialize("agente", "");

if (isset($_POST['cmdSave'])) {
    try {
        set_notas(get_session_varname("s_usr_id"), $_POST['txt_nota'], $db);
        echo "Notas guardadas correctamente.";
    } catch (Exception $e) {
        echo "Error al intentar guardar notas: " . $e->getMessage();
    }
}

$rsNota = get_notas(get_session_varname("s_usr_id"), $db);


if ($rsNota->EOF)
    $nota = '';
else
    $nota = $rsNota->fields['NOTA'];
?>


<form name="frmNotas" action="modules.php?mod=agentes&op=notas" method="POST">
    <table align="left">
        <tr>
            <td>
                <font color="Blue" size="2"><b>Notas Personales</b></font>
            </td>
        </tr>
        <tr>
            <td valign="top">
                <textarea name="txt_nota" cols="40" rows="12" style="font-size:12pt;"><?php echo $nota ?></textarea>
            </td>
        </tr>
        <tr>
            <td>
                <input type="submit" name="cmdSave" value="Guardar" style="font-size:8pt;">
            </td>
        </tr>
    </table>
</form>