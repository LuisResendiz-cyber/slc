<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=utf-8">
	<TITLE></TITLE>
	<META NAME="GENERATOR" CONTENT="LibreOffice 3.5  (Linux)">
	<META NAME="AUTHOR" CONTENT="calidad.atento10">
	<META NAME="CREATED" CONTENT="20150813;22560000">
	<META NAME="CHANGEDBY" CONTENT="Ascenci&oacute;n Madrigal">
	<META NAME="CHANGED" CONTENT="20150824;15590000">
	<META NAME="AppVersion" CONTENT="15.0000">
	<META NAME="Company" CONTENT="CC MONTERREY">
	<META NAME="DocSecurity" CONTENT="0">
	<META NAME="HyperlinksChanged" CONTENT="false">
	<META NAME="LinksUpToDate" CONTENT="false">
	<META NAME="ScaleCrop" CONTENT="false">
	<META NAME="ShareDoc" CONTENT="false">
	<STYLE TYPE="text/css">
	<!--
		@page { margin: 1.27cm }
		P { margin-bottom: 0.21cm; direction: ltr; color: #000000; widows: 2; orphans: 2 }
		A:link { color: #0000ff; so-language: zxx }
	-->
	</STYLE>
</HEAD>
<BODY LANG="es-MX" TEXT="#000000" LINK="#0000ff" DIR="LTR">
<P STYLE="margin-bottom: 0.35cm"><A NAME="_GoBack"></A><BR><BR>
</P>
<CENTER>
	<TABLE WIDTH=726 CELLPADDING=1 CELLSPACING=0>
		<COL WIDTH=724>
		<TR>
			<TD WIDTH=724 STYLE="border: none; padding: 0cm">
				<P ALIGN=CENTER STYLE="margin-bottom: 0cm"><FONT FACE="Arial, serif"><FONT SIZE=2><B>Script
				Inicio</B></FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><B>
				Ayuda Hospitalaria Bancomer</B></FONT></FONT></P>
				<P ALIGN=CENTER><BR>
				</P>
			</TD>
		</TR>
		<TR>
			<TD WIDTH=724 STYLE="border: none; padding: 0cm">
				<P ALIGN=CENTER><BR>
				</P>
			</TD>
		</TR>
		<TR>
			<TD WIDTH=724 STYLE="border: none; padding: 0cm">
				<P STYLE="margin-bottom: 0cm"><FONT FACE="Arial, serif"><FONT SIZE=2>Buenas
				tardes Sr./Sra./Srita </FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><U><B>Nombre
				Completo Cliente</B></U></FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><B>
				</B></FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2>Mi
				nombre es: </FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><B>**</B></FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><U><B>Nombre
				Agente</B></U></FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><B>**
				</B></FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2>me
				comunico de Seguros Bancomer. <BR><BR>Es un placer
				notificarle/comentarle Sr./Sra./Srita </FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><U><B>apellido
				cliente</B></U></FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2>
				que el d&iacute;a de hoy gracias a que es </FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><B>un
				cliente MUY importante Bancomer, </B></FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2>tiene
				la oportunidad de acceder directamente a nuestro </FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2>Respaldo</FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><B>
				Econ&oacute;mico </B></FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2>llamado</FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><B>
				</B></FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2>Ayuda
				Hospitalaria</FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><B>,
				</B></FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2>la cual
				le brinda solvencia econ&oacute;mica, es decir; </FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><B>dinero
				para su beneficio</B></FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2>,
				ya que usted recibir&aacute; </FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><B>$1000</B></FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2>
				/ $500 diarios por hospitalizaci&oacute;n ante eventualidad de alg&uacute;n
				accidente cubierto por m&aacute;s de 24 horas consecutivas hasta 180
				d&iacute;as con un costo/prima mensual de $100.87 </FONT></FONT>
				</P>
				<P STYLE="margin-bottom: 0cm"><BR>
				</P>
				<P STYLE="margin-bottom: 0cm"><FONT FACE="Arial, serif"><FONT SIZE=2>Este
				servicio se liga autom&aacute;ticamente a su cuenta (libreton/Cr&eacute;dito)
				para su mayor comodidad y Usted puede aprovechar esta gran
				oportunidad en este momento, &uacute;nicamente debe cumplir con el
				rango de edad que va de los 18 a 65 a�os.</FONT></FONT></P>
				<P STYLE="margin-bottom: 0cm"><FONT FACE="Arial, serif"><FONT SIZE=2>Para
				validar esta posibilidad y pueda gozar de este apoyo econ&oacute;mico,
				</FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><B>cual es
				su fecha de nacimiento?/cuando naci&oacute;?/que edad tiene
				actualmente?</B></FONT></FONT></P>
				<P STYLE="margin-bottom: 0cm"><BR>
				</P>
				<P STYLE="margin-bottom: 0cm"><FONT FACE="Arial, serif"><FONT SIZE=2><B>Asentir
				con una frase positiva. (excelente, perfecto, me parece muy bien)</B></FONT></FONT></P>
				<P STYLE="margin-bottom: 0cm"><FONT FACE="Arial, serif"><FONT SIZE=2><B>Realizar
				preguntas de seguridad</B></FONT></FONT></P>
				<P STYLE="margin-bottom: 0cm"><BR>
				</P>
				<P ALIGN=JUSTIFY STYLE="margin-bottom: 0.35cm"><FONT FACE="Arial, serif"><FONT SIZE=2><SPAN STYLE="background: #ffff00">Para
				garantizar la transparencia de nuestros servicios,</SPAN></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Calibri, serif"><FONT SIZE=2><SPAN STYLE="background: #ffff00">.
				Es importante mencionarle que existen algunas exclusiones, por
				ejemplo el uso indebido o il&iacute;cito de una TDC o D&eacute;bito o delitos
				ocasionados intencionalmente por el asegurado.</SPAN></FONT></FONT></FONT></P>
				<P STYLE="margin-top: 0.35cm; margin-bottom: 0cm; page-break-inside: avoid; page-break-after: avoid">
				<BR>
				</P>
				<P STYLE="margin-bottom: 0cm"><FONT FACE="Arial, serif"><FONT SIZE=2><SPAN STYLE="background: #ffff00">Asi
				mismo estar&iacute;a fuera de la cobertura si desempe�a las siguientes
				actividades </SPAN></FONT></FONT>
				</P>
				<OL>
					<LI><P ALIGN=JUSTIFY STYLE="margin-bottom: 0cm"><FONT COLOR="#222222"><FONT FACE="Arial, serif"><FONT SIZE=2><SPAN STYLE="background: #ffff00">Prestar
					servicios en cualquier organismo policiaco, cuerpos militares o
					de marina, de seguridad privada, guardaespaldas o utilizar armas
					para el desempe�o de su trabajo.</SPAN></FONT></FONT></FONT></P>
				</OL>
				<P ALIGN=JUSTIFY STYLE="margin-top: 0.35cm; margin-bottom: 0cm; page-break-inside: avoid; page-break-after: avoid">
				<BR>
				</P>
				<OL START=2>
					<LI><P ALIGN=JUSTIFY STYLE="margin-bottom: 0cm"><FONT COLOR="#222222"><FONT FACE="Arial, serif"><FONT SIZE=2><SPAN STYLE="background: #ffff00">Laborar,
					ser ayudante, auxiliar o similar en rastros, fundiciones, manejo
					de explosivos, ingenier&iacute;a mar&iacute;tima, canteras, erecci&oacute;n de
					andamios, a m&aacute;s de dos pisos de altura, pozos de petr&oacute;leo,
					trabajos subterr&aacute;neos, embarcaderos, alba�il, bombero,
					electricista de alto voltaje o piloto fumigador.</SPAN></FONT></FONT></FONT></P>
				</OL>
				<P ALIGN=JUSTIFY STYLE="margin-left: 0.64cm; margin-top: 0.35cm; margin-bottom: 0cm; page-break-inside: avoid; page-break-after: avoid">
				<BR>
				</P>
				<OL START=3>
					<LI><P ALIGN=JUSTIFY STYLE="margin-bottom: 0cm"><FONT COLOR="#222222"><FONT FACE="Arial, serif"><FONT SIZE=2><SPAN STYLE="background: #ffff00">Ser
					chofer de transporte de carga de materiales peligrosos o
					inflamables u operar camiones de volteo, palas mec&aacute;nicas o
					buldozer.</SPAN></FONT></FONT></FONT></P>
				</OL>
				<P STYLE="margin-left: 1.27cm; margin-bottom: 0.35cm"><BR><BR>
				</P>
				<P ALIGN=JUSTIFY STYLE="margin-bottom: 0cm"><FONT COLOR="#222222"><FONT FACE="Arial, serif"><FONT SIZE=2>Usted
				practica actualmente alguna de las actividades antes mencionadas?</FONT></FONT></FONT></P>
				<P><FONT FACE="Arial, serif"><FONT SIZE=2><B>(En caso de
				mencionar que no, proseguir con la venta)</B></FONT></FONT></P>
			</TD>
		</TR>
		<TR>
			<TD WIDTH=724 STYLE="border: none; padding: 0cm">
				<P ALIGN=JUSTIFY STYLE="margin-bottom: 0.35cm"><BR><BR>
				</P>
				<P ALIGN=JUSTIFY STYLE="margin-bottom: 0.35cm"><FONT COLOR="#000000"><FONT FACE="Calibri, serif"><FONT SIZE=2><SPAN STYLE="background: #ffff00">Otro
				beneficio mas es(MENCIONAR OTRA COBERTURA PRINCIPAL DEL PRODUCTO)</SPAN></FONT></FONT></FONT></P>
				<P ALIGN=JUSTIFY STYLE="margin-bottom: 0.35cm"><BR><BR>
				</P>
				<P ALIGN=JUSTIFY STYLE="margin-right: 0.5cm; margin-bottom: 0.35cm">
				<BR><BR>
				</P>
				<P ALIGN=JUSTIFY STYLE="margin-right: 0.5cm; margin-bottom: 0.35cm">
				<FONT SIZE=2><B><SPAN STYLE="background: #ffff00">----VALIDACI�N-----</SPAN></B></FONT></P>
				<P ALIGN=JUSTIFY STYLE="margin-right: 0.5cm; margin-bottom: 0.35cm">
				<BR><BR>
				</P>
				<P ALIGN=JUSTIFY STYLE="margin-right: 0.5cm; margin-bottom: 0.35cm">
				<FONT SIZE=2><SPAN STYLE="background: #ffff00">Sr. Srta.________
				por una PRIMA MENSUAL de $___________PESOS en este momento est&aacute;
				CONTRATANDO el Plan ___________________con cargo a su Tarjeta
				Terminaci&oacute;n XXXX �De acuerdo?</SPAN></FONT></P>
				<P ALIGN=JUSTIFY STYLE="margin-right: 0.5cm; margin-bottom: 0.35cm">
				<BR><BR>
				</P>
				<P ALIGN=JUSTIFY STYLE="margin-bottom: 0.35cm"><FONT COLOR="#000000"><FONT FACE="Calibri, serif"><FONT SIZE=2><SPAN STYLE="background: #ffff00">(S&iacute;,
				est&aacute; bien, muy bien, de acuerdo, ok, por supuesto, perfecto,
				adelante, claro) Si no es una aceptaci&oacute;n v&aacute;lida, se deber&aacute;
				reformular con �Puedo tomar su respuesta como un s&iacute;?</SPAN></FONT></FONT></FONT></P>
				<P ALIGN=JUSTIFY STYLE="margin-right: 0.5cm; margin-bottom: 0.35cm">
				<BR><BR>
				</P>
				<P ALIGN=JUSTIFY STYLE="margin-bottom: 0.35cm"><FONT COLOR="#000000"><FONT FACE="Calibri, serif"><FONT SIZE=2><SPAN STYLE="background: #ffff00">Le
				menciono que la renovaci&oacute;n es autom&aacute;tica y la vigencia de su
				p&oacute;liza comenzar&aacute; a partir de las </SPAN></FONT></FONT></FONT><FONT FACE="Calibri, serif"><FONT SIZE=2><SPAN STYLE="background: #ffff00">12
				horas del d&iacute;a h&aacute;bil siguiente</SPAN></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Calibri, serif"><FONT SIZE=2><SPAN STYLE="background: #ffff00">al
				que se efect&uacute;e el cargo a su tarjeta y a partir de ese momento
				la mensajer&iacute;a estar&aacute; pasando de 10 a 17 d&iacute;as h&aacute;biles para
				hacerle entrega de su p&oacute;liza al domicilio que tenemos
				registrado, Mientras tanto su n&uacute;mero de tarjeta ser&aacute; su
				identificador provisional en caso de tener alguna duda o
				necesitar alg&uacute;n tr&aacute;mite, mismos que podr&aacute; consultar en los
				tel&eacute;fonos 01800 849 66 00 y 11 02 00 00 desde el D. F. Opcional:
				As&iacute; mismo, en caso que necesite reportar alg&uacute;n siniestro lo
				puede hacer al 01 800 830 99 11.</SPAN></FONT></FONT></FONT></P>
				<P ALIGN=JUSTIFY STYLE="margin-right: 0.5cm; margin-bottom: 0.35cm">
				<BR><BR>
				</P>
				<P ALIGN=JUSTIFY STYLE="margin-right: 0.5cm; margin-bottom: 0.35cm">
				<BR><BR>
				</P>
				<P ALIGN=JUSTIFY STYLE="margin-right: 0.5cm; margin-bottom: 0.35cm">
				<FONT SIZE=2><SPAN STYLE="background: #ffff00">Seguros BBVA
				Bancomer, Montes Urales 424, Colonia Lomas&nbsp;de&nbsp;Chapultepec,
				Delegaci&oacute;n Miguel Hidalgo, C&oacute;digo Postal 11000, D.F. recaba sus
				datos para verificar su identidad. El&nbsp;aviso&nbsp;de
				Privacidad&nbsp;Integral actualizado est&aacute;
				en&nbsp;www.segurosbancomer.com.mx.</SPAN></FONT></P>
				<P><BR>
				</P>
			</TD>
		</TR>
	</TABLE>
</CENTER>
<P STYLE="margin-top: 0.05cm; margin-bottom: 0.05cm"><FONT COLOR="#ff0000"><FONT FACE="Arial, serif"><FONT SIZE=2><B>PARA
VENTA TITULAR, APLICAR: </B></FONT></FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><BR></FONT></FONT><BR><BR>
</P>
<P STYLE="margin-bottom: 0.35cm"><FONT FACE="Arial, serif"><FONT SIZE=2>Le
reitero la importancia de contar con saldo disponible en su cuenta de
manera mensual para el cobro de su cobertura y Ud. cuente con una
protecci&oacute;n continua. <BR><BR>Sr. / Sra. /Srita: </FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><U><B>Nombre
Completo Cliente</B></U></FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><B>
</B></FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2>Agradezco
mucho su tiempo y atenci&oacute;n. Que tenga un(a) excelente d&iacute;a/tarde. Le
atendi&oacute; </FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><B>**</B></FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><U><B>Nombre
Agente</B></U></FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><B>**
</B></FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2> de Seguros
Bancomer.</FONT></FONT></P>
<P STYLE="margin-top: 0.05cm; margin-bottom: 0.05cm"><FONT FACE="Arial, serif"><FONT SIZE=2><B>vENTA
ADICIONAL</B></FONT></FONT></P>
<P STYLE="margin-top: 0.05cm; margin-bottom: 0.05cm"><FONT FACE="Arial, serif"><FONT SIZE=2>Usted
ha tomado una excelente decisi&oacute;n que beneficiara su econom&iacute;a, le
comento finalmente que tiene la oportunidad por &uacute;nica ocasi&oacute;n de
proteger a uno de sus familiares con el mismo apoyo econ&oacute;mico.</FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 100%"><FONT FACE="Arial, serif"><FONT SIZE=2>�sta
persona estar&aacute; recibiendo los mismos beneficios que usted, ya que
recibir&aacute; tambi&eacute;n $1000 diarios por hospitalizaci&oacute;n </FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2>ante
eventualidad de alg&uacute;n accidente cubierto por m&aacute;s de 24 horas
consecutivas hasta 180 d&iacute;as con un costo/prima mensual de $100.87.</FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 100%"><FONT FACE="Arial, serif"><FONT SIZE=2>Estamos
hablando aproximadamente de $200,000 que podr&iacute;an recibir en conjunto
usted y alguno de sus seres queridos.</FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 100%"><FONT FACE="Arial, serif"><FONT SIZE=2>�nicamente,
seria necesario el nombre completo de la persona y su fecha de
nacimiento, quien seria esta persona (agregar frases emp&aacute;ticas:
especial, importante, etc)</FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 100%"><FONT FACE="Arial, serif"><FONT SIZE=2>(</FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2><B>verificar
rango de edad para el adicional</B></FONT></FONT><FONT FACE="Arial, serif"><FONT SIZE=2>)</FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 100%"><BR>
</P>
<UL>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 100%"><FONT FACE="Arial, serif"><FONT SIZE=2>Proseguir
	con la venta de manera normal (t&eacute;rminos y condiciones)</FONT></FONT></P>
</UL>
<P STYLE="margin-bottom: 0cm; line-height: 100%"><BR>
</P>
<P STYLE="margin-top: 0.05cm; margin-bottom: 0.05cm"><FONT FACE="Arial, serif"><FONT SIZE=2>En
caso de que la prima total sobrepase el candado de $100.88,
forzosamente se deber&aacute; indicar el costo total. Ejemplos:</FONT></FONT></P>
<UL>
	<LI><P STYLE="margin-top: 0.05cm; margin-bottom: 0.05cm; line-height: 100%">
	<FONT COLOR="#0000ff"><FONT FACE="Arial, serif"><FONT SIZE=2>Usted
	est&aacute; adquiriendo (</FONT></FONT></FONT><FONT COLOR="#0000ff"><FONT FACE="Arial, serif"><FONT SIZE=2><I>2</I></FONT></FONT></FONT><FONT COLOR="#0000ff"><FONT FACE="Arial, serif"><FONT SIZE=2>)
	p&oacute;liza (s) con un costo total mensual de $126.1 &nbsp; (50.44 +
	75.66)</FONT></FONT></FONT></P>
	<LI><P STYLE="margin-top: 0.05cm; margin-bottom: 0.05cm; line-height: 100%">
	<FONT COLOR="#0000ff"><FONT FACE="Arial, serif"><FONT SIZE=2>Usted
	est&aacute; adquiriendo (</FONT></FONT></FONT><FONT COLOR="#0000ff"><FONT FACE="Arial, serif"><FONT SIZE=2><I>3</I></FONT></FONT></FONT><FONT COLOR="#0000ff"><FONT FACE="Arial, serif"><FONT SIZE=2>)
	p&oacute;liza (s) con un costo total mensual de $151.32 &nbsp;(50.44 +
	50.44 + 50.44)</FONT></FONT></FONT></P>
	<LI><P STYLE="margin-top: 0.05cm; margin-bottom: 0.05cm; line-height: 100%">
	<FONT COLOR="#0000ff"><FONT FACE="Arial, serif"><FONT SIZE=2>Usted
	est&aacute; adquiriendo (</FONT></FONT></FONT><FONT COLOR="#0000ff"><FONT FACE="Arial, serif"><FONT SIZE=2><I>2</I></FONT></FONT></FONT><FONT COLOR="#0000ff"><FONT FACE="Arial, serif"><FONT SIZE=2>)
	p&oacute;liza (s) con un costo total mensual de $151.31 &nbsp;(100.87 +
	50.44)</FONT></FONT></FONT></P>
</UL>
<P STYLE="margin-bottom: 0.35cm"><BR><BR>
</P>
<P STYLE="margin-bottom: 0.35cm"><FONT FACE="Arial, serif"><FONT SIZE=2><B>FRASES
DE ALERTA</B></FONT></FONT></P>
<P STYLE="margin-bottom: 0.35cm"><FONT FACE="Arial, serif"><FONT SIZE=2>En
caso de no aceptar el cliente se realizar&aacute;n despu&eacute;s de los segundos
esfuerzo y el vencimiento de objeci&oacute;n.</FONT></FONT></P>
<P STYLE="margin-top: 0.05cm; margin-bottom: 0.05cm"><FONT FACE="Arial, serif"><FONT SIZE=2><B>�Est&aacute;
de acuerdo en la contrataci&oacute;n del plan&nbsp;XXXX&nbsp;con cargo a su
tarjeta?</B></FONT></FONT></P>
<P STYLE="margin-top: 0.05cm; margin-bottom: 0.05cm"><FONT FACE="Arial, serif"><FONT SIZE=2><B>�Podemos
iniciar con la contrataci&oacute;n del plan&nbsp;XXXX&nbsp;con cargo a su
tarjeta?&nbsp;</B></FONT></FONT></P>
<P STYLE="margin-top: 0.05cm; margin-bottom: 0.05cm"><FONT FACE="Arial, serif"><FONT SIZE=2><B>�Desea
que iniciemos con la contrataci&oacute;n del plan&nbsp;XXXX&nbsp;con cargo
a su tarjeta?</B></FONT></FONT></P>
<P STYLE="margin-top: 0.05cm; margin-bottom: 0.05cm"><FONT FACE="Arial, serif"><FONT SIZE=2><B>�Autoriza
que iniciemos con la contrataci&oacute;n del plan&nbsp;XXXX&nbsp;con cargo
a su tarjeta?</B></FONT></FONT></P>
<P STYLE="margin-bottom: 0.35cm"><BR><BR>
</P>
</BODY>
</HTML>