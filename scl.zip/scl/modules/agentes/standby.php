<?php
# @uthor Mark  
# Error File

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("agente","standby");

$tipo_standby = $_REQUEST["e"];

$estatus = $_REQUEST["e"];

set_session_varname("tipo_standby", $tipo_standby);
layout_menu($db, "");

if($estatus == 1){
    $msg = 'Break';
} else if($estatus == 2) {
    $msg = 'Ba�o';
} else if($estatus == 3) {
    $msg = 'Capacitaci�n';
} else if($estatus == 4) {
    $msg = 'Retroalimentaci�n';
} else if($estatus == 5) {
    $msg = 'Ver Reporter�a';
} else if($estatus == 6) {
    $msg = 'Descanso Forzado';
} else if($estatus == 7) {
    $msg = 'Junta de Arranque';
} else if($estatus == 10) {
    $msg = 'COLGO LINEA <br> PREDICTIVO!!!';
}

?>

<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="#">Agentes</a></li>
    <li class="breadcrumb-item active" aria-current="page">Standby</li>
  </ol>
</nav>


<table border="0">
    <tr>
        <td class="textleft" colspan="2" ><b style="font-size:100px;color:red"><?=$msg?></b></td>
    </tr>
</table>
</form>
<?
layout_footer();
?>
