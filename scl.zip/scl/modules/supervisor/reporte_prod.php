<?php
# reporte_productividad File
# @uthor Mark

require_once("includes/includes.inc.php");

initialize("supervisor","Reportes");
layout_menu($db, "");
?>
<h4>Reportes</h4>
<form name="frm1" method="post" action="process_data.php">
<p id="text">Seleccione el tipo de reporte que desea consultar y d&eacute; clic en el bot&oacute;n continuar<br>
<table width="80%" id="t1" border="0">
    <tr>
        <td>&nbsp;</td>
    </tr><tr>
        <td>
            <table align="center" border="0">
                <tr>
                    <td align="center">Agentes</td>
                    <td>&nbsp;&nbsp;<input type="radio" name="tipo_rep" value="2" checked></td>
                </tr><tr>
                    <td align="center">Supervisor</td>
                    <td>&nbsp;&nbsp;<input type="radio" name="tipo_rep" value="1"></td>
                </tr><tr>
                    <td colspan="2" align="center">&nbsp;</td>
                </tr><tr>
                    <td><b>Tipo</b></td>
                    <td><select name="tipo_reporte">
                            <option value="1">Productividad</option>
                            <option value="2">Canceladas</option>
                        </select>
                    </td>
                </tr><tr>
                    <td colspan="2" align="center">&nbsp;</td>
                </tr><tr>
                    <td colspan="2" align="center"><b>Fecha</b></td>
                </tr><tr>
                    <td align="center">Del:</td>
                    <td align="center">Al:</td>
                </tr><tr>
                    <td align="center">
                        <script language="JavaScript">
                        var SC_SET_1 = {'appearance': SC_APPEARANCE,'dataArea':'fecha_del','dateFormat' : 'd/m/Y'}
                        var fecha = '<?=$registro->fields["FECHA_AGENDADO"]?>';
                        new sCalendar(SC_SET_1,fecha);
                        </script>
                    </td>
                    <td>
                        <script language="JavaScript">
                        var SC_SET_1 = {'appearance': SC_APPEARANCE,'dataArea':'fecha_al','dateFormat' : 'd/m/Y'}
                        var fecha = '<?=$registro->fields["FECHA_AGENDADO"]?>';
                        new sCalendar(SC_SET_1,fecha);
                        </script>
                    </td>
                </tr>
            </table>
            <br>
            <input type="button" value="Cancelar" onclick="Atras()">
            <input type="button" value="Mostrar Reporte" onclick="Mostrar_Reporte()">
        </td>
    </tr><tr>
        <td colspan="2">
        <br>
        <div id="resp_act" style="display:none"><img src="<?=$linkpath?>includes/imgs/loading.gif"></div>
        </td>
    </tr>
</table>
</form>
<?
layout_footer();
?>