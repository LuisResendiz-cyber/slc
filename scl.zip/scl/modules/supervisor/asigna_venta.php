<?php
# Activacion File 
# @uthor Mark
require_once("includes/includes.inc.php");

initialize("nomina,supervisor,validacion,mesa_control,gerente_operacion,gerente_validacion","Reporte de productividad");

layout_menu($db, "");
?>
	<h4>Asignaci�n de Ventas</h4>
	<form name="frm11" method="post" action="process_data.php">
	<p id="text">Busca la solicitud y verifica a que agente esta asignado.<br>
	<p id="text">Si no es el correcto asignale a la solcitud al agente correcto.<br>	
	<table width="30%" id="t1" border="0">
		<tr>
			<td>&nbsp;</td>
		</tr><tr>
			<td colspan="2">&nbsp;</td>
		</tr><tr>
			<td>*Solicitud:</td>
			<td><input type="text" name="id_solicitud" id="id_solicitud" value="" maxlength="10" size="10"></td>
		</tr><tr>
			<td colspan="2">
				<div id="asigna_vent" style="display:none"></div>
			</td>
		</tr>
	</table>
	<br>
	<input type="button" value="Cancelar" onclick="LimpiaDatos()">
	<input type="button" value="Buscar" onclick="Asigna_Venta()">
	<br>
<?
layout_footer();
?>