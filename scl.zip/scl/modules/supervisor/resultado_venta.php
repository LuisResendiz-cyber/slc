<?php
# @uthor Eli

require_once("includes/includes.inc.php");
require_once("supervisor.inc.php");

initialize("supervisor","Reporte de productividad");

layout_menu($db, "");

$s_usr_id = get_session_varname("s_usr_id");
$id_solicitud = $_REQUEST['sol'];	
$busca_sol_asignar = get_buscar_sol_asignar($id_solicitud , $db);
$asigno = $_REQUEST['asigno'];

?>
	<p class="textbold">Supervisor &gt; Registro Venta</p>
	<p>&nbsp;</p>
	<form method="post" action="modules.php?mod=supervisor&op=process_data&act=2" name="frm3">
	<table class="text" border="0">
		<tr>
			<td colspan="3"><b>Solicitud que va a ser Asignada</b></td>
		</tr><tr>
			<td colspan="3">&nbsp;</td>
		</tr><tr>
			<td colspan="3">
				<table>
					<tr style="font-weight:bold;" align="center">
						<td># Solicitud</td>
						<td>&nbsp;</td>
						<td>Nombre del Cliente</td>
						<td>&nbsp;</td>												
						<td>Fecha Venta</td>
						<td>&nbsp;</td>												
						<td>Nomina</td>
						<td>&nbsp;</td>
						<td>Agente</td>
						<td>&nbsp;</td>												
						<td>Nomina Nuevo <br>Agente</td>
						<td>&nbsp;</td>							
					</tr>
					<?									
						while(!$busca_sol_asignar->EOF) {
                            echo '<tr align="center">
                                    <td class="textleft">'.$busca_sol_asignar->fields["ID_SOLICITUD"].'</td>
                                    <td><input type="hidden" name="id_solicitud" id="id_solicitud" value="'.$busca_sol_asignar->fields["ID_SOLICITUD"].'">&nbsp;</td>
                                    <td class="textleft">'.$busca_sol_asignar->fields["MAIN_NOMBRE_COMPLETO"].'</td>
                                    <td>&nbsp;</td>
                                    <td class="textleft">'.$busca_sol_asignar->fields["FECHA_ULTIMO_STATUS"].'</td>
                                    <td>&nbsp;</td>
                                    <td class="textleft">'.$busca_sol_asignar->fields["NOMINA"].'</td>
                                    <td><input type="hidden" name="nomina_ant" id="nomina_ant" value="'.$busca_sol_asignar->fields["NOMINA"].'">&nbsp;</td>
                                    <td class="textleft">'.$busca_sol_asignar->fields["AGENTE"].'</td>
                                    <td>&nbsp;</td>
                                    <td class="textleft"><input type="text" name="nuevo_agente" id="nuevo_agente" value="" maxlength="6" size="6"></td>
                                    <td>&nbsp;</td>
                                </tr>';
                            $busca_sol_asignar->MoveNext();
						}
					?>
					
				</table>			
			</td>			
		</tr><tr>
			<td colspan="3">&nbsp;</td>
		</tr><tr>
			<td>
				<? 	if(isset($asigno) and $asigno ==1){
						echo '<p><font color="blue">La solicitud numero: '.$id_solicitud. '  fue asignada correctamete. </font></p>';
					}elseif(isset($asigno) and $asigno ==2){
						echo '<p><font color="red">El agente que esta capturando no esta dado de alta o no tiene el perfil de Agente. </font></p>';
						echo '<p><font color="red">Verifica el numero de nomina. </font></p>';
					}else if(isset($asigno) and $asigno ==0){
						echo '<p><font color="red">El agente que capturaste es igual al que ya tiene la solicitud.</font></p>';				
					}		
				?>
			</td>
		</tr><tr>
			<td colspan="3">&nbsp;</td>
		</tr><tr>
			<td colspan="3">
				<input type="button" value="Cancelar" onclick="Cancelar()"/>
				<input type="button" value="Asignar Agente" onclick="Nvo_Agente()"/>
			</td>
		</tr>
	</table>
	</form>
<?
layout_footer();
?>