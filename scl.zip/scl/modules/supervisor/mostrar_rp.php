<?php
# Activacion File 
# @uthor Mark

require_once("includes/includes.inc.php");
require_once("supervisor.inc.php");

initialize("nomina,supervisor,validacion,mesa_control,gerente_operacion,gerente_validacion","Reporte de productividad");

layout_menu($db, "");
?>
	<h4>Reporte de productividad por Zona y Etapa</h4>
	<form name="frm1" method="post" action="modules.php?mod=supervisor&op=reporte_prod">
	<p id="text">Resume de reporte de productividad<br></p>	
	<table width="80%" id="t1" border="0">
		<tr>
			<td>&nbsp;</td>
		</tr><tr>		
			<td>
		<?	
			
		foreach ($_POST as $v1 => $v2){
			$com = substr($v1, 0 , 7);
			if($com == 'id_zona'){
				if($j == 0){
					$string_zonas .= $v2;
				}else{
					$string_zonas .= ','.$v2;
				}
				$j++;
			}else if ($com == 'id_etap'){
				if($k == 0){
					$string_etapas .= $v2;
				}else{
					$string_etapas .= ','.$v2;
				}
				$k++;
			}
		}	
	$tipo_reporte = $_REQUEST['tipo_rep'];
	$fecha_del = $_REQUEST['fecha_del'];
	$fecha_al = $_REQUEST['fecha_al'];		
	
	//echo 'Tipo_Reporte: '.$tipo_reporte.'<br>Fecha de:'.$fecha_del.'<br>Fecha al:'.$fecha_al.'<br>Zona:'.strlen($string_zonas).'<br>Etapa:'.strlen($string_etapas).'<br>';	
	$rs_reporte_p = get_reporte_productividad_P($tipo_reporte, $fecha_del, $fecha_al, $string_zonas,$string_etapas, $db);
	if( strlen($string_zonas) > 0 || strlen($string_etapas) > 0 ){
		if (!$rs_reporte_p->EOF){			
			if ($tipo_reporte == 1) {				
				echo 	"<table border='0'>
							<tr style='font-weight:bold'>
								<td>Supervisor</td>
								<td>&nbsp;</td>
								<td>Agente</td>
								<td>&nbsp;</td>							
								<td>Registros <br>Tocados</td>
								<td>&nbsp;</td>												
								<td>Contacto <br> Efectivo</td>		
								<td>&nbsp;</td>
								<td>Actualizados</td>
								<td>&nbsp;</td>	
								<td>Interesados/<br>Promesa de <br>Pagos</td>
								<td>&nbsp;</td>
								<td>Interesados/<br>Promesa de <br>Pagos <br>* Hora</td>								
								<td>&nbsp;</td>						
								<td>% Contacto <br>Efectivo</td></td>";
						if( strlen($string_zonas) > 0 && strlen($string_etapas) == 0 ){
							echo "<td>&nbsp;</td>						
								<td>Zona</td></td>";
						}elseif( strlen($string_zonas) == 0 && strlen($string_etapas) > 0){
							echo "<td>&nbsp;</td>						
								<td>Etapa</td></td>";
						}elseif( strlen($string_zonas) > 0 && strlen($string_etapas) > 0){
							echo "<td>&nbsp;</td>						
								<td>Zona</td></td>
								<td>&nbsp;</td>						
								<td>Etapa</td></td>";
						}
						echo			
							"</tr>";
						$i = 1;
						while(!$rs_reporte_p->EOF) {
							if ($i % 2 == 1) {
								$color = "silver";
							}
							else {
								$color = "white";
							}
							echo '<tr bgcolor='.$color.'>
									<td>'.$rs_reporte_p->fields("NOM_SUPER").'-'.$rs_reporte_p->fields("ID_SUPER").'</td>
									<td>&nbsp;</td>
									<td>'.$rs_reporte_p->fields("NOM_AGENTE").'-'.$rs_reporte_p->fields("ID_AGENTE").'</td>
									<td>&nbsp;</td>								
									<td>'.$rs_reporte_p->fields("REGTOCADOS").'</td>
									<td>&nbsp;</td>
									<td>'.$rs_reporte_p->fields("CE").'</td>
									<td>&nbsp;</td>
									<td>'.$rs_reporte_p->fields("ACTUALIZADOS").'</td>
									<td>&nbsp;</td>
									<td>'.$rs_reporte_p->fields("VENTAS").'</td>
									<td>&nbsp;</td>
									<td>'.number_format(($rs_reporte_p->fields("VENTAS")>0 ? $rs_reporte_p->fields("VENTAS") : 0.1 ) / ($rs_reporte_p->fields("HORAS")>0 ? $rs_reporte_p->fields("HORAS") : 0.1 ),2).'</td>
									<td>&nbsp;</td>
									<td>'.number_format(($rs_reporte_p->fields("CE")>0 ? $rs_reporte_p->fields("CE") : 0.1 )/($rs_reporte_p->fields("REGTOCADOS")>0 ? $rs_reporte_p->fields("REGTOCADOS") : 0.1 ),2).'</td>
									<td>&nbsp;</td>';
							if( strlen($string_zonas) > 0 && strlen($string_etapas) == 0 ){
							  echo '<td>'.$rs_reporte_p->fields("ZONA").'</td>
									<td>&nbsp;</td>';
							}elseif( strlen($string_zonas) == 0 && strlen($string_etapas) > 0){
							  echo '<td>'.$rs_reporte_p->fields("ETAPA").'</td>
									<td>&nbsp;</td>';
							}elseif( strlen($string_zonas) > 0 && strlen($string_etapas) > 0){
							  echo '<td>'.$rs_reporte_p->fields("ZONA").'</td>
								    <td>&nbsp;</td>
								    <td>'.$rs_reporte_p->fields("ETAPA").'</td>
									<td>&nbsp;</td>';
							}																				
							echo '</tr>';
							$rs_reporte_p->MoveNext();
							$i++;
						}					
				echo "</table>";
			}else{
				echo 	"<table border='0'>
							<tr style='font-weight:bold'>
								<td>Supervisor</td>
								<td>&nbsp;</td>								
								<td>Registros <br>Tocados</td>						
								<td>&nbsp;</td>
								<td>Contacto <br> Efectivo</td>	
								<td>&nbsp;</td>
								<td>Actualizados</td>
								<td>&nbsp;</td>	
								<td>Interesados/<br>Promesa de <br>Pagos</td>
								<td>&nbsp;</td>
								<td>Interesados/<br>Promesa de <br>Pagos <br>* Hora</td>								
								<td>&nbsp;</td>
								<td>% Contacto <br>Efectivo</td></td>";						
						if( strlen($string_zonas) > 0 && strlen($string_etapas) == 0 ){
							echo "<td>&nbsp;</td>						
								<td>Zona</td></td>";
						}elseif( strlen($string_zonas) == 0 && strlen($string_etapas) > 0){
							echo "<td>&nbsp;</td>						
								<td>Etapa</td></td>";
						}elseif( strlen($string_zonas) > 0 && strlen($string_etapas) > 0){
							echo "<td>&nbsp;</td>						
								<td>Zona</td></td>
								<td>&nbsp;</td>						
								<td>Etapa</td></td>";
						}
						echo			
							"</tr>";
						$i = 1;
						while(!$rs_reporte_p->EOF) {
							if ($i % 2 == 1) {
								$color = "silver";
							}
							else {
								$color = "white";
							}
							echo '<tr bgcolor='.$color.'>
									<td>'.$rs_reporte_p->fields("NOM_SUPER").'-'.$rs_reporte_p->fields("ID_SUPER").'</td>
									<td>&nbsp;</td>									
									<td>'.$rs_reporte_p->fields("REGTOCADOS").'</td>
									<td>&nbsp;</td>
									<td>'.$rs_reporte_p->fields("CE").'</td>
									<td>&nbsp;</td>
									<td>'.$rs_reporte_p->fields("ACTUALIZADOS").'</td>							
									<td>&nbsp;</td>
									<td>'.$rs_reporte_p->fields("VENTAS").'</td>
									<td>&nbsp;</td>
									<td>'.number_format(($rs_reporte_p->fields("VENTAS")>0 ? $rs_reporte_p->fields("VENTAS") : 0.1 ) / ($rs_reporte_p->fields("HORAS")>0 ? $rs_reporte_p->fields("HORAS") : 0.1 ),2).'</td>
									<td>&nbsp;</td>
									<td>'.number_format(($rs_reporte_p->fields("CE")>0 ? $rs_reporte_p->fields("CE") : 0.1 )/($rs_reporte_p->fields("REGTOCADOS")>0 ? $rs_reporte_p->fields("REGTOCADOS") : 0.1 ),2).'</td>
									<td>&nbsp;</td>';
							if( strlen($string_zonas) > 0 && strlen($string_etapas) == 0 ){
							  echo '<td>'.$rs_reporte_p->fields("ZONA").'</td>
									<td>&nbsp;</td>';
							}elseif( strlen($string_zonas) == 0 && strlen($string_etapas) > 0){
							  echo '<td>'.$rs_reporte_p->fields("ETAPA").'</td>
									<td>&nbsp;</td>';
							}elseif( strlen($string_zonas) > 0 && strlen($string_etapas) > 0){
							  echo '<td>'.$rs_reporte_p->fields("ZONA").'</td>
								    <td>&nbsp;</td>
								    <td>'.$rs_reporte_p->fields("ETAPA").'</td>
									<td>&nbsp;</td>';
							}																				
							echo '</tr>';
							$rs_reporte_p->MoveNext();
							$i++;
						}					
				echo "</table>";			
			}	
		}else{
			//echo 'Valor'.$rs_reporte_p->EOF;
			echo "<table border='0'>
					<tr style='font-weight:bold'>
						<td>La comibinaci&oacute;n que selecciono no es valida <br><br>El rango de Fechas <br> La zona <br> o la Etapa
						<br><br> Pruebe con otra consulta.</td>
						<td>&nbsp;</td>											
					</tr>";
		}
	}else{ //Reporte General
		$tipo_reporte = $_REQUEST['tipo_rep'];
		$fecha_del = $_REQUEST['fecha_del'];
		$fecha_al = $_REQUEST['fecha_al'];
		$turno = 0;
		$rs_reporte = get_reporte_productividad($tipo_reporte, $fecha_del, $fecha_al, $turno, $db);
		
		if ($tipo_reporte == 1) {
			echo 	"<table border='0'>
						<tr style='font-weight:bold'>
							<td>Supervisor</td>
							<td>&nbsp;</td>
							<td>Agente</td>
							<td>&nbsp;</td>
							<td>Asistencia</td>
							<td>&nbsp;</td>
							<td>Horas <br>Trabajadas</td>
							<td>&nbsp;</td>
							<td>Registros <br>Tocados</td>
							<td>&nbsp;</td>												
							<td>Contacto <br> Efectivo</td>		
							<td>&nbsp;</td>
							<td>Actualizados</td>
							<td>&nbsp;</td>	
							<td>Interesados/<br>Promesa de <br>Pagos</td>
							<td>&nbsp;</td>
							<td>Interesados/<br>Promesa de <br>Pagos <br>* Hora</td>								
							<td>&nbsp;</td>						
							<td>% Contacto <br>Efectivo</td></td>						
						</tr>";
					$i = 1;
					while(!$rs_reporte->EOF) {
						if ($i % 2 == 1) {
							$color = "silver";
						}
						else {
							$color = "white";
						}
						echo '<tr bgcolor='.$color.'>
								<td>'.$rs_reporte->fields("NOM_SUPER").'-'.$rs_reporte->fields("ID_SUPER").'</td>
								<td>&nbsp;</td>
								<td>'.$rs_reporte->fields("NOM_AGENTE").'-'.$rs_reporte->fields("ID_AGENTE").'</td>
								<td>&nbsp;</td>
								<td>'.$rs_reporte->fields("ASISTENCIA").'</td>
								<td>&nbsp;</td>
								<td>'.number_format($rs_reporte->fields("HORAS"),2).'</td>
								<td>&nbsp;</td>
								<td>'.$rs_reporte->fields("REGTOCADOS").'</td>
								<td>&nbsp;</td>
								<td>'.$rs_reporte->fields("CE").'</td>
								<td>&nbsp;</td>
								<td>'.$rs_reporte->fields("ACTUALIZADOS").'</td>
								<td>&nbsp;</td>
								<td>'.$rs_reporte->fields("VENTAS").'</td>
								<td>&nbsp;</td>
								<td>'.number_format(($rs_reporte->fields("VENTAS")>0 ? $rs_reporte->fields("VENTAS") : 0.1 ) / ($rs_reporte->fields("HORAS")>0 ? $rs_reporte->fields("HORAS") : 0.1 ),2).'</td>
								<td>&nbsp;</td>
								<td>'.number_format(($rs_reporte->fields("CE")>0 ? $rs_reporte->fields("CE") : 0.1 )/($rs_reporte->fields("REGTOCADOS")>0 ? $rs_reporte->fields("REGTOCADOS") : 0.1 ),2).'</td>
								<td>&nbsp;</td>
							</tr>';
						$rs_reporte->MoveNext();
						$i++;
					}					
			echo "</table>";
		}else{
			echo 	"<table border='0'>
						<tr style='font-weight:bold'>
							<td>Supervisor</td>
							<td>&nbsp;</td>
							<td>Asistencias</td>
							<td>&nbsp;</td>
							<td>Horas <br>Trabajadas</td>
							<td>&nbsp;</td>
							<td>Registros <br>Tocados</td>						
							<td>&nbsp;</td>
							<td>Contacto <br> Efectivo</td>	
							<td>&nbsp;</td>
							<td>Actualizados</td>
							<td>&nbsp;</td>	
							<td>Interesados/<br>Promesa de <br>Pagos</td>
							<td>&nbsp;</td>
							<td>Interesados/<br>Promesa de <br>Pagos <br>* Hora</td>								
							<td>&nbsp;</td>
							<td>% Contacto <br>Efectivo</td></td>						
						</tr>";
					$i = 1;
					while(!$rs_reporte->EOF) {
						if ($i % 2 == 1) {
							$color = "silver";
						}
						else {
							$color = "white";
						}
						echo '<tr bgcolor='.$color.'>
								<td>'.$rs_reporte->fields("NOM_SUPER").'-'.$rs_reporte->fields("ID_SUPER").'</td>
								<td>&nbsp;</td>
								<td>'.$rs_reporte->fields("ASISTENCIA").'</td>
								<td>&nbsp;</td>
								<td>'.number_format($rs_reporte->fields("HORAS"),2).'</td>
								<td>&nbsp;</td>
								<td>'.$rs_reporte->fields("REGTOCADOS").'</td>
								<td>&nbsp;</td>
								<td>'.$rs_reporte->fields("CE").'</td>
								<td>&nbsp;</td>
								<td>'.$rs_reporte->fields("ACTUALIZADOS").'</td>							
								<td>&nbsp;</td>
								<td>'.$rs_reporte->fields("VENTAS").'</td>
								<td>&nbsp;</td>
								<td>'.number_format(($rs_reporte->fields("VENTAS")>0 ? $rs_reporte->fields("VENTAS") : 0.1 ) / ($rs_reporte->fields("HORAS")>0 ? $rs_reporte->fields("HORAS") : 0.1 ),2).'</td>
								<td>&nbsp;</td>
								<td>'.number_format(($rs_reporte->fields("CE")>0 ? $rs_reporte->fields("CE") : 0.1 )/($rs_reporte->fields("REGTOCADOS")>0 ? $rs_reporte->fields("REGTOCADOS") : 0.1 ),2).'</td>
								<td>&nbsp;</td>
							 </tr>';
						$rs_reporte->MoveNext();
						$i++;
					}					
			echo "</table>";	
		}				
	}		
	?>			
			</td>
		</tr><tr>
			<td>
				<input type="button" value="Atras" onclick="Atras()">
			</td>
		</tr>
	</table>
	<br>
<?
layout_footer();
?>