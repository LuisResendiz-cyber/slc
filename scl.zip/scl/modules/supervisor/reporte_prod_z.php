<?php
# Activacion File 
# @uthor Mark

require_once("includes/includes.inc.php");
require_once("supervisor.inc.php");

initialize("mesa_control","Reporte de productividad");

layout_menu($db, "");
?>
	<h4>Reporte de productividad por Zona y Etapas</h4>
	<form name="frm1" method="post" action="modules.php?mod=supervisor&op=mostrar_rp">
	<p id="text">Seleccione la opcion por la cual necesita hacer el filtro y d� clic en el bot�n de "Mostrar Reporte"<br></p>
	<p id="text">Son Obligatorios los campos con <b class="textsmall">*</b></p>
	<table width="80%" id="t1" border="0">
		<tr>
			<td>&nbsp;</td>
		</tr><tr>		
			<td>
				<table align="center" border="0">
					<tr>
						<td align="center"><b class="textsmall"><br>*</b>Agentes</td>
						<td>&nbsp;&nbsp;<input type="radio" name="tipo_rep" value="1" checked></td>
					</tr><tr>
						<td align="center"><b class="textsmall"><br>*</b>Supervisor</td>
						<td>&nbsp;&nbsp;<input type="radio" name="tipo_rep" value="2"></td>
					</tr><tr>
						<td align="center">Zonas Activas:</td>
						<td align="left">
						<?	$i = 0;
							$rep_zonas = get_rep_zonas($db);
							while(!$rep_zonas->EOF) {
							echo'<table border="0"><tr>											
									<td><input type="checkbox" name="id_zona'.$i.'"  value="'.$rep_zonas->fields["IZONA_ID"].'" >
									'.$rep_zonas->fields["IZONA_ID"].' - '.$rep_zonas->fields["VNOMBRE"].'
									</td>
								 </tr></table>';							
								$rep_zonas->MoveNext();
								$i ++;
							}								
						?>
						<br><table>
								<tr><td><input name="toda_zona" type="button" onClick="Todas_Z()" value="Todas"></td>
									<td><input name="ninguna_zona" type="button" onClick="Ning_Z()" value="Ninguna"></td>									
								</tr>
							</table>
						</td>								
					</tr><tr>
						<td align="center">Etapas:</td>
						<td align="left">
						<?	$j = 0;
							$catalogos = get_catalogo('ID_ETAPA',$db);
							while(!$catalogos->EOF) {
							echo'<table border="0"><tr>
									<td><input type="checkbox" name="id_etapa'.$j.'"  value="'.$catalogos->fields["VALOR"].'" >									
									'.$catalogos->fields["VALOR"].' - '.$catalogos->fields["ETIQUETA"].'
								</td>
								</tr></table>';							
								$catalogos->MoveNext();
								$j ++;
							}								
						?>
							<table>
								<tr><td><input name="todas_etapa" type="button" onclick="Todas_E()" value="Todas"></td>
									<td><input name="ninguna_etapa" type="button" onclick="Ning_E()" value="Ninguna"></td>
								</tr>
							</table>
						</td>								
					</tr><tr>
						<td colspan="2" align="center">&nbsp;</td>
					</tr><tr>
						<td colspan="2" align="center"><b>Fecha</b></td>
					</tr><tr>
						<td align="center"><b class="textsmall"><br>*</b>Del:</td>
						<td align="left"><b class="textsmall"><br>*</b>Al:</td>
					</tr><tr>
						<td align="center">
							<script language="JavaScript">
								var SC_SET_1 = {'appearance': SC_APPEARANCE,'dataArea':'fecha_del','dateFormat' : 'd/m/Y'}
								var fecha = '<?=$registro->fields["FECHA_AGENDADO"]?>';
								new sCalendar(SC_SET_1,fecha);
							</script>
						</td>
						<td>
							<script language="JavaScript">
								var SC_SET_1 = {'appearance': SC_APPEARANCE,'dataArea':'fecha_al','dateFormat' : 'd/m/Y'}
								var fecha = '<?=$registro->fields["FECHA_AGENDADO"]?>';
								new sCalendar(SC_SET_1,fecha);
							</script>
						</td>
					</tr>
				</table>
				<br>
				<input type="button" value="Cancelar" onclick="Atras()">
				<input type="button" value="Mostrar Reporte" onclick="Mostrar_Reporte_P()">				
			</td>
		</tr><tr>
			<td colspan="2">
				<br>
				<div id="resp_act" style="display:none"><img src="<?=$linkpath?>includes/imgs/loading.gif"></div>
			</td>
		</tr>
	</table>
	<br>
    </form>
<?
layout_footer();
?>