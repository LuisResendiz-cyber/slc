<?php
# @uthor Mark
# Cuestionario File

require_once("includes/includes.inc.php");
require_once("supervisor.inc.php");

initialize("supervisor", "Seguimiento");

$id_solicitud = get_session_varname('id_solicitud');

layout_menu($db, "frm1.nomina.focus();");
?>
<p class="textbold">Supervisor &gt; Seguimiento de Solicitudes</p>
<p>&nbsp;</p>
<form method="post" action="modules.php?mod=supervisor&op=resultado_agentes" name="frm1">
    <table border="0">
        <tr>
            <td colspan="2" class="label_td" bgcolor="grey">Datos</td>
        </tr>
        <tr>
            <td colspan="2">&nbsp;</td>
        </tr>
        <tr>
            <td class="textleft"><b>Solicitud:&nbsp;</b></td>
            <td class="label"><input type="text" name="solicitud" id="solicitud" size="10" maxlength="10" /></td>
        </tr>
        <tr>
            <td colspan="2">&nbsp;</td>
        </tr>
        <tr>
            <td colspan="2">
                <input type="button" value="Cancelar" onclick="window.location='index2.php'"/>&nbsp;&nbsp;
                <input type="button" value="Mostrar Reporte" onclick="seg_solicitud();">
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <br>
                <div id="resp_act" style="display:none"><img src="<?= $linkpath ?>includes/imgs/loading.gif"></div>
            </td>
        </tr>
    </table>
</form>
<?
layout_footer();
?>