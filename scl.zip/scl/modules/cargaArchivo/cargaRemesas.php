<?php
# CargaRemesas File 
# @uthor Mark

require_once("includes/includes.inc.php");
require_once("modules/layoutFile/layoutFile.inc.php");

load_session();

$action = base64_decode($_GET['action']);
if($action == 1 || $action == 6 || $action == 7){
	$section = "mesa_control";
}else if($action == 2 || $action == 3 || $action == 5 ){
	$section = "finanzas";
}

initialize($section,"Busqueda de Solicitudes",$db);
get_header(($action == 1?"Aceptadas":"Carga de Archivos"));
get_menu($db);

echo '-'.$action .'-';

	if($action == 1){ #ESTA SECCION REALIZA LA CARGA DE ARCHIVO PARA CATALOGAR LOS REGISTROS COMO APROBADAS O DECLINADAS
?>
		<b>D&eacute; click en el bot&oacute;n examinar para seleccionar el archivo.</b><br>
		Recuerda que los datos del archivo deben ser de una solo clasificaci&oacute;n (Caidos Impulse, Caidos Banco, Recuperadas, Aceptadas, Canceladas)<br>
		<form name="frm4" method="post" action="modules.php?mod=layoutFile&op=process_data&action=3" enctype="multipart/form-data">
			<table width="45%" align="left" border="0">
				<tr>
					<td colspan="2">&nbsp;</td>
				</tr><tr>
					<td colspan="2"><b>Archivo:</b>&nbsp;<input type="file" name="fichero" size="50" ></td>
				</tr><tr>
					<td colspan="2">&nbsp;</td>
				</tr><tr>
					<td colspan="2">
						<input type="hidden" name="action_val" value="upload">
						<input type="button" value="Pantalla Anterior" onclick="location.href='<?=$linkpath?>index.php'"/>&nbsp;&nbsp;
						<input type="button" name="continuar" value="Continuar" onclick="validaFicheroForm()" />
					</td>
				</tr>
			</table>
		</form>

<?php	
	} else if($action == 2) { ## ESTA SECCION PERMITE CAMBIAR EL ESTADO DE LAS SOLICITUDES APROBADAS A FACTURADAS
?>

		<b>Seleccione la (s) Pre - factura (s), capture el numero de factura y fecha de facturacion, por ultimo d� click en el bot�n continuar.</b>
		<br><br>
		<form name="frm3" method="post" action="modules.php?mod=layoutFile&op=process_data&action=2">
			<table border="0">
				<tr style="background-color:<?=getColor(0)?>;font-weight:bold" align="center">
					<td># Reg.</td>
					<td>Accion</td>
					<td>Pre-factura</td>
					<td>Remesa</td>
					<td>Status</td>
					<td>Registros</td>
				</tr>
					<?php		
						$i = 1;
						$ii = 0;
						$rs_count = get_preInvoice_data(1, 'AB', $action, $db);
						if($rs_count->fields['REGISTROS'] > 0){
							$rs = get_preInvoice_data(2, 'AB', $action, $db);
							$total = 0;
							while(!$rs->EOF) {
								echo '
								<tr align="center">
									<td>'.$i.'</td>
									<td><input type="checkbox" name="factura'.$ii.'" value="'.$rs->fields["PREINVOICE"].'" checked></td>
									<td>'.$rs->fields["PREINVOICE"].'</td>
									<td>'.$rs->fields["REMESA"].'</td>
									<td>'.$rs->fields["STATUS"].'</td>
									<td>'.$rs->fields["CANTIDAD"].'</td>
								</tr>';
								$total += $rs->fields["CANTIDAD"];
								$rs->MoveNext();
								$i++;
								$ii++;
								
							}
							
							if($total > 0){
								echo '	<tr align="center">
											<td colspan="6"><hr></td>
										</tr><tr>
											<td colspan="5"><b>Total:&nbsp;</b></td>
											<td align="center"><b>'.$total.'</b></td>
										</tr>';
							}
						
						}else{
							echo '	<tr>
										<td colspan="5"><font color="red" size="2"><b>No se encontraron registros</b></font></td>
									</tr>';
						}
						
					?>
				<tr>
					<td colspan="6">&nbsp;</td>
				</tr><tr>
					<td><b>Factura #:</b></td>
					<td><b>Fecha de Facturaci&oacute;n:</b></td>
					<td colspan="4">&nbsp;</td>
				</tr><tr align="center">
					<td>&nbsp;<input type="text" name="num_factura" id="num_factura" size="10">&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td>
						<script language="JavaScript">
							var SC_SET_1 = {'appearance': SC_APPEARANCE,'dataArea':'fecha_factura','dateFormat' : 'd/m/Y'}
							new sCalendar(SC_SET_1);
						</script>
					</td>
					<td colspan="4">&nbsp;</td>
				</tr><tr>
					<td colspan="6">
						<input type="hidden" name="registros" value="<?=$total?>" readonly>
						<input type="button" value="Pantalla Anterior" onclick="location.href='<?=$linkpath?>index.php'"/>&nbsp;
						<input type="button" value="Continuar" onclick="UpdateRemesas(<?=$action?>)" name="continuar">&nbsp;
					</td>
				</tr><tr>
					<td colspan="6">
						&nbsp;<div id="loading" style="display:none">Realizando petici&oacute;n, espere un momento.&nbsp;<img src="<?=$linkpath?>includes/imgs/loading.gif"></div>
					</td>
				</tr>
			</table>
		</form>
		
<?php
	} else if($action == 3) { ## ESTA SECCION PERMITE CAMBIAR EL ESTADO DE LAS SOLICITUDES FATURADAS A COBRADAS
?>
		<b>Seleccione la (s) factura (s), capture la fecha de envio de facturacion, fecha de pago de factura, por ultimo d� click en el bot�n continuar</b>
		<br><br>
		<form name="frm3" method="post" action="modules.php?mod=layoutFile&op=process_data&action=2">
			<table border="0">
				<tr style="background-color:<?=getColor(0)?>;font-weight:bold" align="center">
					<td># Reg.</td>
					<td>Accion</td>
					<td>Factura</td>
					<td>Remesa</td>
					<td>Status</td>
					<td>Registros</td>
				</tr>
					<?php		
						$i = 1;
						$ii = 0;
						$rs_count = get_preInvoice_data(1, '', $action, $db);
						if($rs_count->fields['REGISTROS'] > 0){
							$rs = get_preInvoice_data(2, '', $action, $db);
							$total = 0;
							while(!$rs->EOF) {
								echo '
								<tr align="center">
									<td>'.$i.'</td>
									<td><input type="checkbox" name="factura'.$ii.'" value="'.$rs->fields["SURVEYID"].'-'.$rs->fields["INVOICENUM"].'" checked></td>
									<td>'.$rs->fields["INVOICENUM"].'</td>
									<td>'.$rs->fields["REMESA"].'</td>
									<td>'.$rs->fields["STATUS"].'</td>
									<td>'.$rs->fields["CANTIDAD"].'</td>
								</tr>';
								$total += $rs->fields["CANTIDAD"];
								$rs->MoveNext();
								$i++;
								$ii++;
								
							}
							
							if($total > 0){
								echo '<tr align="center"><td colspan="6"><hr></td></tr>
									<tr><td colspan="5"><b>Total:&nbsp;</b></td><td align="center"><b>'.$total.'</b></td></tr>';
							}
						
						}else{
							echo '<tr><td colspan="6"><font color="red" size="2"><b>No se encontraron registros</b></font></td></tr>';
						}
						
					?>
				<tr>
					<td colspan="7">&nbsp;</td>
				</tr><tr>
					<td colspan="2"><b>Fecha de envio de Factura:</b></td>
					<td colspan="5">
						<script language="JavaScript">
							var SC_SET_1 = {'appearance': SC_APPEARANCE,'dataArea':'fecha_envio','dateFormat' : 'd/m/Y'}
							new sCalendar(SC_SET_1);
						</script>
					</td>
				</tr><tr>
					<td colspan="2"><b>Fecha de pago de Factura:</b></td>
					<td colspan="5">
						<script language="JavaScript">
							var SC_SET_1 = {'appearance': SC_APPEARANCE,'dataArea':'fecha_pago','dateFormat' : 'd/m/Y'}
							new sCalendar(SC_SET_1);
						</script>
					</td>
				</tr><tr>
					<td colspan="7">
						<input type="hidden" name="registros" value="<?=$total?>" readonly>
						<input type="button" value="Pantalla Anterior" onclick="location.href='<?=$linkpath?>index.php'"/>&nbsp;
						<input type="button" value="Continuar" onclick="UpdateRemesas(<?=$action?>)" name="continuar">&nbsp;
					</td>
				</tr><tr>
					<td colspan="7">
						&nbsp;<div id="loading" style="display:none">Realizando petici&oacute;n, espere un momento.&nbsp;<img src="<?=$linkpath?>includes/imgs/loading.gif"></div>
					</td>
				</tr>
			</table>
		</form>

<?php
	} else if($action == 5) { ## ESTA SECCION PERMITE CAMBIAR EL ESTADO DE LAS SOLICITUDES CANCELADAS A REEMBOLSADO
?>
		<b>Seleccione las facturas y capture el numero de la nota de credito, por ultimo d� click en el bot�n continuar.</b>
		<br><br>
		<form name="frm3" method="post" action="modules.php?mod=layoutFile&op=process_data&action=2">
			<table border="0">
				<tr style="font-weight:bold;text-align:center">
					<td># Reg.</td>
					<td>Accion</td>
					<td>Factura</td>
					<td>Shot</td>
					<td>Remesa</td>
					<td>Status</td>
					<td>Registros</td>
				</tr>
					<?php		
						$i = 1;
						$ii = 0;
						$rs_count = get_preInvoice_data(1, 0, $action, $db);
						if($rs_count->fields['REGISTROS'] > 0){
							$rs = get_preInvoice_data(2, 0, $action, $db);
							$total = 0;
							while(!$rs->EOF) {
								echo '
								<tr align="center">
									<td>'.$i.'</td>
									<td><input type="checkbox" name="factura'.$ii.'" value="'.$rs->fields["INVOICENUM"].'" checked></td>
									<td>'.$rs->fields["INVOICENUM"].'</td>
									<td>'.$rs->fields["SHOTID"].'</td>
									<td>'.$rs->fields["REMESA"].'</td>
									<td>'.$rs->fields["STATUS"].'</td>
									<td>'.$rs->fields["CANTIDAD"].'</td>
								</tr>';
								$total += $rs->fields["CANTIDAD"];
								$rs->MoveNext();
								$i++;
								$ii++;
								
							}
							
							if($total > 0){
								echo '<tr align="center"><td colspan="7"><hr></td></tr>
									<tr><td colspan="6"><b>Total:&nbsp;</b></td><td align="center"><b>'.$total.'</b></td></tr>';
							}
						
						}else{
							echo '<tr><td colspan="6"><font color="red" size="2"><b>No se encontraron registros</b></font></td></tr>';
						}
						
					?>
				<tr><td colspan="7">&nbsp;</td></tr>
				<tr align="center">
					<td colspan="2"><b># Nota de Credito:</b></td>
					<td colspan="5"><b>Fecha de Nota de Credito:</b></td>
				</tr><tr align="center">
					<td colspan="2">
						<input type="text" name="num_credito" id="num_credito" size="10">&nbsp;&nbsp;&nbsp;&nbsp;
					</td>
					<td colspan="5">
						<script language="JavaScript">
							var SC_SET_1 = {'appearance': SC_APPEARANCE,'dataArea':'fecha_credito','dateFormat' : 'd/m/Y'}
							new sCalendar(SC_SET_1);
						</script>
					</td>
				</tr><tr>
					<td colspan="7">
						<input type="hidden" name="registros" value="<?=$total?>" readonly>
						<input type="button" value="Pantalla Anterior" onclick="location.href='<?=$linkpath?>index.php'"/>&nbsp;
						<input type="button" value="Continuar" onclick="UpdateRemesas(<?=$action?>)" name="continuar">&nbsp;
					</td>
				</tr><tr>
					<td colspan="7">
						&nbsp;<div id="loading" style="display:none">Realizando petici&oacute;n, espere un momento.&nbsp;<img src="<?=$linkpath?>includes/imgs/loading.gif"></div>
					</td>
				</tr>
			</table>
		</form>
<?php
	} else if($action == 6) { ## ESTA SECCION PERMITE APLICAR LOS DISTINTOS PRECIOS A LAS REMESAS
?>
		<b>Seleccione la base para mostrar los resultados.</b>
		<br><br>
		<form name="frm3" method="post" action="modules.php?mod=layoutFile&op=process_data&action=7">
			<table border="0">
				<tr>
					<td valign="bottom" colspan="2">
						<b>Shot:&nbsp;</b>
						<select name="shots">
						<?php		
						$i = 0;
						$rs = get_shot_zonas(1,$db);
						while(!$rs->EOF) {
							echo '<option value="'.$rs->fields["ZONA"].'">'.$rs->fields["ZONA"].'</option>';
							$rs->MoveNext();
							$i++;
						}
						?>
						</select>
					</td>
				</tr><tr>
					<td colspan="2">&nbsp;</td>
				</tr><tr>
					<td><b>% de Cumplimiento:</b></td>
					<td>
						<select name="porcentaje">
							<option value="1">- 80%</option>
							<option value="2">81 a 100%</option>
							<option value="3">+ 100%</option>
						</select>
					</td>
				</tr><tr>
					<td colspan="2">
						&nbsp;<div id="loading" style="display:none">Realizando petici&oacute;n, espere un momento.&nbsp;<img src="<?php echo $linkpath;?>includes/imgs/loading.gif"></div>
					</td>
				</tr><tr>
					<td colspan="2">&nbsp;</td>
				</tr><tr>
					<td id="datosPrecio" style="display:none" colspan="2" align="left">
						<table>
							<tr>
								<td><b>Fecha de envio a visto bueno:</b></td>
								<td>
									<script language="JavaScript">
										var SC_SET_1 = {'appearance': SC_APPEARANCE,'dataArea':'fecha_envio','dateFormat' : 'd/m/Y'}
										new sCalendar(SC_SET_1);
									</script>
								</td>
							</tr>
						</table>
					</td>
				</tr><tr>			
					<td colspan="2">
						<input type="button" value="Pantalla Anterior" onclick="location.href='<?=$linkpath?>index.php'"/>&nbsp;
						<input type="button" value="Generar" onclick="UpdateRemesas(<?=$action?>)" name="continuar">&nbsp;
						<input type="button" value="Guardar" onclick="GuardarPrecios()" name="guardar">
					</td>
				</tr>
			</table>
		</form>	
<?php
	} else if($action == 7) { ## ESTA SECCION PERMITE AGREGAR EL NUMERO DE PRE - FACTURA A LAS SOLICITUDES APROBADAS
?>
		<b>Capture el campo de Pre-Factura y la fecha, por ultimo de click en el bot�n Continuar.</b>
		<br><br>
		<form name="frm3" method="post" action="modules.php?mod=layoutFile&op=process_data&action=2">
			<table border="0">
				<tr style="font-weight:bold;text-align:center">
					<td># Reg.</td>
					<td>Accion</td>
					<td># Remesa</td>
					<td>Registros</td>
				</tr>
					<?php		
						$i = 1;
						$ii = 0;
						$rs = get_shot_zonas(2,$db);
						$total = 0;
						while(!$rs->EOF) {
							echo '
							<tr align="center">
								<td>'.$i.'</td>
								<td><input type="checkbox" name="remesaid'.$ii.'" value="'.$rs->fields["REMESAID"].'" checked></td>
								<td>'.$rs->fields["REMESAID"].'</td>
								<td>'.$rs->fields["REGISTROS"].'</td>
							</tr>';
							$total += $rs->fields["REGISTROS"];
							$rs->MoveNext();
							$i++;
							$ii++;
							
						}
						if($total > 0){
							echo '
								<tr align="center"><td colspan="4"><hr></td>
								</tr><tr>
									<td colspan="3"><b>Total:&nbsp;</b></td>
									<td align="center"><b>'.$total.'</b></td>
								</tr>';
						}
					?>
				<tr><td colspan="5">&nbsp;</td></tr>
				<tr align="center">
					<td colspan="2"><b>Pre - Factura #:</b></td>
					<td colspan="3" align="left"><b>&nbsp;Fecha de Pre - Factura:</b></td>
				</tr><tr align="center">
					<td colspan="2">&nbsp;<input type="text" name="num_gen" size="15">&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td colspan="3" align="left">
						<script language="JavaScript">
							var SC_SET_1 = {'appearance': SC_APPEARANCE,'dataArea':'fecha_pref','dateFormat' : 'd/m/Y'}
							new sCalendar(SC_SET_1);
						</script>
					</td>
				</tr><tr>
					<td colspan="5">
						<input type="hidden" name="registros" value="<?=$total?>" readonly>
						<input type="button" value="Pantalla Anterior" onclick="location.href='<?=$linkpath?>index.php'"/>&nbsp;
						<input type="button" value="Continuar" onclick="UpdateRemesas(<?=$action?>)" name="continuar">&nbsp;
					</td>
				</tr><tr>
					<td colspan="5">
						&nbsp;<div id="loading" style="display:none">Realizando petici&oacute;n, espere un momento.&nbsp;<img src="<?=$linkpath?>includes/imgs/loading.gif"></div>
					</td>
				</tr>
			</table>
		</form>
<?
realpath('modules/Files_remesas/load_data.ctl');
}
get_footer();
?>