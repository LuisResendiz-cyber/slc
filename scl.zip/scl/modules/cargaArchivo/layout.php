<?php
set_time_limit(300);
ini_set("display_errors", "On");
# Download File 
# @uthor Mark     

require_once("../includes/includes.inc.php");
require_once("../layoutFile/layoutFile.inc.php");

$file_name = desencrypt($_GET["file_name"]);
$tipoLayout = $_REQUEST['tipoLayout'];
$mes = $_REQUEST['mes'];
$rs = get_datos_layout_remesas($mes, $tipoLayout  ,$conn);

if($tipoLayout == 1){
	$layout_name ='';
}else{
	$layout_name ='';
}
//header("Content-Type: text/plain");
//header("content-disposition: attachment;filename=".$file_name."");

echo  '<br>';
echo  '<pre>';

if($tipoLayout == 1){
	echo 'IDENTIFICADOR,CD_SUCURSAL,FE_INICIO,FE_FIN,CONTA_EFECTIVOS,NU_VENTAS,CD_CAMP,CD_PROM,PRIMA_PRM_VTA,REMESA,NO_SHOT'.'<br>';

	$i = 0;
	while(!$rs->EOF) {
		$cont = substr('000' . $i, -3);
		echo $rs->fields['IDENTIFICADOR'].$cont.','.$rs->fields['SUCURSAL'].','.$rs->fields['FE_INICIO'].','.$rs->fields['FE_FIN'].','.$rs->fields['CONTA_EFECTIVOS'].','.$rs->fields['NUM_VENTAS'].','.$rs->fields['CD_CAMP'].','.$rs->fields['CD_PROM'].', '.$rs->fields['PRIMA'].', '.$rs->fields['REMESA'].','.$rs->fields['SHOT'].'<br>';
		$i++;
		$rs->MoveNext();
	}
}else{
	echo 'CANAL,RAMO,REMESA,CAMPANA,SUCURSAL,COMP_SUCURSAL,FECH_CARGA,PRIMA_PRM_VTA,TOT_REG_VTA<br>';
	$i = 0;
	while(!$rs->EOF) {
		$cont = substr('000' . $i, -3);
//		echo $rs->fields['CANAL'].','.$rs->fields['RAMO'].','.$rs->fields['REMESA'].','.$rs->fields['CAMPANA'].$cont.','.$rs->fields['SUCURSAL'].','.$rs->fields['COMP_SUCURSAL'].$cont.','.$rs->fields['FECH_CARGA'].','.$rs->fields['PRIMA_PRM_VTA'].','.$rs->fields['TOT_REG_VTA'].'<br>';
		echo $rs->fields[0].','.$rs->fields[1].','.$rs->fields[2].','.$rs->fields[3].$cont.','.$rs->fields[4].','.$rs->fields[5].$cont.','.$rs->fields[6].','.$rs->fields[7].','.$rs->fields[8].'<br>';		$i++;
		$rs->MoveNext();
	}
}
	echo "</pre>";
	$rs->Close();
?>