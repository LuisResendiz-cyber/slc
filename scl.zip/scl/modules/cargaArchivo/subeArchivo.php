<?php
#SuberArchivo File 
#@uthor Mark

require_once("includes/includes.inc.php");
require_once("modules/layoutFile/layoutFile.inc.php");

load_session();
initialize("mesa_control","Busqueda de Clientes",$db);

get_header("Inicio");
get_menu($db);

$error = (isset($_GET['e'])?$_GET['e']:0);
$ky = (isset($_GET['ky'])?$_GET['ky']:0);

if(isset($error) && $error != 0){
	$cantidad = (isset($_GET['c'])?$_GET['c']:"");
	if($error == 1){
		$valor_error = '<font color="red">El archivo no se cargo correctamente, intente de nuevo!!!!';
	}else if($error == 2){
		$valor_error = '<font color="red">No se recibio un tipo de archivo de texto, intente de nuevo!!!!';
	}else if($error == 3){
		$valor_error = '<font color="blue">Se actualizaron correctamente '.$cantidad.' registros!!!!';
	}else if($error == 4){
		$valor_error = '<font color="red">No se pudo realizar la peticion, intente nuevamente!!!!';
	}else if($error == 5){
		$valor_error = '<font color="Blue">Se actualizo con exito el precio de las solicitudes!!!!';
	}else if($error == 6){
		$valor_error = '<font color="blue">Se inicio el seguimiento a '.$cantidad.' registros!!!!';	
	}
?>
	<b>Resultado de la carga de Archivo.</b><br><br>
	<form name="fmr3" method="POST" action="modules.php?mod=layoutFile&op=process_data&action=9">
	<input type="hidden" name="ky" value="<?=$ky?>">
	<table width="35%" border ="0">
		<tr>
			<td><b>Mensaje:</b></td>
			<td><b><?php echo $valor_error;?></font></b></td>
		</tr><tr>
			<td colspan="2">
				<br><br>
				<input type="button" value="Terminar" onclick="location.href='<?php echo $linkpath;?>index.php'" />&nbsp;
				<?
					if($ky != 0){
						echo '<input type="submit" value="Mostrar reporte"/>&nbsp;';
					}
				?>
			</td>
		</tr>
	</table>
	</form>
<?php
} else {
?>	
	<b>Seleccione la acci�n a realizar.</b><br><br>
	<form name="fmr3" method="post" action="modules.php?mod=layoutFile&op=process_data&action=4">
		<table>
			<tr>
				<td width="40%" valign="bottom">
					<table border ="0">
						<tr style="background-color:<?=getColor(0)?>;font-weight:bold" align="center">
							<td>Reg.</td>
							<td># Remesa</td>
							<td>Cliente</td>
							<td>Producto</td>
							<td>RFC / Contrato</td>
							<td>Estatus</td>
						</tr>
						<?php 
							$i = 0;
							$ii = 0;
							$contador_registro = 1;
							
							$rs_data = get_data_by_file(1, 1, $db);
							while(!$rs_data->EOF){
								echo '<tr style="background-color:'.getColor($contador_registro).'" align="center">';
									if(strlen($rs_data->fields["CUSTOMERID"]) >= 1) {
										echo '<td>'.$contador_registro.'&nbsp;&nbsp;</td>
											  <td>'.$rs_data->fields["REMESA"].'&nbsp;&nbsp;</td>
											  <td>'.$rs_data->fields["CUSTOMERID"].'&nbsp;&nbsp;</td>
											  <td>'.$rs_data->fields["SURVEYID"] .'&nbsp;&nbsp;</td>
											  <td>'.$rs_data->fields["RFC"].'&nbsp;&nbsp;</td>
											  <td><b>'.$rs_data->fields["STATUS"].'&nbsp;&nbsp;</b></td>';
											  $i++;
									} else {
										echo '<td>'.$contador_registro.'&nbsp;&nbsp;</td>
											  <td colspan="3"><font size="2" color="red"><b>No se encontro informacion</b></font>&nbsp;&nbsp;</td>
											  <td>'.$rs_data->fields["RFC"].'&nbsp;&nbsp;</td>
											  <td><b>----</b></td>
											  ';
											  $ii++;
									}
								echo '</tr>';
								$contador_registro++;
								$rs_data->MoveNext();
							}
						?>
						<tr>
							<td colspan="5"><b>Registros Encontrados: <?=$i?></b></td>
						</tr><tr>
							<td colspan="5"><b>Registros No Encontrados: <?=$ii?></b></td>
						</tr><tr>
							<td colspan="5">&nbsp;</td>
						</tr><tr>
							<td colspan="5">
								<b>Clasificar como:</b>
								<select name="clasificacion" id="clasificacion">
								<?php 
									$title_status = '';
									if($i >= 1){
										$rs_clasificacion = get_ControllerStatus(1,$db);
										$title_status =  $rs_clasificacion->fields["DESCRIPTION"];
										echo '<option value="'.$rs_clasificacion->fields["OPERATIONID"].'">&nbsp;'.$rs_clasificacion->fields["DESCRIPTION"].'&nbsp;</option>';
									}
								?>
								</select>
							</td>
						</tr><tr>
							<td colspan="5">&nbsp;</td>
						</tr><tr>
							<td colspan="5">
								<div id="fact">
									<table border="0">
										<tr>
											<td id="fecha"><b>Fecha de <?=$title_status?></b></td>
											<td colspan="2">
												<script language="JavaScript">
													var SC_SET_1 = {'appearance': SC_APPEARANCE,'dataArea':'fec_gen','dateFormat' : 'd/m/Y'}
													new sCalendar(SC_SET_1);
												</script>
											</td>
											<td>&nbsp;&nbsp;</td>
										</tr>
									</table>
								</div>
							</td>
						</tr>
					</table>
				</td>
			</tr><tr>
				<td>&nbsp;</td>
			</tr><tr>
				<td colspan="2">&nbsp;<div id="loading" style="display:none">Realizando peticion, espere un momento.&nbsp;<img src="<?=$linkpath?>includes/imgs/loading.gif"></div></td>
			</tr><tr>
				<td colspan="2">
					<input type="button" value="Terminar" onclick="location.href='<?=$linkpath?>index.php'"/>&nbsp;&nbsp;
					<input type="button" value="Continuar" name="continuar" onclick="validaFormEstatus(<?=$i-1?>)">
				</td>
			</tr>
		</table>
	</form>
<?php
}
get_footer();
?>