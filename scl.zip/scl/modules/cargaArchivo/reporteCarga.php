<?php
ini_set('display_errors',1);
#Reporte Carga File 
#@uthor Mark   

require_once("includes/includes.inc.php");
require_once("modules/layoutFile/layoutFile.inc.php");

load_session();

header("Content-Type: text/plain");
header("content-disposition: attachment;filename=reporte.xls");

$ky = $_GET['ky'];
?>
	<table border ="2">
		<tr>
			<td># Reg.</td>
			<td>RFC / Contrato</td>
			<td>Motivo</td>
			<td>Estado cargado</td>
			<td>Solicitud</td>
			<td colspan="7">Datos</td>
			<td>Fecha</td>
		</tr>
<?
		$contador = 1;
		$i = 0;
		$rs = get_rerporte_carga($ky, $db);
		while(!$rs->EOF) {
		//print_R($rs->fields);
			echo '<tr style="background-color:'.getColor($i).'">';
			if($rs->fields["STATUS"] == 850){
				echo '<td>'.$contador.'</td><td>'.$rs->fields["RFC"].'</td><td>'.$rs->fields["MOTIVO"].'</td><td>'.$rs->fields["STATUS"].'</td><td>'.$rs->fields["CUSTOMERID"].'</td><td>'.$rs->fields["CAUSA_ANULACION"].'</td><td>'.$rs->fields["INICIO_VIGENCIA"] .'</td><td>'.$rs->fields["FECHA_ANULACION"].'</td><td>'.$rs->fields["CUOTA"].'</td><td>'.$rs->fields["PRIMA_PAGO"].'</td><td>'.$rs->fields["STATUS_RECIBO"].'</td><td>'.$rs->fields["RESPUESTA_COBRANZA"].'</td><td>'.$rs->fields["FECHA"].'</td>';
			}else{
				echo '<td>'.$contador.'</td><td>'.$rs->fields["RFC"].'</td><td>'.$rs->fields["MOTIVO"].'</td><td>'.$rs->fields["STATUS"].'</td><td>'.$rs->fields["CUSTOMERID"].'</td><td colspan="7">&nbsp;</td><td>'.$rs->fields["FECHA"].'</td>';
			}
			
				echo '</tr>';
			$rs->MoveNext();
			$i++;
			$contador++;
		}
?>
		<tr>
			<td colspan="12"><b>Registros Encontrados:<?=$i?></b></td>
		</tr>
	</table>