<?php
# CargaRemesas File 
# @uthor Mark

require_once("includes/includes.inc.php");
require_once("modules/layoutFile/layoutFile.inc.php");

load_session();

$action = base64_decode($_GET['action']);
if($action == 1 || $action == 6 || $action == 7){
	$section = "mesa_control";
}else if($action == 5 || $action == 3 || $action == 2 ){
	$section = "finanzas";
}

initialize($section,"Layouts",$conn);
get_header(($action == 1?"Aceptadas":"Carga de Archivos"));
get_menu($conn);
$genera = (isset($_REQUEST['genera'])?$_REQUEST['genera']:0);

	if($genera == 0){ #ESTA SECCION MUESTRA EL ARCHIVO LAYOUT
?>
		<b>Seleccione el tipo de layout que desee generar y por ultimo d� click en el bot&oacute;n continuar.</b><br>
		<form name="frm3" method="post" action="<?=$linkpath?>layoutFile/process_data.php?action=8">
			<table width="45%" align="left" border="0">
				<tr>
					<td colspan="2">&nbsp;</td>
				</tr><tr>
						<td class="textleft"><b>Layout:&nbsp;</b></td>
						<td>							
							<b>Campa�a</b>&nbsp;<input type="radio" name="tipoLayout" value="1" id="tipollamada" checked>&nbsp;&nbsp;&nbsp;&nbsp;
							<b>Ramo</b>&nbsp;<input type="radio" name="tipoLayout" value="2" id="tipollamada">
						</td>
				</tr><tr>
					<td><b>Seleccione el mes</b>&nbsp;</td>
					<td>
					<select name="mes">
						<option value="1">Enero</option>
						<option value="2">Febrero</option>
						<option value="3">Marzo</option>
						<option value="4">Abril</option>
						<option value="5">Mayo</option>
						<option value="6">Junio</option>
						<option value="7">Julio</option>
						<option value="8">Agosto</option>
						<option value="9">Septiembre</option>
						<option value="10">Octubre</option>
						<option value="11">Noviembre</option>
						<option value="12">Diciembre</option>
					</select>
						
					</td>
				</tr><tr>
					<td colspan="2">&nbsp;</td>
				</tr><tr>
					<td colspan="2">
						<input type="hidden" name="action_val" value="upload">
						<input type="button" value="Pantalla Anterior" onclick="location.href='<?=$linkpath?>index.php'"/>&nbsp;&nbsp;
						<input type="button" name="continuar" value="Continuar" onclick="MuestraLayout()" />
					</td>
				</tr><tr>
					<td colspan="7">
						&nbsp;<div id="loading" style="display:none">Realizando petici&oacute;n, espere un momento.&nbsp;<img src="<?=$linkpath?>includes/imgs/loading.gif"></div>
					</td>
				</tr>
			</table>
		</form>

<?php	
	} else if($action == 2) { ## Sin Datos

	}

get_footer();
?>