<?php
# @uthor Mark 
# Modules Fille 
/*
$module = (isset($_REQUEST['mod'])?$_REQUEST['mod']:"");
$op = (isset($_REQUEST['op'])?$_REQUEST['op']:"");

if(strlen($module) > 0 || strlen($op) > 0){
		include("modules/".$module."/".$op.'.php');
}*/

$module = (isset($_REQUEST['mod'])?$_REQUEST['mod']:"");
$op = (isset($_REQUEST['op'])?$_REQUEST['op']:"");

/*  var_dump($module, $op); // Agrega esta línea para imprimir los valores
 echo "modules/".$module."/".$op.".php"; */
 
//die(); 

if(strlen($module) > 0 || strlen($op) > 0){
    include("modules/".$module."/".$op.'.php');
}



?>