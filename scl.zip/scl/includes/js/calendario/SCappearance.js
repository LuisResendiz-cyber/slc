/*
 * ABarajas, 2014-03-19: Usar lector de cookies (definido en jsCode).
 */
var linkpath = readCookie('linkpath');

var SC_APPEARANCE = {
    'weekdays': ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'Sa'],
    'longmonth': ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
    'messages': {
        'Warning': 'Alerta: La fecha ingresada no corresponde con el formato dd/mm/yyyy',
        'AltPrevYear': 'Año anterior',
        'AltNextYear': 'Año proximo',
        'AltPrevMonth': 'Mes anterior',
        'AltNextMonth': 'Mes siguiente'
    },
    'CalDiv': 'clsCalDiv',
    'OuterFrame': 'clsOuterFrame',
    'InnerFrame': 'clsInnerFrame',
    'TopPartNavpanel': 'clsTopPartNavpanel',
    'BottomPartNavpanel': 'clsBottomPartNavpanel',
    'MidRow': 'clsMidRow',
    'DateGrid': 'clsDateGrid',
    'WeekDay': 'clsWeekDay',
    'WorkDayCell': 'clsWorkDayCell',
    'HoliDayCell': 'clsHoliDayCell',
    'OtherMonthDayCell': 'clsOtherMonthDayCell',
    'SelectedDayCell': 'clsSelectedDayCell',
    'CurrentMonthDay': 'clsCurrentMonthDay',
    'OtherMonthDay': 'clsOtherMonthDay',
    'SelectedDay': 'clsSelectedDay',
    'InfoTitle': 'clsInfoTitle',
    'DataArea': 'clsDataArea',
    'PrevYear': linkpath + '/includes/js/calendario/img/prev_year.gif',
    'PrevMonth': linkpath + '/includes/js/calendario/img/prev_month.gif',
    'NextYear': linkpath + '/includes/js/calendario/img/next_year.gif',
    'NextMonth': linkpath + '/includes/js/calendario/img/next_month.gif',
    'IcoCalUnVis': linkpath + '/includes/js/calendario/img/dpr_unvis.gif',
    'IcoCalVis': linkpath + '/includes/js/calendario/img/dpr_vis.gif'

};