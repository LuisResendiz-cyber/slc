<?php

session_start();
$dato1 = $_REQUEST['dato1'];

die();



?>