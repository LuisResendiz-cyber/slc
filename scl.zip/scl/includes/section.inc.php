<?php

#VERIFICA EL PERFIL DEL USUARIO TENGA PERMISOS EN LA SECCION
function check_profile($section, $conn) {
    $section_array = explode(",", $section);

    $permission_array = array(0 => 'No has iniciado session', 'A' => 'agente', 'AI' => 'agente', 'ASB' => 'agente', 'ACB' => 'agente', 'N' => 'nomina', 'V' => 
    'validacion', 'MC' => 'mesa_control', 'GO' => 'gerente_operacion', 'GV' => 'gerente_validacion', 'S' => 'supervisor');

    // Iterar sobre el array solo si es válido y no está vacío
    for ($i = 0; $i < count($section_array); $i++) {
        if ($section_array[$i] == $permission_array[get_session_varname("s_usr_nivel")]) {
            $exist = 1;
            break;
        } else {
            $exist = 0;
        }
    }
    return $exist;
} 