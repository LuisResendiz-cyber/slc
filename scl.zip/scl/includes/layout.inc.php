<?php
# @uthor Mark
# Layout.inc File
# MUESTRA EL ENCABEZADO DE LA PAGINA

function layout_header($subtitle) {
    global $linkpath, $pagetitle;
    $random = rand();
    echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
		  <html>
		  <head>
                  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
                  <link rel="stylesheet" href="' . $linkpath . 'includes/css/style.css" type="text/css" />
                  <link rel="stylesheet" href="' . $linkpath . 'includes/css/block.css" type="text/css" />
		          <link rel="stylesheet" href="' . $linkpath . 'includes/js/calendario/calendar.css" type="text/css" />
		          <link rel="stylesheet" href="' . $linkpath . 'includes/js/tcal.css" type="text/css" />
		          <link rel="stylesheet" href="' . $linkpath . 'includes/css/SpryAssets/SpryAccordion.css" type="text/css" />
                  <link rel="stylesheet" href="' . $linkpath . 'includes/css/jquery-ui-1.10.3.custom.css" type="text/css" />
		          <script language="JavaScript" src="' . $linkpath . 'includes/css/SpryAssets/SpryAccordion.js" type="text/javascript"></script>
                  <script language="JavaScript" src="' . $linkpath . 'includes/js/jquery-1.9.1.js"></script>
                  <script language="JavaScript" src="' . $linkpath . 'includes/js/jquery/sweet-alert.js?r=' . $random . '"></script> 
		          <script language="JavaScript" src="' . $linkpath . 'includes/js/jsCode.js?r=' . $random . '"></script>
		          <script language="JavaScript" src="' . $linkpath . 'includes/js/calendario/SCappearance.js"></script>
		          <script language="JavaScript" src="' . $linkpath . 'includes/js/calendario/SprigstCalendar.js"></script>
                  <script LANGUAGE="JavaScript" src="' . $linkpath . 'includes/js/jquery-ui-1.10.3.custom.js"></script>
                  <link rel="stylesheet" href="' . $linkpath . 'includes/css/jquery/jquery.ui.all.css" type="text/css" />
                  <link rel="stylesheet" href="' . $linkpath . 'includes/js/tcal.css" type="text/css" />
                  <script language="JavaScript" src="' . $linkpath . 'includes/js/tcal.js"></script>
                  <link rel="stylesheet" href="' . $linkpath . 'includes/css/bootstrap.4.css" type="text/css" />
                  <script language="JavaScript" src="' . $linkpath . 'includes/js/bootstrap.js"></script>
                  <link rel="stylesheet" href="' . $linkpath .'includes/css/icons/icomoon/styles.min.css" type="text/css">
                  <link rel="stylesheet" href="' . $linkpath .'includes/css/icons/fontawesome/styles.min.css" type="text/css">
                  <link rel="stylesheet" href="' . $linkpath . 'includes/css/jquery/sweet-alert.css" type="text/css" />

		  <title>' . $pagetitle . ' - ' . $subtitle . '</title>';
    if ($subtitle === "Script") {
        echo '<link rel="stylesheet" href="' . $linkpath . 'includes/css/script.css" type="text/css" />';
    }
}

# MUESTRA EL MENU

function layout_menu($db, $jsFunction = "") {
    global $linkpath, $header_title, $isPredictivo, $db;

    $es_cumple = 0;
    $festejo = 0;

    $isPredictivo = get_EsPredictivo($db);

    if (is_logged()) {
        $name = get_session_varname('s_usr_nombre');
        $es_cumple = get_session_varname('es_cumple');//here
        set_session_varname("es_cumple", 0);
        $festejo = get_session_varname('festejo');//here
        set_session_varname("festejo", 0);
    }
    
    //Se valida que la variable tenga el valor de cumpleños y muestre el pop-up
    if ($es_cumple == 1){
        $jsFunction = $jsFunction." dialogo('https://172.20.1.72/ImagenesAntiestres/cumple/imagen_cumple2.gif', 'Hoy es tu cumpleaños, FELICIDADES!!!');";
    }
    
    if ($festejo == 1){
        $jsFunction = $jsFunction." dialogo('https://172.20.1.72/ImagenesAntiestres/festejos/festejo.gif', 'FELICIDADES!!!');";
    }

    echo '</head><body id="idBody" class="bottom_image" onload="boton_der_deshabilitado();';
    
    if (strlen($jsFunction) > 0) {
        echo $jsFunction;
    }

    echo'">
          <table class="width100" border="0">
            <tr background="' . $linkpath . 'includes/imgs/amex.jpg">
                <td>
                    <p><img style="width: 41%; height: 41%;" src="' . $linkpath . 'includes/imgs/amex_logo.png" class="valignmiddle"/><a class="title2"><font color="white">&nbsp;' . $header_title . '</font></a></p>
                </td><td>';
    if (is_logged() && (get_session_varname('s_usr_nivel') == 'A' || get_session_varname('s_usr_nivel') == 'ACB' || get_session_varname('s_usr_nivel') == 'ASB')) {
                $detalle = get_agente_info(get_session_varname("s_usr_id"), $db);


                
if ($detalle && !$detalle->EOF) {
    $detalle->MoveFirst();

    echo '<table align="center">';
    
    // Accede a la columna 'CANCELADAS' (suponiendo que es el nombre correcto)
    echo '<tr><td><font color="white"><b>Solicitudes Canceladas:</b></font></td><td><font color="white">' . $detalle->fields['CANCELADAS'] . '</font></td></tr>';

    // Accede a la columna 'ACEPTADAS'
    echo '<tr><td><font color="white"><b>Solicitudes Aceptadas:</b></font></td><td><font color="white">' . $detalle->fields['ACEPTADAS']. '</font></td></tr>';

    // Accede a la columna 'ULTIMASOLICITUD'
    echo '<tr><td><font color="white"><b>Ultima Solicitud:</b></font></td><td><font color="white">' . $detalle->fields['ULTIMASOLICITUD'] . '</font></td></tr>';

    // Accede a la columna 'V_NOTA'
    echo '<tr><td><font color="white"><b>Nota de Validación:</b></font></td><td><font color="white">' . $detalle->fields['V_NOTA'] . '</font></td></tr>';

    echo '</table>';
}
} else {
        echo '&nbsp;';
    }
    echo '</td>
                </tr><tr class="bar">
                    <td align="left" width="50%">';
    if (is_logged())
        echo '<b>Usuario: ' . $name . '</b>';
    else
        echo '&nbsp;';
    echo '</td></td><td align="right">&nbsp;<b>' . get_now() . '</b></td>
			</tr><tr>
				<td  colspan="2">
		  			<table class="width100" border="0">
		  				<tr>
		  					<td class="menu">';
    echo menu($db);
    echo '</td>
					  		  <td class="vspacer">&nbsp;</td>
					  		  <td class="text">';
}

# MUESTRA LA PARTE SI MENU

function layout_no_menu() {
    global $linkpath, $header_title;
    echo '</head><body id="idBody" class="bottom_image" onLoad="boton_der_deshabilitado()">
              <table class="width100">
                    <tr>
                        <td>
                            <p class="title"><img src="' . $linkpath . 'includes/imgs/banner_impulse.jpg" class="valignmiddle" />&nbsp;' . $header_title . '</p>
                        </td>
                    </tr><tr class="bar">
                        <td class="bar">&nbsp;</td>
                    </tr><tr>
                            <td>
                                <table class="width100">
                                    <tr>';
}

# MUESTRA EL PIE DE PAGINA

function layout_footer() {
    global $pagefooter, $linkpath;
    ?>	</td></tr>
    </table>
    </td></tr>
    <tr class="spacer">
        <td colspan="2" class="spacer">&nbsp;</td>
    </tr><tr class="bar">
        <td colspan="3">&nbsp;</td>
    </tr>

    <?php if (is_logged() && (get_session_varname('s_usr_nivel') == 'A' || get_session_varname('s_usr_nivel') == 'AI' || get_session_varname('s_usr_nivel') == 'AA' || get_session_varname('s_usr_nivel') == 'ACB')) { ?>
        <div id="dialog-proceso" title="Obteniendo Registro">
            <div id="progressbar"></div>
            <p>Si seleccionaste alguna opcion de break, Baño, capa, agenda o busqueda, debes colgar tu linea!!!</p>
        </div>
        
        <div valign="bottom" id="dial-layer" style="display:none">
            <iframe src='<?php echo $linkpath; ?>modules.php?mod=agentes&op=act27' id='asistido' name='asistido' align='right' scrolling='no' frameborder='0' width='10%' height='10%'>
            </iframe>
        </div>
    <?PHP } ?>                

    <tr>
        <td  colspan="2"><p id="text"><b><?php echo $pagefooter; ?></b></p></td>
    </tr>
    <tr>
        <td colspan="2" align="right">
            <strong>Servidor:</strong><?php echo $_SERVER['SERVER_ADDR'] ?><br />
            <strong>Cliente: </strong><?php echo $_SERVER['REMOTE_ADDR'] ?><br />
        </td>
    </tr>
    </table>
    </body>
    </html>
    <?php
}

# MUESTRA LOS CAMPOS MARCADS COMO OBLIGATORIOS

function form_oblmsg() {
    return '<table class="text">
                <tr>
                    <td colspan="2" class="messagebox">&nbsp;&nbsp;Los campos marcados con * son obligatorios.&nbsp;&nbsp;</td>
                </tr>
        </table>';
}

# MUESTRA EL FOMULARIO PARA INICIAR SESSION

function layout_loggin($message) {

    global $linkpath, $isPredictivo, $marcacion;
    
    echo '<div class="container">
            <form id="login" name="frm1" action="modules.php?mod=admin&op=process_data&act=1" method="POST" class="login-form"><br>
                    <div class="card" style="border-radius: 5px">
                        <div class="card-body" style="border-radius: 5px">
                            <div class="text-center mb-3">
                            <img alt="Brand" src="includes/imgs/user.png" style="margin-top: 5px;margin-bottom: 5px;" width="130" height="130">
                                <!--<h2><font color="#000"><b>Iniciar Sesi�n</b></font></h2>-->
                                <p id="text"><font color="#0a5693"><b>Para ingresar al sistema debes, capturar tu Id Usuario y contrase&ntilde;a</b></font><br></p>
                            </div>
                            <div>
                                <label><font color="red">' . (isset($message) ? $message : 0)  . '</font></label>
                            </div>

                            <div class="input-group flex-nowrap">
                              <span class="input-group-text" id="addon-wrapping"><i class="icon-user text-muted"></i></span>
                              <input type="text" maxlenght="10" size="10" name="user" id="user" class="form-control" placeholder="Id Usuario">
                            </div><br>
                            <div class="input-group flex-nowrap">
                              <span class="input-group-text" id="addon-wrapping"><i class="icon-lock2 text-muted"></i></span>
                                <input type="password" maxlenght="10" size="10"  name="password" id="password" class="form-control" placeholder="Contrase&ntilde;a">
                            </div>
                            <table border="0" id="t1">';
    
    $ip = $_SERVER['REMOTE_ADDR'];
    
    if (substr($ip, 0, 6) == '172.20' || substr($ip, 0, 6) == '172.23') {
        $empresa_inicia = 1;
    } else {
        if (substr($ip, 0, 6) == '172.21'){
            $empresa_inicia = 5;
        } else
            $empresa_inicia = 11;
    }

    
    
    if ($isPredictivo == 1) {

       echo'<div class="form-group form-group-feedback form-group-feedback-left">
                                <tr><td><label>Marcacion</label></td>                            
                                <td>
                                <select name="marcacion" class="form-control" style="width:200px">
                                <option value="0">Selecciona una opcion</option>
                                <option value="1">Predictivo</option>
                                <option value="2">Asistido</option>
                                </select>
<br>
                                </td></tr>
                            </div>';
                    } else {
                        echo '<div class="form-group form-group-feedback form-group-feedback-left">
                                <tr><td><p id="text_marc">Marcaci&oacute;n: </p></td>
                                <td><input type="text" size="10" name="marcacio2n" id="marcacion2" value="Asistido" disabled>
                                <input type="hidden" size="10" name="marcacion" id="marcacion" value="2">    </td></tr>
                            </div>';

                    }
                        echo '</table><div class="form-group">
                                <input type="hidden" name="local" id="local" value="2">
                                <input type="button" class="btn btn-primary btn-block" value="Ingresar" onclick="ValidaLogin()">
                                <!-- <button type="submit" class="btn btn-dark btn-block" onclick="ValidaLogin()">Ingresar <i class="icon-circle-right2 ml-2"></i></button> -->
                            </div>
                        </div>
                    </div>
                </form>';
    echo '
  <ul class="messages"></ul>';
}

?>
