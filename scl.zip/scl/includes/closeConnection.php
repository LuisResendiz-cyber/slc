<?php
$db->Close();
?>