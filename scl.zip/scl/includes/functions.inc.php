<?php
function userdata($string){
	return str_replace("\\","&#092;",htmlspecialchars(trim(get_magic_quotes_gpc() ? stripslashes($string) : $string),ENT_QUOTES,"UTF-8"));
}

function initialize($section, $title){
	global $serveraddress;
	global $linkpath;
	global $db;
	
	if(!load_session()){
		die("Su Sesion ha Expirado. Por favor Ingrese Nuevemente
			<br><a href='{$serveraddress}{$linkpath}'>Ingresar Nuevamente</a>");
	}
        if ($title !== "Script") {
            if(!check_profile($section, $db)){
                    die("No tienes autorizacion para ver esta seccion.
                            <br><a href='#' onclick='javascript:history.back()'>Regresar</a>");
            }
        }
	
	layout_header($title);
}

function initialize_nolayout($section){
    global $db;
    if(!load_session()){
            echo '<a href="index.php">Inicio</a><br>';
            die("Necesitas iniciar sesion para entrar al sistema.");
    }
    if(!check_profile($section, $db)){
            die("No tienes autorizacion para ver esta seccion.");
    }
}

function initialize_layout($section, $title){
	global $db;
    session_start();
	if(!load_session()){
		die("Necesitas iniciar sesion para entrar al sistema.");
	}
	if(!check_profile($section, $db)){
		die("No tienes autorizacion para ver esta seccion.");
	}
    layout_header($title);
}

function encripta($data){
    return base64_encode($data);
}

function desencripta($data){
    return base64_decode($data);
}

function quitarCaracteresEspeciales($string) {
    $cadena = strtoupper(trim($string));
    $cadena = str_replace(array('�', '�', '�', '�'), 'A', $cadena);
    $cadena = str_replace(array('�', '�', '�', '�'), 'E', $cadena);
    $cadena = str_replace(array('�', '�', '�', '�'), 'I', $cadena);
    $cadena = str_replace(array('�', '�', '�', '�'), 'O', $cadena);
    $cadena = str_replace(array('�', '�', '�', '�'), 'U', $cadena);
    $cadena = str_replace(array('�', '�'), 'N', $cadena);
    
    return $cadena;
}
