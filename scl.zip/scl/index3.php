<?php
require_once("includes/includes.inc.php");
?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $header_title; ?></title>
<script language="JavaScript">
    function confirmExit()
    {
        return 'Esta accion perdera los cambios hechos a la pagina si no guardas!!!!!';
    }
</script>
</head>
<body onbeforeunload="return confirmExit()">
    <iframe src=<?php $_SERVER['SERVER_ADDR'].$linkpath ?>"index2.php" width="100%" height="100%" frameborder="0">
        <p>El navegador no soporta IFrames.</p>
    </iframe>
</body>
</html>

